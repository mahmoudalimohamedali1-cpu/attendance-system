export declare const TenantId: (...dataOrPipes: unknown[]) => ParameterDecorator;
