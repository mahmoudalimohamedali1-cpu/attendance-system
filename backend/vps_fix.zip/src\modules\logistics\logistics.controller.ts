import {
    Controller,
    Get,
    Post,
    Body,
    Param,
    Delete,
    UseGuards,
    Request,
    Query,
} from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { RolesGuard } from '../auth/guards/roles.guard';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { LogisticsService } from './logistics.service';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';

@ApiTags('Logistics')
@ApiBearerAuth()
@Controller('logistics')
@UseGuards(JwtAuthGuard, RolesGuard)
export class LogisticsController {
    constructor(private readonly logisticsService: LogisticsService) { }

    // ==================== الرحلات ====================

    @Get('trips')
    @Roles('ADMIN', 'HR', 'MANAGER')
    @ApiOperation({ summary: 'جلب جميع الرحلات' })
    async getTrips(@CurrentUser('companyId') companyId: string) {
        return this.logisticsService.getTrips(companyId);
    }

    @Post('trips')
    @Roles('ADMIN', 'HR', 'MANAGER')
    @ApiOperation({ summary: 'إضافة رحلة جديدة' })
    async createTrip(@CurrentUser('companyId') companyId: string, @Body() data: any) {
        return this.logisticsService.createTrip(companyId, data);
    }

    @Delete('trips/:id')
    @Roles('ADMIN', 'HR')
    @ApiOperation({ summary: 'حذف رحلة' })
    async deleteTrip(@Param('id') id: string) {
        return this.logisticsService.deleteTrip(id);
    }

    // ==================== التوصيلات ====================

    @Get('deliveries')
    @Roles('ADMIN', 'HR', 'MANAGER')
    @ApiOperation({ summary: 'جلب جميع التوصيلات' })
    async getDeliveries(@CurrentUser('companyId') companyId: string) {
        return this.logisticsService.getDeliveries(companyId);
    }

    @Post('deliveries')
    @Roles('ADMIN', 'HR', 'MANAGER')
    @ApiOperation({ summary: 'إضافة توصيل جديد' })
    async createDelivery(@CurrentUser('companyId') companyId: string, @Body() data: any) {
        return this.logisticsService.createDelivery(companyId, data);
    }

    @Delete('deliveries/:id')
    @Roles('ADMIN', 'HR')
    @ApiOperation({ summary: 'حذف توصيل' })
    async deleteDelivery(@Param('id') id: string) {
        return this.logisticsService.deleteDelivery(id);
    }

    // ==================== الجرد ====================

    @Get('inventory')
    @Roles('ADMIN', 'HR', 'MANAGER')
    @ApiOperation({ summary: 'جلب جميع عمليات الجرد' })
    async getInventoryCounts(@CurrentUser('companyId') companyId: string) {
        return this.logisticsService.getInventoryCounts(companyId);
    }

    @Post('inventory')
    @Roles('ADMIN', 'HR', 'MANAGER')
    @ApiOperation({ summary: 'إضافة عملية جرد' })
    async createInventoryCount(@CurrentUser('companyId') companyId: string, @Body() data: any) {
        return this.logisticsService.createInventoryCount(companyId, data);
    }

    @Delete('inventory/:id')
    @Roles('ADMIN', 'HR')
    @ApiOperation({ summary: 'حذف عملية جرد' })
    async deleteInventoryCount(@Param('id') id: string) {
        return this.logisticsService.deleteInventoryCount(id);
    }

    // ==================== أداء السائقين ====================

    @Get('driver-performance')
    @Roles('ADMIN', 'HR', 'MANAGER')
    @ApiOperation({ summary: 'جلب أداء السائقين' })
    async getDriverPerformance(
        @CurrentUser('companyId') companyId: string,
        @Query('month') month?: number,
        @Query('year') year?: number,
    ) {
        const now = new Date();
        return this.logisticsService.getDriverPerformance(
            companyId,
            month || now.getMonth() + 1,
            year || now.getFullYear(),
        );
    }

    @Post('driver-performance/calculate')
    @Roles('ADMIN', 'HR')
    @ApiOperation({ summary: 'حساب أداء السائقين للشهر' })
    async calculateDriverPerformance(
        @CurrentUser('companyId') companyId: string,
        @Query('month') month: number,
        @Query('year') year: number,
    ) {
        return this.logisticsService.calculateDriverPerformance(
            companyId,
            month,
            year,
        );
    }
}
