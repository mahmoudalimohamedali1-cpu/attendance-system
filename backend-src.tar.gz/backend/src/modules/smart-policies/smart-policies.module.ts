import { Module, forwardRef } from "@nestjs/common";
import { SmartPoliciesController } from "./smart-policies.controller";
import { SmartPoliciesService } from "./smart-policies.service";
import { SmartPolicyExecutorService } from "./smart-policy-executor.service";
import { SmartPolicyTriggerService } from "./smart-policy-trigger.service";
import { AIPolicyEvaluatorService } from "./ai-policy-evaluator.service";
import { PolicyContextService } from "./policy-context.service";
import { FormulaParserService } from "./formula-parser.service";
import { DynamicQueryService } from "./dynamic-query.service";
import { SchemaDiscoveryService } from "./schema-discovery.service";
import { AiAgentService } from "./ai-agent.service";
import { AiSchemaGeneratorService } from "./ai-schema-generator.service";
import { AiCodeGeneratorService } from "./ai-code-generator.service";
import { PolicyVersioningService } from "./policy-versioning.service";
import { PolicyApprovalService } from "./policy-approval.service";
import { PolicySimulationService } from "./policy-simulation.service";
import { PolicyConflictService } from "./policy-conflict.service";
import { PolicyAuditService } from "./policy-audit.service";
import { PolicyNotificationService } from "./policy-notification.service";
// === New Enterprise Services ===
import { PolicyExceptionService } from "./policy-exception.service";
import { TieredPenaltyService } from "./tiered-penalty.service";
import { RetroactivePolicyService } from "./retroactive-policy.service";
import { PayrollProtectionService } from "./payroll-protection.service";
// === Phase 2: Analytics, Coach & Templates ===
import { PolicyAnalyticsService } from "./policy-analytics.service";
import { PolicyTemplatesService } from "./policy-templates.service";
import { PolicyCoachService } from "./policy-coach.service";
// === Phase 3: Accountant Tools ===
import { AccountantDashboardService } from "./accountant-dashboard.service";
import { PayrollPolicyIntegrationService } from "./payroll-policy-integration.service";
import { PolicyFinancialReportService } from "./policy-financial-report.service";
import { PolicyExportService } from "./policy-export.service";
import { PrismaModule } from "../../common/prisma/prisma.module";
import { AiModule } from "../ai/ai.module";

@Module({
    imports: [PrismaModule, forwardRef(() => AiModule)],
    controllers: [SmartPoliciesController],
    providers: [
        SmartPoliciesService,
        SmartPolicyExecutorService,
        SmartPolicyTriggerService,
        AIPolicyEvaluatorService,
        PolicyContextService,
        FormulaParserService,
        DynamicQueryService,
        SchemaDiscoveryService,
        AiAgentService,
        AiSchemaGeneratorService,
        AiCodeGeneratorService,
        PolicyVersioningService,
        PolicyApprovalService,
        PolicySimulationService,
        PolicyConflictService,
        PolicyAuditService,
        PolicyNotificationService,
        // === New Enterprise Services ===
        PolicyExceptionService,
        TieredPenaltyService,
        RetroactivePolicyService,
        PayrollProtectionService,
        // === Phase 2: Analytics, Coach & Templates ===
        PolicyAnalyticsService,
        PolicyTemplatesService,
        PolicyCoachService,
        // === Phase 3: Accountant Tools ===
        AccountantDashboardService,
        PayrollPolicyIntegrationService,
        PolicyFinancialReportService,
        PolicyExportService,
    ],
    exports: [
        SmartPoliciesService,
        SmartPolicyExecutorService,
        SmartPolicyTriggerService,
        AIPolicyEvaluatorService,
        PolicyContextService,
        FormulaParserService,
        DynamicQueryService,
        SchemaDiscoveryService,
        AiAgentService,
        AiSchemaGeneratorService,
        AiCodeGeneratorService,
        PolicyVersioningService,
        PolicyApprovalService,
        PolicySimulationService,
        PolicyConflictService,
        PolicyAuditService,
        PolicyNotificationService,
        // === New Enterprise Services ===
        PolicyExceptionService,
        TieredPenaltyService,
        RetroactivePolicyService,
        PayrollProtectionService,
        // === Phase 2: Analytics, Coach & Templates ===
        PolicyAnalyticsService,
        PolicyTemplatesService,
        PolicyCoachService,
        // === Phase 3: Accountant Tools ===
        AccountantDashboardService,
        PayrollPolicyIntegrationService,
        PolicyFinancialReportService,
        PolicyExportService,
    ],
})
export class SmartPoliciesModule { }
