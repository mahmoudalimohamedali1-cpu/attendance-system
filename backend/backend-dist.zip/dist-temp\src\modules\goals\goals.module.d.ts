export declare class GoalsModule {
}
