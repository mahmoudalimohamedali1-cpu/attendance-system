import{c as t,j as o}from"./index-D5un0LxA.js";const a=t(o.jsx("path",{d:"M8 5v14l11-7z"}),"PlayArrow");export{a as S};
