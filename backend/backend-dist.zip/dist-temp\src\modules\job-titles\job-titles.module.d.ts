export declare class JobTitlesModule {
}
