export declare class CompaniesModule {
}
