import{c as o,j as s}from"./index-D5un0LxA.js";const e=o(s.jsx("path",{d:"M2.01 21 23 12 2.01 3 2 10l15 2-15 2z"}),"Send");export{e as S};
