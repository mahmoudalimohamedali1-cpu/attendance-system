export declare class CompanyConfigModule {
}
