export declare class PdfModule {
}
