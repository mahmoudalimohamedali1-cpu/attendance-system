import{aO as o,aP as e}from"./index-Dt9l-mSr.js";function s(r,a){o(2,arguments);var t=e(r),i=e(a);return t.getTime()>i.getTime()}export{s as i};
