export declare class AiHrModule {
}
