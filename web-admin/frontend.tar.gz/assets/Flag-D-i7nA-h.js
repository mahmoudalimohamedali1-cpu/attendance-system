import{c as a,j as o}from"./index-BuXFEtFT.js";const t=a(o.jsx("path",{d:"M14.4 6 14 4H5v17h2v-7h5.6l.4 2h7V6z"}),"Flag");export{t as F};
