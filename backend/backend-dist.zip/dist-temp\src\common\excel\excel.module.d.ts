export declare class ExcelModule {
}
