export declare class ApproveLeaveDto {
    notes?: string;
}
