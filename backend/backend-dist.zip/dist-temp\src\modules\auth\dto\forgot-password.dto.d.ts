export declare class ForgotPasswordDto {
    email: string;
}
