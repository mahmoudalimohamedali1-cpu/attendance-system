import{c as e,j as o}from"./index-D5un0LxA.js";const t=e(o.jsx("path",{d:"M19 13H5v-2h14z"}),"Remove");export{t as R};
