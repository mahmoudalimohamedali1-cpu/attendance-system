export declare class DevicesModule {
}
