export declare class RegisterFaceDto {
    faceEmbedding: string | number[];
    faceImage?: string;
    confidence?: number;
    deviceInfo?: string;
}
