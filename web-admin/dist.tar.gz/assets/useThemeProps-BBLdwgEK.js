import{av as t,aw as p}from"./index-Dt9l-mSr.js";function n({props:s,name:o,defaultTheme:m,themeId:r}){let e=t(m);return r&&(e=e[r]||e),p({theme:e,name:o,props:s})}export{n as u};
