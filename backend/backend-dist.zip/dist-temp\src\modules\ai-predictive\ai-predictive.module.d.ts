export declare class AiPredictiveModule {
}
