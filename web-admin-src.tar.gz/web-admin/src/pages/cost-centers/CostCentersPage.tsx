import React, { useState, useEffect } from 'react';
import {
    Box,
    Paper,
    Typography,
    Button,
    IconButton,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    TextField,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Chip,
    Alert,
    CircularProgress,
    Card,
    CardContent,
    Grid,
    Tooltip,
    Tabs,
    Tab,
    LinearProgress,
    Collapse,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    ListItemSecondaryAction,
    FormControlLabel,
    Switch,
    Avatar,
    Autocomplete,
} from '@mui/material';
import {
    Add as AddIcon,
    Edit as EditIcon,
    Archive as ArchiveIcon,
    AccountTree as TreeIcon,
    ExpandMore,
    ExpandLess,
    Folder as FolderIcon,
    FolderOpen as FolderOpenIcon,
    Person as PersonIcon,
    AttachMoney as BudgetIcon,
    PieChart as AllocationIcon,
    Business as BusinessIcon,
    TrendingUp as TrendingUpIcon,
    TrendingDown as TrendingDownIcon,
} from '@mui/icons-material';
import { api } from '@/services/api.service';

// ==================== Types ====================

interface CostCenter {
    id: string;
    code: string;
    nameAr: string;
    nameEn?: string;
    description?: string;
    type: string;
    status: string;
    level: number;
    path?: string;
    parentId?: string;
    parent?: { id: string; code: string; nameAr: string };
    children?: CostCenter[];
    managerId?: string;
    effectiveFrom: string;
    effectiveTo?: string;
    isAllowOverbudget: boolean;
    _count?: { users: number; allocations: number; budgets: number };
}

interface CostCenterBudget {
    id: string;
    year: number;
    month?: number;
    budgetAmount: number;
    actualAmount: number;
    variance: number;
    notes?: string;
}

interface Allocation {
    id: string;
    userId: string;
    percentage: number;
    effectiveFrom: string;
    effectiveTo?: string;
    isActive: boolean;
    user?: {
        id: string;
        firstName: string;
        lastName: string;
        email: string;
    };
}

interface Employee {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
}

interface Analytics {
    costCenter: CostCenter;
    summary: {
        directEmployees: number;
        childrenCount: number;
        allocationsCount: number;
        totalAllocationPercentage: number;
    };
    budget: {
        totalBudget: number;
        totalActual: number;
        totalVariance: number;
        utilizationRate: number;
        periods: CostCenterBudget[];
    };
}

// ==================== Tree Node Component ====================

const TreeNode: React.FC<{
    node: CostCenter;
    level: number;
    onSelect: (node: CostCenter) => void;
    selectedId?: string;
}> = ({ node, level, onSelect, selectedId }) => {
    const [expanded, setExpanded] = useState(level < 2);
    const hasChildren = node.children && node.children.length > 0;

    return (
        <Box>
            <ListItem
                button
                onClick={() => onSelect(node)}
                sx={{
                    pl: level * 3,
                    bgcolor: selectedId === node.id ? 'primary.light' : 'transparent',
                    '&:hover': { bgcolor: 'action.hover' },
                    borderRadius: 1,
                    mb: 0.5,
                }}
            >
                <ListItemIcon sx={{ minWidth: 36 }}>
                    {hasChildren ? (
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); setExpanded(!expanded); }}>
                            {expanded ? <ExpandLess /> : <ExpandMore />}
                        </IconButton>
                    ) : (
                        <Box sx={{ width: 36 }} />
                    )}
                </ListItemIcon>
                <ListItemIcon sx={{ minWidth: 36 }}>
                    {hasChildren ? (expanded ? <FolderOpenIcon color="primary" /> : <FolderIcon color="primary" />) : <BusinessIcon />}
                </ListItemIcon>
                <ListItemText
                    primary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Typography fontWeight="medium">{node.nameAr}</Typography>
                            <Chip label={node.code} size="small" variant="outlined" />
                        </Box>
                    }
                    secondary={node.description || `المستوى ${node.level}`}
                />
                <ListItemSecondaryAction>
                    <Chip
                        label={node.type === 'OPERATING' ? 'تشغيلي' : node.type === 'PROJECT' ? 'مشروع' : node.type === 'OVERHEAD' ? 'تكاليف عامة' : 'إيراد'}
                        size="small"
                        color={node.type === 'OPERATING' ? 'primary' : node.type === 'PROJECT' ? 'secondary' : 'default'}
                    />
                </ListItemSecondaryAction>
            </ListItem>
            {hasChildren && (
                <Collapse in={expanded}>
                    {node.children!.map((child) => (
                        <TreeNode key={child.id} node={child} level={level + 1} onSelect={onSelect} selectedId={selectedId} />
                    ))}
                </Collapse>
            )}
        </Box>
    );
};

// ==================== Main Page Component ====================

const CostCentersPage: React.FC = () => {
    const [loading, setLoading] = useState(true);
    const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
    const [tree, setTree] = useState<CostCenter[]>([]);
    const [selectedCC, setSelectedCC] = useState<CostCenter | null>(null);
    const [analytics, setAnalytics] = useState<Analytics | null>(null);
    const [activeTab, setActiveTab] = useState(0);

    // Dialog states
    const [dialogOpen, setDialogOpen] = useState(false);
    const [budgetDialogOpen, setBudgetDialogOpen] = useState(false);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);

    // Form state
    const [form, setForm] = useState({
        code: '',
        nameAr: '',
        nameEn: '',
        description: '',
        type: 'OPERATING',
        parentId: '',
        isAllowOverbudget: false,
    });

    const [budgetForm, setBudgetForm] = useState({
        year: new Date().getFullYear(),
        month: null as number | null,
        budgetAmount: 0,
        notes: '',
    });

    // Allocations state
    const [allocations, setAllocations] = useState<Allocation[]>([]);
    const [employees, setEmployees] = useState<Employee[]>([]);
    const [allocationDialogOpen, setAllocationDialogOpen] = useState(false);
    const [allocationForm, setAllocationForm] = useState({
        userId: '',
        percentage: 100,
    });

    // Fetch data
    const fetchData = async () => {
        setLoading(true);
        try {
            const [listRes, treeRes] = await Promise.all([
                api.get('/cost-centers'),
                api.get('/cost-centers/tree'),
            ]);
            setCostCenters(listRes as CostCenter[]);
            setTree(treeRes as CostCenter[]);
        } catch (err: any) {
            setError(err.message || 'فشل في تحميل البيانات');
        } finally {
            setLoading(false);
        }
    };

    const fetchAnalytics = async (id: string) => {
        try {
            const res = await api.get(`/cost-centers/${id}/analytics`);
            setAnalytics(res as Analytics);
            // Fetch allocations for selected cost center
            const allocRes = await api.get(`/cost-centers/${id}/allocations`);
            setAllocations(allocRes as Allocation[]);
        } catch (err: any) {
            console.error('Failed to fetch analytics:', err);
        }
    };

    const fetchEmployees = async () => {
        try {
            const res = await api.get('/users');
            setEmployees(res as Employee[]);
        } catch (err: any) {
            console.error('Failed to fetch employees:', err);
        }
    };

    useEffect(() => {
        fetchData();
        fetchEmployees();
    }, []);

    useEffect(() => {
        if (selectedCC) {
            fetchAnalytics(selectedCC.id);
        }
    }, [selectedCC]);

    // Handlers
    const handleOpenDialog = (cc?: CostCenter) => {
        if (cc) {
            setForm({
                code: cc.code,
                nameAr: cc.nameAr,
                nameEn: cc.nameEn || '',
                description: cc.description || '',
                type: cc.type,
                parentId: cc.parentId || '',
                isAllowOverbudget: cc.isAllowOverbudget,
            });
            setSelectedCC(cc);
        } else {
            setForm({
                code: '',
                nameAr: '',
                nameEn: '',
                description: '',
                type: 'OPERATING',
                parentId: selectedCC?.id || '',
                isAllowOverbudget: false,
            });
        }
        setDialogOpen(true);
    };

    const handleSubmit = async () => {
        setSaving(true);
        setError(null);
        try {
            if (selectedCC && dialogOpen) {
                await api.patch(`/cost-centers/${selectedCC.id}`, form);
            } else {
                const data = { ...form };
                if (!data.parentId) delete (data as any).parentId;
                await api.post('/cost-centers', data);
            }
            setDialogOpen(false);
            fetchData();
        } catch (err: any) {
            setError(err.response?.data?.message || err.message || 'فشل في الحفظ');
        } finally {
            setSaving(false);
        }
    };

    const handleArchive = async (id: string) => {
        if (!confirm('هل أنت متأكد من أرشفة مركز التكلفة؟')) return;
        try {
            await api.delete(`/cost-centers/${id}`);
            fetchData();
            if (selectedCC?.id === id) setSelectedCC(null);
        } catch (err: any) {
            setError(err.response?.data?.message || 'فشل في الأرشفة');
        }
    };

    const handleSubmitBudget = async () => {
        if (!selectedCC) return;
        setSaving(true);
        try {
            await api.post(`/cost-centers/${selectedCC.id}/budgets`, budgetForm);
            setBudgetDialogOpen(false);
            fetchAnalytics(selectedCC.id);
        } catch (err: any) {
            setError(err.response?.data?.message || 'فشل في إضافة الميزانية');
        } finally {
            setSaving(false);
        }
    };

    // Render
    if (loading) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
                <CircularProgress />
            </Box>
        );
    }

    return (
        <Box>
            {/* Header */}
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
                <Box>
                    <Typography variant="h4" fontWeight="bold">
                        <TreeIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                        مراكز التكلفة
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        إدارة الهيكل الهرمي لمراكز التكلفة والميزانيات
                    </Typography>
                </Box>
                <Button variant="contained" startIcon={<AddIcon />} onClick={() => handleOpenDialog()}>
                    إضافة مركز تكلفة
                </Button>
            </Box>

            {error && (
                <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
                    {error}
                </Alert>
            )}

            <Grid container spacing={3}>
                {/* Tree View */}
                <Grid item xs={12} md={5}>
                    <Paper sx={{ p: 2, minHeight: 500 }}>
                        <Typography variant="h6" gutterBottom>
                            الهيكل الهرمي
                        </Typography>
                        {tree.length === 0 ? (
                            <Box textAlign="center" py={4}>
                                <Typography color="text.secondary">لا توجد مراكز تكلفة</Typography>
                                <Button startIcon={<AddIcon />} onClick={() => handleOpenDialog()} sx={{ mt: 2 }}>
                                    إنشاء أول مركز
                                </Button>
                            </Box>
                        ) : (
                            <List>
                                {tree.map((node) => (
                                    <TreeNode
                                        key={node.id}
                                        node={node}
                                        level={0}
                                        onSelect={(node) => setSelectedCC(node)}
                                        selectedId={selectedCC?.id}
                                    />
                                ))}
                            </List>
                        )}
                    </Paper>
                </Grid>

                {/* Details Panel */}
                <Grid item xs={12} md={7}>
                    {selectedCC ? (
                        <Paper sx={{ p: 2 }}>
                            {/* Header */}
                            <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={2}>
                                <Box>
                                    <Typography variant="h5" fontWeight="bold">
                                        {selectedCC.nameAr}
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        {selectedCC.code} • {selectedCC.path}
                                    </Typography>
                                </Box>
                                <Box>
                                    <IconButton onClick={() => handleOpenDialog(selectedCC)}>
                                        <EditIcon />
                                    </IconButton>
                                    <IconButton color="error" onClick={() => handleArchive(selectedCC.id)}>
                                        <ArchiveIcon />
                                    </IconButton>
                                </Box>
                            </Box>

                            {/* Summary Cards */}
                            {analytics && (
                                <Grid container spacing={2} mb={3}>
                                    <Grid item xs={6} sm={3}>
                                        <Card variant="outlined">
                                            <CardContent>
                                                <Typography variant="caption" color="text.secondary">الموظفين</Typography>
                                                <Typography variant="h4">{analytics.summary.directEmployees}</Typography>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={6} sm={3}>
                                        <Card variant="outlined">
                                            <CardContent>
                                                <Typography variant="caption" color="text.secondary">التوزيعات</Typography>
                                                <Typography variant="h4">{analytics.summary.allocationsCount}</Typography>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={6} sm={3}>
                                        <Card variant="outlined">
                                            <CardContent>
                                                <Typography variant="caption" color="text.secondary">نسب التوزيع</Typography>
                                                <Typography variant="h4">{analytics.summary.totalAllocationPercentage}%</Typography>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={6} sm={3}>
                                        <Card variant="outlined">
                                            <CardContent>
                                                <Typography variant="caption" color="text.secondary">الاستخدام</Typography>
                                                <Typography variant="h4" color={analytics.budget.utilizationRate > 100 ? 'error' : 'success'}>
                                                    {analytics.budget.utilizationRate}%
                                                </Typography>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                </Grid>
                            )}

                            {/* Tabs */}
                            <Tabs value={activeTab} onChange={(_, v) => setActiveTab(v)} sx={{ mb: 2 }}>
                                <Tab label="الميزانية" icon={<BudgetIcon />} iconPosition="start" />
                                <Tab label="التوزيعات" icon={<AllocationIcon />} iconPosition="start" />
                            </Tabs>

                            {/* Budget Tab */}
                            {activeTab === 0 && analytics && (
                                <Box>
                                    <Box display="flex" justifyContent="space-between" mb={2}>
                                        <Typography variant="h6">الميزانية</Typography>
                                        <Button size="small" startIcon={<AddIcon />} onClick={() => setBudgetDialogOpen(true)}>
                                            إضافة ميزانية
                                        </Button>
                                    </Box>

                                    {/* Budget Summary */}
                                    <Grid container spacing={2} mb={3}>
                                        <Grid item xs={4}>
                                            <Box textAlign="center" p={2} bgcolor="success.light" borderRadius={2}>
                                                <Typography variant="caption">الميزانية</Typography>
                                                <Typography variant="h5">{analytics.budget.totalBudget.toLocaleString()}</Typography>
                                            </Box>
                                        </Grid>
                                        <Grid item xs={4}>
                                            <Box textAlign="center" p={2} bgcolor="info.light" borderRadius={2}>
                                                <Typography variant="caption">الفعلي</Typography>
                                                <Typography variant="h5">{analytics.budget.totalActual.toLocaleString()}</Typography>
                                            </Box>
                                        </Grid>
                                        <Grid item xs={4}>
                                            <Box textAlign="center" p={2} bgcolor={analytics.budget.totalVariance >= 0 ? 'success.light' : 'error.light'} borderRadius={2}>
                                                <Typography variant="caption">التباين</Typography>
                                                <Typography variant="h5">
                                                    {analytics.budget.totalVariance >= 0 ? <TrendingUpIcon sx={{ fontSize: 16 }} /> : <TrendingDownIcon sx={{ fontSize: 16 }} />}
                                                    {Math.abs(analytics.budget.totalVariance).toLocaleString()}
                                                </Typography>
                                            </Box>
                                        </Grid>
                                    </Grid>

                                    {/* Utilization Bar */}
                                    <Box mb={2}>
                                        <Typography variant="body2" gutterBottom>نسبة الاستخدام</Typography>
                                        <LinearProgress
                                            variant="determinate"
                                            value={Math.min(analytics.budget.utilizationRate, 100)}
                                            color={analytics.budget.utilizationRate > 100 ? 'error' : analytics.budget.utilizationRate > 80 ? 'warning' : 'success'}
                                            sx={{ height: 10, borderRadius: 5 }}
                                        />
                                    </Box>
                                </Box>
                            )}

                            {/* Allocations Tab */}
                            {activeTab === 1 && (
                                <Box>
                                    <Box display="flex" justifyContent="space-between" mb={2}>
                                        <Typography variant="h6">التوزيعات</Typography>
                                        <Button size="small" startIcon={<AddIcon />} onClick={() => {
                                            setAllocationForm({ userId: '', percentage: 100 });
                                            setAllocationDialogOpen(true);
                                        }}>
                                            إضافة توزيع
                                        </Button>
                                    </Box>

                                    {allocations.length === 0 ? (
                                        <Typography variant="body2" color="text.secondary" textAlign="center" py={4}>
                                            لا توجد توزيعات لهذا المركز
                                        </Typography>
                                    ) : (
                                        <List>
                                            {allocations.map((alloc) => (
                                                <ListItem
                                                    key={alloc.id}
                                                    sx={{ bgcolor: 'background.paper', mb: 1, borderRadius: 1, border: '1px solid', borderColor: 'divider' }}
                                                >
                                                    <ListItemIcon>
                                                        <Avatar sx={{ width: 36, height: 36 }}>
                                                            {alloc.user?.firstName?.[0] || 'U'}
                                                        </Avatar>
                                                    </ListItemIcon>
                                                    <ListItemText
                                                        primary={`${alloc.user?.firstName || ''} ${alloc.user?.lastName || ''}`}
                                                        secondary={`${alloc.percentage}% - منذ ${new Date(alloc.effectiveFrom).toLocaleDateString('ar-SA')}`}
                                                    />
                                                    <ListItemSecondaryAction>
                                                        <Chip
                                                            label={`${alloc.percentage}%`}
                                                            color="primary"
                                                            size="small"
                                                            sx={{ mr: 1 }}
                                                        />
                                                        <IconButton
                                                            edge="end"
                                                            size="small"
                                                            color="error"
                                                            onClick={async () => {
                                                                try {
                                                                    await api.delete(`/cost-centers/allocations/${alloc.id}`);
                                                                    if (selectedCC) fetchAnalytics(selectedCC.id);
                                                                } catch (err: any) {
                                                                    setError(err.message || 'فشل في الحذف');
                                                                }
                                                            }}
                                                        >
                                                            <ArchiveIcon fontSize="small" />
                                                        </IconButton>
                                                    </ListItemSecondaryAction>
                                                </ListItem>
                                            ))}
                                        </List>
                                    )}
                                </Box>
                            )}
                        </Paper>
                    ) : (
                        <Paper sx={{ p: 4, textAlign: 'center', minHeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            <Box>
                                <TreeIcon sx={{ fontSize: 80, color: 'text.disabled', mb: 2 }} />
                                <Typography variant="h6" color="text.secondary">
                                    اختر مركز تكلفة لعرض التفاصيل
                                </Typography>
                            </Box>
                        </Paper>
                    )}
                </Grid>
            </Grid>

            {/* Create/Edit Dialog */}
            <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
                <DialogTitle>{selectedCC ? 'تعديل مركز تكلفة' : 'إضافة مركز تكلفة جديد'}</DialogTitle>
                <DialogContent>
                    <Grid container spacing={2} sx={{ mt: 1 }}>
                        <Grid item xs={6}>
                            <TextField
                                fullWidth
                                label="الكود"
                                value={form.code}
                                onChange={(e) => setForm({ ...form, code: e.target.value })}
                                placeholder="CC-001"
                            />
                        </Grid>
                        <Grid item xs={6}>
                            <FormControl fullWidth>
                                <InputLabel>النوع</InputLabel>
                                <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} label="النوع">
                                    <MenuItem value="OPERATING">تشغيلي</MenuItem>
                                    <MenuItem value="PROJECT">مشروع</MenuItem>
                                    <MenuItem value="OVERHEAD">تكاليف عامة</MenuItem>
                                    <MenuItem value="REVENUE">مركز إيراد</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                label="الاسم بالعربية"
                                value={form.nameAr}
                                onChange={(e) => setForm({ ...form, nameAr: e.target.value })}
                                required
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                label="الاسم بالإنجليزية"
                                value={form.nameEn}
                                onChange={(e) => setForm({ ...form, nameEn: e.target.value })}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <FormControl fullWidth>
                                <InputLabel>مركز التكلفة الأب</InputLabel>
                                <Select
                                    value={form.parentId}
                                    onChange={(e) => setForm({ ...form, parentId: e.target.value })}
                                    label="مركز التكلفة الأب"
                                >
                                    <MenuItem value="">بدون (مستوى أول)</MenuItem>
                                    {costCenters.filter((cc) => cc.id !== selectedCC?.id).map((cc) => (
                                        <MenuItem key={cc.id} value={cc.id}>
                                            {cc.path || cc.code} - {cc.nameAr}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                label="الوصف"
                                value={form.description}
                                onChange={(e) => setForm({ ...form, description: e.target.value })}
                                multiline
                                rows={2}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <FormControlLabel
                                control={
                                    <Switch
                                        checked={form.isAllowOverbudget}
                                        onChange={(e) => setForm({ ...form, isAllowOverbudget: e.target.checked })}
                                    />
                                }
                                label="السماح بتجاوز الميزانية"
                            />
                        </Grid>
                    </Grid>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setDialogOpen(false)}>إلغاء</Button>
                    <Button variant="contained" onClick={handleSubmit} disabled={saving || !form.code || !form.nameAr}>
                        {saving ? <CircularProgress size={20} /> : 'حفظ'}
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Budget Dialog */}
            <Dialog open={budgetDialogOpen} onClose={() => setBudgetDialogOpen(false)} maxWidth="xs" fullWidth>
                <DialogTitle>إضافة ميزانية</DialogTitle>
                <DialogContent>
                    <Grid container spacing={2} sx={{ mt: 1 }}>
                        <Grid item xs={6}>
                            <TextField
                                fullWidth
                                type="number"
                                label="السنة"
                                value={budgetForm.year}
                                onChange={(e) => setBudgetForm({ ...budgetForm, year: parseInt(e.target.value) })}
                            />
                        </Grid>
                        <Grid item xs={6}>
                            <FormControl fullWidth>
                                <InputLabel>الشهر</InputLabel>
                                <Select
                                    value={budgetForm.month || ''}
                                    onChange={(e) => setBudgetForm({ ...budgetForm, month: e.target.value ? parseInt(e.target.value as string) : null })}
                                    label="الشهر"
                                >
                                    <MenuItem value="">سنوي</MenuItem>
                                    {[...Array(12)].map((_, i) => (
                                        <MenuItem key={i + 1} value={i + 1}>{i + 1}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                type="number"
                                label="مبلغ الميزانية"
                                value={budgetForm.budgetAmount}
                                onChange={(e) => setBudgetForm({ ...budgetForm, budgetAmount: parseFloat(e.target.value) })}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                label="ملاحظات"
                                value={budgetForm.notes}
                                onChange={(e) => setBudgetForm({ ...budgetForm, notes: e.target.value })}
                                multiline
                                rows={2}
                            />
                        </Grid>
                    </Grid>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setBudgetDialogOpen(false)}>إلغاء</Button>
                    <Button variant="contained" onClick={handleSubmitBudget} disabled={saving || budgetForm.budgetAmount <= 0}>
                        {saving ? <CircularProgress size={20} /> : 'حفظ'}
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Allocation Dialog */}
            <Dialog open={allocationDialogOpen} onClose={() => setAllocationDialogOpen(false)} maxWidth="xs" fullWidth>
                <DialogTitle>إضافة توزيع جديد</DialogTitle>
                <DialogContent>
                    <Grid container spacing={2} sx={{ mt: 1 }}>
                        <Grid item xs={12}>
                            <FormControl fullWidth>
                                <InputLabel>الموظف</InputLabel>
                                <Select
                                    value={allocationForm.userId}
                                    onChange={(e) => setAllocationForm({ ...allocationForm, userId: e.target.value })}
                                    label="الموظف"
                                >
                                    {employees.map((emp) => (
                                        <MenuItem key={emp.id} value={emp.id}>
                                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                <Avatar sx={{ width: 24, height: 24, fontSize: '0.75rem' }}>
                                                    {emp.firstName?.[0]}
                                                </Avatar>
                                                {emp.firstName} {emp.lastName}
                                            </Box>
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                type="number"
                                label="النسبة المئوية"
                                value={allocationForm.percentage}
                                onChange={(e) => setAllocationForm({ ...allocationForm, percentage: parseFloat(e.target.value) })}
                                inputProps={{ min: 0, max: 100, step: 0.01 }}
                                InputProps={{ endAdornment: <Typography>%</Typography> }}
                            />
                        </Grid>
                    </Grid>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setAllocationDialogOpen(false)}>إلغاء</Button>
                    <Button
                        variant="contained"
                        disabled={saving || !allocationForm.userId || allocationForm.percentage <= 0}
                        onClick={async () => {
                            if (!selectedCC) return;
                            setSaving(true);
                            try {
                                await api.post(`/cost-centers/${selectedCC.id}/allocations`, allocationForm);
                                setAllocationDialogOpen(false);
                                fetchAnalytics(selectedCC.id);
                            } catch (err: any) {
                                setError(err.message || 'فشل في إضافة التوزيع');
                            } finally {
                                setSaving(false);
                            }
                        }}
                    >
                        {saving ? <CircularProgress size={20} /> : 'حفظ'}
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
};

export default CostCentersPage;
