import{c as t,j as o}from"./index-Dpjqn_H_.js";const a=t(o.jsx("path",{d:"M8 5v14l11-7z"}),"PlayArrow");export{a as S};
