import {
    Controller,
    Get,
    Post,
    Body,
    Param,
    UseGuards,
    Request,
    Query,
    ParseUUIDPipe
} from '@nestjs/common';
import { DisciplinaryService } from './disciplinary.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionGuard } from '../auth/guards/permission.guard';
import { RequirePermission } from '../auth/decorators/require-permission.decorator';
import { CreateCaseDto } from './dto/create-case.dto';
import { HRReviewDto } from './dto/hr-review.dto';
import { IssueDecisionDto } from './dto/issue-decision.dto';
import { EmployeeResponseDto } from './dto/employee-response.dto';
import { ObjectionReviewDto } from './dto/objection-review.dto';

@Controller('disciplinary')
@UseGuards(JwtAuthGuard, PermissionGuard)
export class DisciplinaryController {
    constructor(private readonly disciplinaryService: DisciplinaryService) { }

    /**
     * إنشاء طلب تحقيق جديد (للمديرين)
     */
    @Post('cases')
    @RequirePermission('DISC_MANAGER_CREATE')
    async createCase(@Request() req: any, @Body() dto: CreateCaseDto) {
        return this.disciplinaryService.createCase(req.user.id, req.user.companyId, dto);
    }

    /**
     * مراجعة أولية للطلب (للـ HR)
     */
    @Post('cases/:id/hr-review')
    @RequirePermission('DISC_HR_REVIEW')
    async hrInitialReview(
        @Param('id', ParseUUIDPipe) id: string,
        @Request() req: any,
        @Body() dto: HRReviewDto
    ) {
        return this.disciplinaryService.hrInitialReview(id, req.user.id, req.user.companyId, dto);
    }

    /**
     * رد الموظف على الإجراء غير الرسمي
     */
    @Post('cases/:id/employee-informal-response')
    @RequirePermission('DISC_EMPLOYEE_RESPONSE')
    async employeeInformalResponse(
        @Param('id', ParseUUIDPipe) id: string,
        @Request() req: any,
        @Body() dto: EmployeeResponseDto
    ) {
        return this.disciplinaryService.employeeInformalResponse(id, req.user.id, req.user.companyId, dto);
    }

    /**
     * إصدار قرار التحقيق (للـ HR)
     */
    @Post('cases/:id/decision')
    @RequirePermission('DISC_HR_DECISION')
    async issueDecision(
        @Param('id', ParseUUIDPipe) id: string,
        @Request() req: any,
        @Body() dto: IssueDecisionDto
    ) {
        return this.disciplinaryService.issueDecision(id, req.user.id, req.user.companyId, dto);
    }

    /**
     * الاعتماد النهائي للقضية
     */
    @Post('cases/:id/finalize')
    @RequirePermission('DISC_HR_FINALIZE')
    async finalizeCase(
        @Param('id', ParseUUIDPipe) id: string,
        @Request() req: any
    ) {
        return this.disciplinaryService.finalizeCase(id, req.user.id, req.user.companyId);
    }

    /**
     * مراجعة الاعتراض من قبل الموارد البشرية
     */
    @Post('cases/:id/objection-review')
    @RequirePermission('DISC_HR_DECISION')
    async objectionReview(
        @Param('id', ParseUUIDPipe) id: string,
        @Request() req: any,
        @Body() dto: ObjectionReviewDto
    ) {
        return this.disciplinaryService.objectionReview(id, req.user.id, req.user.companyId, dto);
    }

    /**
     * جلب تفاصيل القضية
     */
    @Get('cases/:id')
    async getCase(@Param('id', ParseUUIDPipe) id: string, @Request() req: any) {
        // any authenticated user can view if they are part of it or have permissions
        // validation is handled in service
        // return this.disciplinaryService.getCase(id, req.user.id, req.user.companyId);
        // Placeholder for now
        return {};
    }
}
