import{c as o,j as s}from"./index-Dt9l-mSr.js";const h=o(s.jsx("path",{d:"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"}),"Add");export{h as A};
