import{c as o,j as r}from"./index-Dt9l-mSr.js";const s=o(r.jsx("path",{d:"M8 5v14l11-7z"}),"PlayArrow");export{s as P};
