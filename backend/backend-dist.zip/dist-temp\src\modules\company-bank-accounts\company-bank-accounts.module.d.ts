export declare class CompanyBankAccountsModule {
}
