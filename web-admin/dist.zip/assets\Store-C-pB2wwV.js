import{c as t,j as v}from"./index-BiBF1DeO.js";const h=t(v.jsx("path",{d:"M20 4H4v2h16zm1 10v-2l-1-5H4l-1 5v2h1v6h10v-6h4v6h2v-6zm-9 4H6v-4h6z"}),"Store");export{h as S};
