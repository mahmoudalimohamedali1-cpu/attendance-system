export declare class DisciplinaryModule {
}
