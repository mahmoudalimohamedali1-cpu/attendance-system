import{c as n,j as a}from"./index-D5un0LxA.js";const r=n(a.jsx("path",{d:"M1 21h22L12 2zm12-3h-2v-2h2zm0-4h-2v-4h2z"}),"Warning");export{r as W};
