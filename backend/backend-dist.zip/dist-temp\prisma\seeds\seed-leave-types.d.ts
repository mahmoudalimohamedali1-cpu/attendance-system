export declare function seedLeaveTypes(companyId: string): Promise<void>;
export default seedLeaveTypes;
