import{aT as t}from"./index-D5un0LxA.js";function m(e,o){const a=t(e),r=t(o);return a.getTime()>r.getTime()}export{m as i};
