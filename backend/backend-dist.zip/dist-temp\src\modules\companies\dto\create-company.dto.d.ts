export declare class CreateCompanyDto {
    name: string;
    nameEn?: string;
    crNumber?: string;
    taxId?: string;
    logo?: string;
    address?: string;
    phone?: string;
    email?: string;
    website?: string;
}
