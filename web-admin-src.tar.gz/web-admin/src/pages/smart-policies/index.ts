export { default as SmartPoliciesPage } from './SmartPoliciesPage';
