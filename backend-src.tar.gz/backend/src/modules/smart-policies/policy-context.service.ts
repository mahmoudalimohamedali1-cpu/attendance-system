import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../common/prisma/prisma.service';

/**
 * السياق المُثرى للسياسة الذكية
 * يحتوي على كل البيانات المطلوبة لتنفيذ أي سياسة معقدة
 */
export interface EnrichedPolicyContext {
    // بيانات الموظف الأساسية
    employee: {
        id: string;
        name: string;
        email: string;
        companyId: string;
        hireDate: Date;
        tenure: {
            years: number;
            months: number;
            days: number;
            totalMonths: number;
        };
        department: string;
        departmentId: string;
        branch: string;
        branchId: string;
        jobTitle: string;
        jobTitleId: string;
        nationality: string;
        isSaudi: boolean;
    };

    // بيانات العقد والراتب
    contract: {
        id: string;
        basicSalary: number;
        totalSalary: number;
        housingAllowance: number;
        transportAllowance: number;
        otherAllowances: number;
        contractType: string;
        probationEndDate?: Date;
        isProbation: boolean;
        probationMonthsRemaining?: number;
    };

    // بيانات الحضور (الفترة الحالية)
    attendance: {
        currentPeriod: {
            presentDays: number;
            absentDays: number;
            lateDays: number;
            lateMinutes: number;
            earlyLeaveDays: number;
            overtimeHours: number;
            weekendWorkDays: number;
            holidayWorkDays: number;
            attendancePercentage: number;
            workingDays: number;
        };
        last3Months: {
            presentDays: number;
            absentDays: number;
            lateDays: number;
            lateMinutes: number;
            overtimeHours: number;
            attendancePercentage: number;
        };
        last6Months: {
            presentDays: number;
            absentDays: number;
            lateDays: number;
            lateMinutes: number;
            overtimeHours: number;
            attendancePercentage: number;
        };
        patterns: {
            lateStreak: number;
            absenceStreak: number;
            consecutivePresent: number;
        };
    };

    // بيانات الإجازات
    leaves: {
        currentMonth: {
            sickDays: number;
            annualDays: number;
            unpaidDays: number;
            totalDays: number;
            consecutiveSickDays: number;
        };
        balance: {
            annual: number;
            sick: number;
        };
        history: Array<{
            type: string;
            days: number;
            from: Date;
            to: Date;
        }>;
    };

    // بيانات العهد
    custody: {
        active: number;
        returned: number;
        lateReturns: number;
        totalValue: number;
        avgReturnDelay: number;
    };

    // بيانات السلف
    advances: {
        active: number;
        totalAmount: number;
        remainingAmount: number;
        monthlyDeduction: number;
        hasActiveAdvance: boolean;
    };

    // السجل التأديبي
    disciplinary: {
        totalCases: number;
        activeCases: number;
        activeWarnings: number;
        lastIncidentDate?: Date;
        daysSinceLastIncident?: number;
        penalties: Array<{
            type: string;
            amount?: number;
            date: Date;
        }>;
    };

    // الأداء والتقييمات والتارجت
    performance: {
        // التقييم الأخير (من 5)
        lastRating?: number;
        lastReviewDate?: Date;
        hasRecentReview: boolean;

        // نسبة تحقيق التارجت (مثلاً 105% = حقق أكتر من المطلوب)
        targetAchievement: number; // النسبة المئوية
        targetAmount: number;      // المبلغ المستهدف
        actualAmount: number;      // المبلغ المحقق

        // مستوى التحقيق للحوافز المتدرجة
        achievementLevel: 'BELOW' | 'MET' | 'EXCEEDED' | 'OUTSTANDING'; // أقل/مطابق/تجاوز/متميز
        isAbove100: boolean;       // حقق التارجت؟
        isAbove105: boolean;       // تجاوز 105%؟
        isAbove110: boolean;       // تجاوز 110%؟

        // مؤشرات الأداء الرئيسية (KPIs)
        kpis: {
            salesCount?: number;       // عدد المبيعات
            dealsClosedCount?: number; // عدد الصفقات المُغلقة
            customersAcquired?: number;// عملاء جدد
            customerSatisfaction?: number; // رضا العملاء
        };
    };

    // بيانات القسم/الفريق
    department: {
        id: string;
        name: string;
        totalEmployees: number;
        departmentAttendance: number;
    };

    // بيانات الفرع
    branch: {
        id: string;
        name: string;
        totalEmployees: number;
    };

    // بيانات تتبع الموقع (Geofencing)
    location: {
        // إجمالي الوقت خارج نطاق الشركة بالدقائق
        minutesOutsideGeofence: number;
        // عدد مرات الخروج من النطاق
        geofenceExitCount: number;
        // أطول فترة متواصلة خارج النطاق بالدقائق
        longestOutsideDuration: number;
        // هل تجاوز الحد المسموح (15 دقيقة)؟
        exceededAllowedTime: boolean;
        // الوقت الزائد عن المسموح (15 دقيقة) بالدقائق
        excessMinutes: number;
    };

    // بيانات الشركة
    company: {
        id: string;
        currentPeriod: {
            month: number;
            year: number;
            workingDays: number;
        };
        policies: {
            probationPeriodMonths: number;
            weekendDays: string[];
        };
    };

    // الفترة الحالية
    period: {
        month: number;
        year: number;
        startDate: Date;
        endDate: Date;
    };

    // حقول مخصصة ديناميكية - للبيانات الإضافية التي لا تنتمي لفئة محددة
    // يمكن للنظام إضافة حقول جديدة هنا تلقائياً
    customFields: {
        [key: string]: any;
    };

    // قائمة الحقول المتاحة في النظام - للتحقق من صحة السياسات
    _availableFields: string[];
}

@Injectable()
export class PolicyContextService {
    private readonly logger = new Logger(PolicyContextService.name);

    constructor(private readonly prisma: PrismaService) { }

    /**
     * إثراء السياق بكل البيانات المطلوبة
     */
    async enrichContext(
        employeeId: string,
        month: number,
        year: number
    ): Promise<EnrichedPolicyContext> {
        this.logger.log(`Enriching context for employee ${employeeId}, period ${year}-${month}`);

        // جلب بيانات الموظف الأساسية
        const user = await this.prisma.user.findUnique({
            where: { id: employeeId },
            include: {
                department: true,
                branch: true,
                jobTitleRef: true,
            } as any,
        });

        if (!user) {
            throw new Error(`Employee ${employeeId} not found`);
        }

        const hireDate = user.hireDate || user.createdAt;
        const tenure = this.calculateTenure(hireDate);
        const period = this.getPeriodDates(month, year);
        const workingDays = this.calculateWorkingDays(month, year);

        // جلب بيانات العقد
        const contract = await this.getContractData(employeeId);

        // جلب بيانات الحضور
        const attendance = await this.getAttendanceData(employeeId, month, year, workingDays);

        return {
            employee: {
                id: user.id,
                name: `${user.firstName} ${user.lastName}`,
                email: user.email,
                companyId: user.companyId,
                hireDate,
                tenure,
                department: (user as any).department?.nameAr || (user as any).department?.name || 'غير محدد',
                departmentId: user.departmentId || '',
                branch: (user as any).branch?.nameAr || (user as any).branch?.name || 'غير محدد',
                branchId: user.branchId || '',
                jobTitle: (user as any).jobTitleRef?.titleAr || (user as any).jobTitleRef?.name || user.jobTitle || 'غير محدد',
                jobTitleId: user.jobTitleId || '',
                nationality: user.nationality || 'غير محدد',
                isSaudi: user.nationality === 'SA' || user.nationality === 'Saudi',
                // حقول الراتب - مهمة جداً للسياسات
                salary: Number(user.salary) || 0,
                basicSalary: Number(user.salary) || 0, // alias for compatibility
            },
            contract,
            attendance,
            leaves: this.getDefaultLeaves(),
            custody: this.getDefaultCustody(),
            advances: this.getDefaultAdvances(),
            disciplinary: await this.getDisciplinaryData(employeeId),
            performance: await this.getPerformanceData(employeeId, month, year),
            department: {
                id: user.departmentId || '',
                name: (user as any).department?.nameAr || (user as any).department?.name || 'غير محدد',
                totalEmployees: 0,
                departmentAttendance: 0,
            },
            branch: {
                id: user.branchId || '',
                name: (user as any).branch?.nameAr || (user as any).branch?.name || 'غير محدد',
                totalEmployees: 0,
            },
            location: await this.getLocationTrackingData(employeeId, month, year),
            company: {
                id: user.companyId,
                currentPeriod: {
                    month,
                    year,
                    workingDays,
                },
                policies: {
                    probationPeriodMonths: 3,
                    weekendDays: ['FRIDAY', 'SATURDAY'],
                },
            },
            period: {
                month,
                year,
                ...period,
            },
            // حقول مخصصة ديناميكية
            customFields: await this.getCustomFields(employeeId, user.companyId || '', month, year),
            // قائمة كل الحقول المتاحة
            _availableFields: this.getAllAvailableFields(),
        } as EnrichedPolicyContext;
    }

    /**
     * جلب الحقول المخصصة للموظف
     */
    private async getCustomFields(employeeId: string, companyId: string, month: number, year: number): Promise<Record<string, any>> {
        try {
            // جلب الحقول المخصصة من جدول CustomFieldValue
            const customValues = await (this.prisma as any).customFieldValue?.findMany?.({
                where: {
                    OR: [
                        { employeeId },
                        { entityType: 'COMPANY', entityId: companyId }
                    ]
                },
                include: { field: true }
            }) || [];

            const result: Record<string, any> = {};
            for (const cv of customValues) {
                const fieldName = cv.field?.name || cv.fieldId;
                result[fieldName] = cv.value;
            }

            // إضافة بيانات إضافية يمكن أن تكون مفيدة
            // مثل: المبيعات، الإنتاجية، إلخ
            const salesData = await this.getSalesData(employeeId, month, year);
            if (salesData) {
                result.sales = salesData;
            }

            return result;
        } catch {
            return {};
        }
    }

    /**
     * جلب بيانات المبيعات (إذا وجدت)
     */
    private async getSalesData(employeeId: string, month: number, year: number): Promise<any> {
        try {
            const { startDate, endDate } = this.getPeriodDates(month, year);

            // جرب من جدول Sales أو SalesRecord
            const sales = await (this.prisma as any).sale?.findMany?.({
                where: {
                    salesPersonId: employeeId,
                    createdAt: { gte: startDate, lte: endDate }
                }
            }) || [];

            if (sales.length === 0) return null;

            const totalAmount = sales.reduce((sum: number, s: any) => sum + (Number(s.amount) || 0), 0);
            const count = sales.length;

            return {
                count,
                totalAmount,
                averageAmount: count > 0 ? totalAmount / count : 0,
            };
        } catch {
            return null;
        }
    }

    /**
     * قائمة كل الحقول المتاحة في النظام
     */
    getAllAvailableFields(): string[] {
        return [
            // الموظف
            'employee.id', 'employee.name', 'employee.tenure.years', 'employee.tenure.months',
            'employee.department', 'employee.branch', 'employee.jobTitle', 'employee.isSaudi',
            // العقد
            'contract.basicSalary', 'contract.totalSalary', 'contract.isProbation',
            'contract.housingAllowance', 'contract.transportAllowance',
            // الحضور
            'attendance.currentPeriod.presentDays', 'attendance.currentPeriod.absentDays',
            'attendance.currentPeriod.lateDays', 'attendance.currentPeriod.lateMinutes',
            'attendance.currentPeriod.overtimeHours', 'attendance.currentPeriod.attendancePercentage',
            'attendance.patterns.lateStreak', 'attendance.patterns.consecutivePresent',
            // الإجازات
            'leaves.currentMonth.sickDays', 'leaves.currentMonth.annualDays', 'leaves.balance.annual',
            // العهد والسلف
            'custody.active', 'custody.lateReturns', 'advances.hasActiveAdvance', 'advances.remainingAmount',
            // التأديب
            'disciplinary.activeCases', 'disciplinary.activeWarnings',
            // الموقع
            'location.minutesOutsideGeofence', 'location.excessMinutes', 'location.exceededAllowedTime',
            // الأداء
            'performance.targetAchievement', 'performance.isAbove100', 'performance.isAbove105',
            'performance.achievementLevel', 'performance.lastRating',
            // المخصصة
            'customFields.*',
        ];
    }

    /**
     * فحص إذا كان الحقل موجود في النظام
     */
    isFieldAvailable(fieldPath: string): boolean {
        const availableFields = this.getAllAvailableFields();
        // فحص مباشر
        if (availableFields.includes(fieldPath)) return true;
        // فحص wildcard (customFields.*)
        if (fieldPath.startsWith('customFields.')) return true;
        // فحص جزئي
        return availableFields.some(f => fieldPath.startsWith(f.replace('.*', '')));
    }

    /**
     * اقتراح الحقول المفقودة في السياسة
     */
    detectMissingFields(conditions: any[], actions: any[]): string[] {
        const missingFields: string[] = [];
        const allFields = this.getAllAvailableFields();

        // فحص الشروط
        for (const condition of conditions) {
            const field = condition.field || '';
            if (field && !this.isFieldAvailable(field)) {
                missingFields.push(field);
            }
        }

        // فحص المعادلات في الإجراءات
        for (const action of actions) {
            if (action.valueType === 'FORMULA' && action.value) {
                // استخراج الحقول من المعادلة
                const formulaFields = this.extractFieldsFromFormula(action.value);
                for (const field of formulaFields) {
                    if (!this.isFieldAvailable(field)) {
                        missingFields.push(field);
                    }
                }
            }
        }

        return [...new Set(missingFields)]; // إزالة التكرار
    }

    /**
     * استخراج أسماء الحقول من معادلة
     */
    private extractFieldsFromFormula(formula: string): string[] {
        const fieldPattern = /([a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)+)/g;
        return formula.match(fieldPattern) || [];
    }

    private async getContractData(employeeId: string) {
        try {
            const contract = await this.prisma.contract.findFirst({
                where: {
                    userId: employeeId,
                    status: 'ACTIVE',
                } as any,
                orderBy: { startDate: 'desc' },
            });

            if (!contract) {
                return this.getDefaultContract();
            }

            const basicSalary = Number(contract.basicSalary);
            const housingAllowance = Number(contract.housingAllowance || 0);
            const transportAllowance = Number(contract.transportAllowance || 0);
            const otherAllowances = Number(contract.otherAllowances || 0);
            const totalSalary = basicSalary + housingAllowance + transportAllowance + otherAllowances;

            const now = new Date();
            const isProbation = contract.probationEndDate ? contract.probationEndDate > now : false;

            return {
                id: contract.id,
                basicSalary,
                totalSalary,
                housingAllowance,
                transportAllowance,
                otherAllowances,
                contractType: contract.type,
                probationEndDate: contract.probationEndDate || undefined,
                isProbation,
                probationMonthsRemaining: undefined,
            };
        } catch {
            return this.getDefaultContract();
        }
    }

    private getDefaultContract() {
        return {
            id: '',
            basicSalary: 0,
            totalSalary: 0,
            housingAllowance: 0,
            transportAllowance: 0,
            otherAllowances: 0,
            contractType: 'FULL_TIME',
            isProbation: false,
        };
    }

    private async getAttendanceData(employeeId: string, month: number, year: number, workingDays: number) {
        try {
            const { startDate, endDate } = this.getPeriodDates(month, year);

            const records = await this.prisma.attendance.findMany({
                where: {
                    userId: employeeId,
                    checkIn: {
                        gte: startDate,
                        lte: endDate,
                    },
                } as any,
            });

            let presentDays = 0;
            let lateDays = 0;
            let lateMinutes = 0;
            let overtimeHours = 0;

            for (const record of records) {
                const rec = record as any;
                if (rec.status === 'PRESENT' || rec.status === 'LATE') {
                    presentDays++;
                }
                if (rec.status === 'LATE') {
                    lateDays++;
                    lateMinutes += Number(rec.lateMinutes || 0);
                }
                overtimeHours += Number(rec.overtimeHours || 0);
            }

            const absentDays = Math.max(0, workingDays - presentDays);
            const attendancePercentage = workingDays > 0 ? (presentDays / workingDays) * 100 : 0;

            const currentPeriod = {
                presentDays,
                absentDays,
                lateDays,
                lateMinutes,
                earlyLeaveDays: 0,
                overtimeHours,
                weekendWorkDays: 0,
                holidayWorkDays: 0,
                attendancePercentage,
                workingDays,
            };

            return {
                currentPeriod,
                last3Months: { ...currentPeriod, attendancePercentage: 0 },
                last6Months: { ...currentPeriod, attendancePercentage: 0 },
                patterns: {
                    lateStreak: 0,
                    absenceStreak: 0,
                    consecutivePresent: 0,
                },
            };
        } catch {
            return this.getDefaultAttendance(workingDays);
        }
    }

    private getDefaultAttendance(workingDays: number) {
        const defaultPeriod = {
            presentDays: 0,
            absentDays: 0,
            lateDays: 0,
            lateMinutes: 0,
            earlyLeaveDays: 0,
            overtimeHours: 0,
            weekendWorkDays: 0,
            holidayWorkDays: 0,
            attendancePercentage: 0,
            workingDays,
        };
        return {
            currentPeriod: defaultPeriod,
            last3Months: { ...defaultPeriod, attendancePercentage: 0 },
            last6Months: { ...defaultPeriod, attendancePercentage: 0 },
            patterns: {
                lateStreak: 0,
                absenceStreak: 0,
                consecutivePresent: 0,
            },
        };
    }

    private getDefaultLeaves() {
        return {
            currentMonth: {
                sickDays: 0,
                annualDays: 0,
                unpaidDays: 0,
                totalDays: 0,
                consecutiveSickDays: 0,
            },
            balance: { annual: 0, sick: 0 },
            history: [],
        };
    }

    private getDefaultCustody() {
        return {
            active: 0,
            returned: 0,
            lateReturns: 0,
            totalValue: 0,
            avgReturnDelay: 0,
        };
    }

    private getDefaultAdvances() {
        return {
            active: 0,
            totalAmount: 0,
            remainingAmount: 0,
            monthlyDeduction: 0,
            hasActiveAdvance: false,
        };
    }

    private async getDisciplinaryData(employeeId: string) {
        try {
            const cases = await this.prisma.disciplinaryCase.findMany({
                where: { employeeId },
                orderBy: { incidentDate: 'desc' },
            });

            const totalCases = cases.length;
            const activeCases = cases.filter(c => c.status !== 'FINALIZED_APPROVED' && c.status !== 'FINALIZED_CANCELLED').length;

            const oneYearAgo = new Date();
            oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);

            const activeWarnings = cases.filter(c =>
                c.decisionType &&
                ['WARNING', 'FIRST_WARNING', 'SECOND_WARNING', 'FINAL_WARNING_TERMINATION'].includes(c.decisionType) &&
                c.incidentDate > oneYearAgo
            ).length;

            const lastIncidentDate = cases[0]?.incidentDate;
            const daysSinceLastIncident = lastIncidentDate
                ? Math.floor((Date.now() - lastIncidentDate.getTime()) / (1000 * 60 * 60 * 24))
                : undefined;

            return {
                totalCases,
                activeCases,
                activeWarnings,
                lastIncidentDate,
                daysSinceLastIncident,
                penalties: [],
            };
        } catch {
            return {
                totalCases: 0,
                activeCases: 0,
                activeWarnings: 0,
                penalties: [],
            };
        }
    }

    private calculateTenure(hireDate: Date): {
        years: number;
        months: number;
        days: number;
        totalMonths: number;
    } {
        const now = new Date();
        const diff = now.getTime() - hireDate.getTime();
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const years = Math.floor(days / 365);
        const months = Math.floor((days % 365) / 30);
        const remainingDays = days % 30;
        const totalMonths = Math.floor(days / 30);

        return {
            years,
            months,
            days: remainingDays,
            totalMonths,
        };
    }

    private getPeriodDates(month: number, year: number): { startDate: Date; endDate: Date } {
        const startDate = new Date(year, month - 1, 1);
        const endDate = new Date(year, month, 0, 23, 59, 59);
        return { startDate, endDate };
    }

    private calculateWorkingDays(month: number, year: number): number {
        const daysInMonth = new Date(year, month, 0).getDate();
        const weekends = Math.floor(daysInMonth / 7) * 2;
        return daysInMonth - weekends;
    }

    /**
     * جلب بيانات تتبع الموقع (Geofencing)
     * يحسب الوقت الذي قضاه الموظف خارج نطاق الشركة
     */
    private async getLocationTrackingData(employeeId: string, month: number, year: number) {
        const ALLOWED_MINUTES_OUTSIDE = 15; // الوقت المسموح خارج النطاق

        try {
            const { startDate, endDate } = this.getPeriodDates(month, year);

            // جلب سجلات تتبع الموقع من قاعدة البيانات
            const locationRecords = await (this.prisma as any).locationLog?.findMany?.({
                where: {
                    userId: employeeId,
                    timestamp: {
                        gte: startDate,
                        lte: endDate,
                    },
                    isWithinGeofence: false, // خارج النطاق فقط
                },
                orderBy: { timestamp: 'asc' },
            }) || [];

            // إذا لم يوجد جدول LocationLog، جرب GeofenceEvent
            let minutesOutsideGeofence = 0;
            let geofenceExitCount = 0;
            let longestOutsideDuration = 0;

            if (locationRecords.length > 0) {
                // حساب الوقت خارج النطاق
                for (const record of locationRecords) {
                    const duration = Number(record.durationOutside || record.duration || 1);
                    minutesOutsideGeofence += duration;
                    geofenceExitCount++;
                    if (duration > longestOutsideDuration) {
                        longestOutsideDuration = duration;
                    }
                }
            } else {
                // جرب جدول GeofenceEvent أو Attendance مع حقل geofence
                const geofenceEvents = await (this.prisma as any).geofenceEvent?.findMany?.({
                    where: {
                        userId: employeeId,
                        eventType: 'EXIT',
                        timestamp: {
                            gte: startDate,
                            lte: endDate,
                        },
                    },
                }) || [];

                for (const event of geofenceEvents) {
                    const duration = Number(event.durationMinutes || 5); // افتراضي 5 دقائق
                    minutesOutsideGeofence += duration;
                    geofenceExitCount++;
                    if (duration > longestOutsideDuration) {
                        longestOutsideDuration = duration;
                    }
                }
            }

            const exceededAllowedTime = minutesOutsideGeofence > ALLOWED_MINUTES_OUTSIDE;
            const excessMinutes = Math.max(0, minutesOutsideGeofence - ALLOWED_MINUTES_OUTSIDE);

            return {
                minutesOutsideGeofence,
                geofenceExitCount,
                longestOutsideDuration,
                exceededAllowedTime,
                excessMinutes,
            };
        } catch (error) {
            this.logger.warn(`Error fetching location data for ${employeeId}: ${error.message}`);
            return {
                minutesOutsideGeofence: 0,
                geofenceExitCount: 0,
                longestOutsideDuration: 0,
                exceededAllowedTime: false,
                excessMinutes: 0,
            };
        }
    }

    /**
     * جلب بيانات الأداء والتارجت
     * يحسب نسبة تحقيق الهدف ومستوى الإنجاز للحوافز المتدرجة
     */
    private async getPerformanceData(employeeId: string, month: number, year: number) {
        try {
            const { startDate, endDate } = this.getPeriodDates(month, year);

            // جلب أهداف الأداء والتحقيق من قاعدة البيانات
            let targetAmount = 0;
            let actualAmount = 0;

            // جرب جلب من PerformanceGoal أو SalesTarget
            const performanceGoal = await (this.prisma as any).performanceGoal?.findFirst?.({
                where: {
                    userId: employeeId,
                    periodStart: { lte: endDate },
                    periodEnd: { gte: startDate },
                },
            });

            if (performanceGoal) {
                targetAmount = Number(performanceGoal.targetAmount || performanceGoal.targetValue || 0);
                actualAmount = Number(performanceGoal.actualAmount || performanceGoal.actualValue || 0);
            } else {
                // جرب من SalesTarget
                const salesTarget = await (this.prisma as any).salesTarget?.findFirst?.({
                    where: {
                        userId: employeeId,
                        month: month,
                        year: year,
                    },
                });

                if (salesTarget) {
                    targetAmount = Number(salesTarget.targetAmount || 0);
                    actualAmount = Number(salesTarget.achieved || salesTarget.actualAmount || 0);
                }
            }

            // حساب نسبة التحقيق
            const targetAchievement = targetAmount > 0
                ? Math.round((actualAmount / targetAmount) * 100)
                : 0;

            // تحديد مستوى التحقيق
            let achievementLevel: 'BELOW' | 'MET' | 'EXCEEDED' | 'OUTSTANDING' = 'BELOW';
            if (targetAchievement >= 110) {
                achievementLevel = 'OUTSTANDING';
            } else if (targetAchievement >= 105) {
                achievementLevel = 'EXCEEDED';
            } else if (targetAchievement >= 100) {
                achievementLevel = 'MET';
            }

            // الحصول على آخر تقييم
            const lastReview = await (this.prisma as any).performanceReview?.findFirst?.({
                where: { userId: employeeId },
                orderBy: { reviewDate: 'desc' },
            });

            return {
                lastRating: lastReview?.rating || undefined,
                lastReviewDate: lastReview?.reviewDate || undefined,
                hasRecentReview: !!lastReview,
                targetAchievement,
                targetAmount,
                actualAmount,
                achievementLevel,
                isAbove100: targetAchievement >= 100,
                isAbove105: targetAchievement >= 105,
                isAbove110: targetAchievement >= 110,
                kpis: {
                    salesCount: undefined,
                    dealsClosedCount: undefined,
                    customersAcquired: undefined,
                    customerSatisfaction: undefined,
                },
            };
        } catch (error) {
            this.logger.warn(`Error fetching performance data for ${employeeId}: ${error.message}`);
            return {
                hasRecentReview: false,
                targetAchievement: 0,
                targetAmount: 0,
                actualAmount: 0,
                achievementLevel: 'BELOW' as const,
                isAbove100: false,
                isAbove105: false,
                isAbove110: false,
                kpis: {},
            };
        }
    }
}
