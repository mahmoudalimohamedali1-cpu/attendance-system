export declare class AuditLogsModule {
}
