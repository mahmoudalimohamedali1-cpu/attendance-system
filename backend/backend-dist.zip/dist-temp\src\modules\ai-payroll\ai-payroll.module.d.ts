export declare class AiPayrollModule {
}
