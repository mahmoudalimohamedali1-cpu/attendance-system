export declare class LeavesModule {
}
