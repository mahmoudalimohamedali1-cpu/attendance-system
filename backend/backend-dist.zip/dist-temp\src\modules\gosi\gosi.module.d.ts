export declare class GosiModule {
}
