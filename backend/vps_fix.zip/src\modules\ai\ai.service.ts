import { Injectable, Logger } from '@nestjs/common';
import Anthropic from '@anthropic-ai/sdk';

/**
 * 🤖 AI Service - Claude (Anthropic) Implementation
 * 
 * Switched from Gemini to Claude for better Arabic support
 * and more reliable JSON responses.
 * 
 * Models available:
 * - claude-3-5-sonnet-20241022 (recommended - fast & smart)
 * - claude-3-opus-20240229 (most capable)
 * - claude-3-haiku-20240307 (fastest)
 */

@Injectable()
export class AiService {
    private readonly logger = new Logger(AiService.name);
    private anthropic: Anthropic | null = null;

    // Claude models - using latest sonnet
    private readonly models = [
        'claude-sonnet-4-20250514',     // Latest Sonnet 4
        'claude-3-5-sonnet-20241022',   // Stable sonnet
    ];

    constructor() {
        const apiKey = process.env.CLAUDE_API_KEY || process.env.ANTHROPIC_API_KEY;
        if (apiKey) {
            this.anthropic = new Anthropic({ apiKey });
            this.logger.log('Claude AI (Anthropic) initialized successfully ✅');
        } else {
            this.logger.warn('CLAUDE_API_KEY not found - AI features will be disabled');
        }
    }

    isAvailable(): boolean {
        return this.anthropic !== null;
    }

    async generateContent(prompt: string, systemInstruction?: string): Promise<string> {
        if (!this.anthropic) {
            throw new Error('AI service is not available. Please configure CLAUDE_API_KEY.');
        }

        let lastError: any = null;

        for (const modelName of this.models) {
            try {
                this.logger.log(`Attempting AI generation with Claude model: ${modelName}`);

                const response = await this.anthropic.messages.create({
                    model: modelName,
                    max_tokens: 4096,
                    system: systemInstruction || 'أنت مساعد ذكي لنظام الموارد البشرية. أجب بالعربية بشكل مختصر ومفيد.',
                    messages: [
                        {
                            role: 'user',
                            content: prompt
                        }
                    ]
                });

                // Extract text from Claude response
                const textContent = response.content.find(c => c.type === 'text');
                if (textContent && textContent.type === 'text') {
                    this.logger.log(`Successfully generated content using Claude ${modelName}`);
                    return textContent.text;
                }

                throw new Error('Claude returned empty response');
            } catch (error: any) {
                this.logger.warn(`Model ${modelName} failed: ${error.message || error}`);
                lastError = error;
                // Always try next model on any error
                continue;
            }
        }

        this.logger.error('All Claude models failed to generate content');
        throw lastError || new Error('Failed to generate content with Claude');
    }

    parseJsonResponse<T>(response: string | undefined | null): T {
        if (!response) {
            throw new Error('AI returned empty response');
        }

        let cleaned = response.trim();
        if (cleaned.startsWith('```json')) {
            cleaned = cleaned.slice(7);
        } else if (cleaned.startsWith('```')) {
            cleaned = cleaned.slice(3);
        }
        if (cleaned.endsWith('```')) {
            cleaned = cleaned.slice(0, -3);
        }
        cleaned = cleaned.trim();

        try {
            return JSON.parse(cleaned) as T;
        } catch (error) {
            this.logger.warn(`Initial JSON parse failed, attempting recovery...`);

            // محاولة إصلاح JSON المقطوع
            try {
                // إزالة أي نص إضافي بعد الـ JSON
                const jsonEndIndex = this.findJsonEnd(cleaned);
                if (jsonEndIndex > 0) {
                    const fixedJson = cleaned.substring(0, jsonEndIndex + 1);
                    return JSON.parse(fixedJson) as T;
                }
            } catch (e) {
                // فشل الإصلاح
            }

            // محاولة إصلاح JSON ناقص بإضافة الإغلاقات
            try {
                const repaired = this.repairIncompleteJson(cleaned);
                return JSON.parse(repaired) as T;
            } catch (e) {
                this.logger.error(`Failed to parse JSON response: ${cleaned.substring(0, 300)}...`);
                throw new Error('Failed to parse AI response as JSON');
            }
        }
    }

    /**
     * البحث عن نهاية الـ JSON
     */
    private findJsonEnd(json: string): number {
        let braceCount = 0;
        let inString = false;
        let escapeNext = false;

        for (let i = 0; i < json.length; i++) {
            const char = json[i];

            if (escapeNext) {
                escapeNext = false;
                continue;
            }

            if (char === '\\') {
                escapeNext = true;
                continue;
            }

            if (char === '"') {
                inString = !inString;
                continue;
            }

            if (inString) continue;

            if (char === '{') braceCount++;
            if (char === '}') {
                braceCount--;
                if (braceCount === 0) return i;
            }
        }

        return -1;
    }

    /**
     * محاولة إصلاح JSON ناقص
     */
    private repairIncompleteJson(json: string): string {
        let repaired = json;

        // حساب الأقواس المفتوحة
        let braceCount = 0;
        let bracketCount = 0;
        let inString = false;

        for (const char of repaired) {
            if (char === '"' && repaired[repaired.indexOf(char) - 1] !== '\\') {
                inString = !inString;
            }
            if (!inString) {
                if (char === '{') braceCount++;
                if (char === '}') braceCount--;
                if (char === '[') bracketCount++;
                if (char === ']') bracketCount--;
            }
        }

        // لو في string مفتوح، أغلقه
        if (inString) {
            repaired += '"';
        }

        // إغلاق الأقواس المفتوحة
        while (bracketCount > 0) {
            repaired += ']';
            bracketCount--;
        }
        while (braceCount > 0) {
            repaired += '}';
            braceCount--;
        }

        return repaired;
    }
}

