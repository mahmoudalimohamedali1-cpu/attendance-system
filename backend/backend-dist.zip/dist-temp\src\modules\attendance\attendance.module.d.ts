export declare class AttendanceModule {
}
