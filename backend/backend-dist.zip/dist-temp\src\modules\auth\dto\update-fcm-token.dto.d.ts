export declare class UpdateFcmTokenDto {
    fcmToken: string;
}
