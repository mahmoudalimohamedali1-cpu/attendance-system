import { Module } from '@nestjs/common';
import { PrismaModule } from '../../common/prisma/prisma.module';
import { PerformanceReviewsController } from './performance-reviews.controller';
import { PerformanceReviewsService } from './performance-reviews.service';
import { AiGoalAssistantService } from './ai-goal-assistant.service';

@Module({
    imports: [PrismaModule],
    controllers: [PerformanceReviewsController],
    providers: [PerformanceReviewsService, AiGoalAssistantService],
    exports: [PerformanceReviewsService, AiGoalAssistantService],
})
export class PerformanceReviewsModule { }
