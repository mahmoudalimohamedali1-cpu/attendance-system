export declare class AdvancesModule {
}
