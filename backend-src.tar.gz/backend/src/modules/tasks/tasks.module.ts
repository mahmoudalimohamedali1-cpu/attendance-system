import { Module } from '@nestjs/common';
import { TasksService } from './tasks.service';
import { TasksController, TaskCategoriesController, TaskTemplatesController } from './tasks.controller';
import { PrismaModule } from '../../common/prisma/prisma.module';
import { NotificationsModule } from '../notifications/notifications.module';
import { RecurringTasksScheduler } from './recurring-tasks.scheduler';

@Module({
    imports: [PrismaModule, NotificationsModule],
    controllers: [TasksController, TaskCategoriesController, TaskTemplatesController],
    providers: [TasksService, RecurringTasksScheduler],
    exports: [TasksService],
})
export class TasksModule { }

