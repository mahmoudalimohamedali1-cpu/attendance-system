export declare class CreateGosiConfigDto {
    employeeRate: number;
    employerRate: number;
    sanedRate: number;
    hazardRate: number;
    maxCapAmount: number;
    isSaudiOnly?: boolean;
    isActive?: boolean;
}
