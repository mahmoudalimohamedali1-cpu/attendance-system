export declare class AiChatModule {
}
