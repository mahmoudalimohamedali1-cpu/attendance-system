import{c as e,j as o}from"./index-Dpjqn_H_.js";const t=e(o.jsx("path",{d:"M19 13H5v-2h14z"}),"Remove");export{t as R};
