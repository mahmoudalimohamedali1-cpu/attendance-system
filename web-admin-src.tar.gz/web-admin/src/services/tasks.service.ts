import { api } from './api.service';

export interface Task {
    id: string;
    title: string;
    description?: string;
    status: 'BACKLOG' | 'TODO' | 'IN_PROGRESS' | 'PENDING_REVIEW' | 'IN_REVIEW' | 'APPROVED' | 'REJECTED' | 'BLOCKED' | 'COMPLETED' | 'CANCELLED';
    priority: 'URGENT' | 'HIGH' | 'MEDIUM' | 'LOW';
    categoryId?: string;
    category?: TaskCategory;
    dueDate?: string;
    startDate?: string;
    completedAt?: string;
    createdById: string;
    createdBy: UserBrief;
    assigneeId?: string;
    assignee?: UserBrief;
    // Workflow roles
    reviewerId?: string;
    reviewer?: UserBrief;
    approverId?: string;
    approver?: UserBrief;
    // Workflow tracking
    reviewRequestedAt?: string;
    reviewedAt?: string;
    approvedAt?: string;
    rejectedAt?: string;
    rejectionReason?: string;
    // Other
    progress: number;
    tags: string[];
    recurrenceType?: string;
    checklists: TaskChecklist[];
    _count?: { comments: number; attachments: number };
    createdAt: string;
    updatedAt: string;
}

export interface UserBrief {
    id: string;
    firstName: string;
    lastName: string;
    avatar?: string;
    email?: string;
}

export interface TaskCategory {
    id: string;
    name: string;
    nameEn?: string;
    color: string;
    icon?: string;
    _count?: { tasks: number };
}

export interface TaskTemplate {
    id: string;
    name: string;
    nameEn?: string;
    description?: string;
    category?: TaskCategory;
    defaultPriority: string;
    defaultDueDays?: number;
    workflowType?: string;
    checklistTemplate?: any[];
}

export interface TaskChecklist {
    id: string;
    title: string;
    order: number;
    items: TaskChecklistItem[];
}

export interface TaskChecklistItem {
    id: string;
    content: string;
    isCompleted: boolean;
    order: number;
}

export interface TaskComment {
    id: string;
    content: string;
    author: UserBrief;
    mentions: string[];
    createdAt: string;
}

export interface TaskTimeLog {
    id: string;
    startTime: string;
    endTime?: string;
    duration?: number;
    description?: string;
    user: UserBrief;
}

export interface TaskQuery {
    search?: string;
    status?: string;
    priority?: string;
    categoryId?: string;
    assigneeId?: string;
    createdById?: string;
    dueDateFrom?: string;
    dueDateTo?: string;
    tags?: string;
    page?: number;
    limit?: number;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
}

export interface KanbanBoard {
    BACKLOG: Task[];
    TODO: Task[];
    IN_PROGRESS: Task[];
    IN_REVIEW: Task[];
    BLOCKED: Task[];
    COMPLETED: Task[];
}

export interface TaskStats {
    total: number;
    byStatus: Record<string, number>;
    byPriority: Record<string, number>;
    overdue: number;
}

// ============ TASKS API ============

export const tasksApi = {
    // Tasks CRUD
    getTasks: (params?: TaskQuery) => api.get<{ data: Task[]; meta: any }>('/tasks', { params }),
    getTask: (id: string) => api.get<Task>(`/tasks/${id}`),
    createTask: (data: Partial<Task>) => api.post<Task>('/tasks', data),
    updateTask: (id: string, data: Partial<Task>) => api.patch<Task>(`/tasks/${id}`, data),
    deleteTask: (id: string) => api.delete(`/tasks/${id}`),

    // Kanban
    getKanban: (categoryId?: string, myTasks?: boolean) =>
        api.get<KanbanBoard>('/tasks/kanban', { params: { categoryId, myTasks } }),
    reorderTask: (id: string, status: string, order: number) =>
        api.patch(`/tasks/${id}/reorder`, { status, order }),

    // Stats
    getStats: (myStats?: boolean) => api.get<TaskStats>('/tasks/stats', { params: { myStats } }),

    // Checklists
    addChecklist: (taskId: string, title: string) =>
        api.post<TaskChecklist>(`/tasks/${taskId}/checklists`, { title }),
    addChecklistItem: (checklistId: string, content: string) =>
        api.post<TaskChecklistItem>(`/tasks/checklists/${checklistId}/items`, { content }),
    toggleChecklistItem: (itemId: string, isCompleted: boolean) =>
        api.patch(`/tasks/checklist-items/${itemId}/toggle`, { isCompleted }),
    deleteChecklistItem: (itemId: string) =>
        api.delete(`/tasks/checklist-items/${itemId}`),

    // Comments
    addComment: (taskId: string, content: string, mentions?: string[]) =>
        api.post<TaskComment>(`/tasks/${taskId}/comments`, { content, mentions }),
    deleteComment: (commentId: string) => api.delete(`/tasks/comments/${commentId}`),

    // Time Logs
    addTimeLog: (taskId: string, data: { startTime: string; endTime?: string; duration?: number; description?: string }) =>
        api.post<TaskTimeLog>(`/tasks/${taskId}/time-logs`, data),

    // Attachments
    uploadAttachment: (taskId: string, file: File) => {
        const formData = new FormData();
        formData.append('file', file);
        return api.post(`/tasks/${taskId}/attachments`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
        });
    },
    deleteAttachment: (attachmentId: string) => api.delete(`/tasks/attachments/${attachmentId}`),

    // Watchers
    watch: (taskId: string) => api.post(`/tasks/${taskId}/watch`),
    unwatch: (taskId: string) => api.delete(`/tasks/${taskId}/watch`),

    // Workflow Actions
    requestReview: (taskId: string) => api.post(`/tasks/${taskId}/workflow/request-review`),
    startReview: (taskId: string) => api.post(`/tasks/${taskId}/workflow/start-review`),
    approve: (taskId: string, comment?: string) =>
        api.post(`/tasks/${taskId}/workflow/approve`, { comment }),
    reject: (taskId: string, reason: string) =>
        api.post(`/tasks/${taskId}/workflow/reject`, { reason }),
    requestChanges: (taskId: string, feedback: string) =>
        api.post(`/tasks/${taskId}/workflow/request-changes`, { feedback }),
    getApprovalHistory: (taskId: string) =>
        api.get(`/tasks/${taskId}/workflow/history`),

    // Evidence APIs
    submitEvidence: (taskId: string, data: {
        description?: string;
        fileUrl?: string;
        fileName?: string;
        fileType?: string;
        fileSize?: number;
        latitude?: number;
        longitude?: number;
        locationName?: string;
    }) => api.post(`/tasks/${taskId}/evidence`, data),
    getEvidences: (taskId: string) =>
        api.get(`/tasks/${taskId}/evidence`),
    verifyEvidence: (evidenceId: string, status: 'APPROVED' | 'REJECTED', comment?: string) =>
        api.post(`/tasks/evidence/${evidenceId}/verify`, { status, comment }),
    deleteEvidence: (evidenceId: string) =>
        api.delete(`/tasks/evidence/${evidenceId}`),

    // Dependencies
    addDependency: (blockedTaskId: string, blockingTaskId: string, type?: string) =>
        api.post(`/tasks/${blockedTaskId}/dependencies`, { blockingTaskId, type }),
    removeDependency: (blockedTaskId: string, blockingTaskId: string) =>
        api.delete(`/tasks/${blockedTaskId}/dependencies/${blockingTaskId}`),
    getDependencies: (taskId: string) =>
        api.get(`/tasks/${taskId}/dependencies`),
    updateDependencyType: (dependencyId: string, type: 'BLOCKS' | 'BLOCKED_BY' | 'RELATED' | 'DUPLICATES') =>
        api.patch(`/tasks/dependencies/${dependencyId}/type`, { type }),

    // Gantt Chart
    getGanttData: (categoryId?: string) =>
        api.get('/tasks/gantt', { params: categoryId ? { categoryId } : {} }),

    // Communication Hub
    getThreadedComments: (taskId: string) =>
        api.get(`/tasks/${taskId}/comments/threaded`),
    replyToComment: (commentId: string, content: string, mentions?: string[]) =>
        api.post(`/tasks/comments/${commentId}/reply`, { content, mentions }),
    addReaction: (commentId: string, emoji: string) =>
        api.post(`/tasks/comments/${commentId}/reactions`, { emoji }),
    removeReaction: (commentId: string, emoji: string) =>
        api.delete(`/tasks/comments/${commentId}/reactions/${emoji}`),
    getActivityFeed: (taskId: string, limit?: number) =>
        api.get(`/tasks/${taskId}/activity`, { params: limit ? { limit } : {} }),

    // Analytics
    getProductivityMetrics: (startDate?: string, endDate?: string) =>
        api.get('/tasks/analytics/metrics', { params: { startDate, endDate } }),
    getTeamPerformance: (startDate?: string, endDate?: string) =>
        api.get('/tasks/analytics/team', { params: { startDate, endDate } }),
    getTimeAnalytics: (startDate?: string, endDate?: string) =>
        api.get('/tasks/analytics/time', { params: { startDate, endDate } }),
    getTaskTrends: (days?: number) =>
        api.get('/tasks/analytics/trends', { params: days ? { days } : {} }),
    generateReport: (options: {
        startDate?: string;
        endDate?: string;
        categoryId?: string;
        assigneeId?: string;
        includeMetrics?: boolean;
        includeTeam?: boolean;
        includeTime?: boolean;
        includeTrends?: boolean;
    }) => api.post('/tasks/analytics/report', options),

    // Automations
    createAutomation: (data: {
        name: string;
        description?: string;
        trigger: string;
        triggerConfig?: any;
        action: string;
        actionConfig?: any;
        categoryId?: string;
        priority?: string;
    }) => api.post('/tasks/automations', data),
    getAutomations: () => api.get('/tasks/automations'),
    updateAutomation: (id: string, data: any) =>
        api.patch(`/tasks/automations/${id}`, data),
    deleteAutomation: (id: string) =>
        api.delete(`/tasks/automations/${id}`),
    toggleAutomation: (id: string) =>
        api.patch(`/tasks/automations/${id}/toggle`),
    getAutomationLogs: (id: string, limit?: number) =>
        api.get(`/tasks/automations/${id}/logs`, { params: limit ? { limit } : {} }),
};

// ============ CATEGORIES API ============

export const taskCategoriesApi = {
    getAll: () => api.get<TaskCategory[]>('/task-categories'),
    create: (data: { name: string; nameEn?: string; color?: string; icon?: string }) =>
        api.post<TaskCategory>('/task-categories', data),
    update: (id: string, data: Partial<TaskCategory>) =>
        api.patch<TaskCategory>(`/task-categories/${id}`, data),
    delete: (id: string) => api.delete(`/task-categories/${id}`),
};

// ============ TEMPLATES API ============

export const taskTemplatesApi = {
    getAll: () => api.get<TaskTemplate[]>('/task-templates'),
    create: (data: Partial<TaskTemplate>) => api.post<TaskTemplate>('/task-templates', data),
    update: (id: string, data: Partial<TaskTemplate>) =>
        api.patch<TaskTemplate>(`/task-templates/${id}`, data),
    delete: (id: string) => api.delete(`/task-templates/${id}`),
};
