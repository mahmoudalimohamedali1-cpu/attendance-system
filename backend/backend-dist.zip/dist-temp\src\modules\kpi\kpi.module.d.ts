export declare class KPIModule {
}
