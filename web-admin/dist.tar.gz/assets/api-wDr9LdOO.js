const E={BASE_URL:"http://72.61.239.170/api/v1",FILE_BASE_URL:"http://72.61.239.170/api/v1".replace("/api/v1",""),TIMEOUT:3e4,RETRY_ATTEMPTS:3,RETRY_DELAY:1e3};export{E as A};
