export declare class CustodyModule {
}
