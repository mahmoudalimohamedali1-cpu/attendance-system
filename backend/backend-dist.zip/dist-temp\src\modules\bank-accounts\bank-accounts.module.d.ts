export declare class BankAccountsModule {
}
