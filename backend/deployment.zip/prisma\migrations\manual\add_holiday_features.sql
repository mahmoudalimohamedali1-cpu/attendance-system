-- إضافة حقول جديدة لجدول العطلات
-- تاريخ: 2026-01-10

-- إضافة نوع التطبيق enum
DO $$ BEGIN
    CREATE TYPE "HolidayApplicationType" AS ENUM ('ALL', 'BRANCH', 'DEPARTMENT', 'SPECIFIC_EMPLOYEES', 'EXCLUDE_EMPLOYEES');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- إضافة الحقول الجديدة لجدول العطلات
ALTER TABLE "holidays" 
ADD COLUMN IF NOT EXISTS "is_paid" BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS "application_type" "HolidayApplicationType" DEFAULT 'ALL',
ADD COLUMN IF NOT EXISTS "count_as_work_day" BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS "overtime_multiplier" DECIMAL(3,2) DEFAULT 2.0,
ADD COLUMN IF NOT EXISTS "notes" TEXT;

-- إنشاء جدول تعيينات العطلات
CREATE TABLE IF NOT EXISTS "holiday_assignments" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "holiday_id" UUID NOT NULL REFERENCES "holidays"("id") ON DELETE CASCADE,
    "assignment_type" VARCHAR(50) NOT NULL,
    "branch_id" UUID,
    "department_id" UUID,
    "employee_id" UUID,
    "created_at" TIMESTAMP DEFAULT NOW(),
    UNIQUE("holiday_id", "assignment_type", "branch_id", "department_id", "employee_id")
);

-- إنشاء فهارس للأداء
CREATE INDEX IF NOT EXISTS "idx_holiday_assignments_holiday_id" ON "holiday_assignments"("holiday_id");
CREATE INDEX IF NOT EXISTS "idx_holiday_assignments_branch_id" ON "holiday_assignments"("branch_id");
CREATE INDEX IF NOT EXISTS "idx_holiday_assignments_department_id" ON "holiday_assignments"("department_id");
CREATE INDEX IF NOT EXISTS "idx_holiday_assignments_employee_id" ON "holiday_assignments"("employee_id");
CREATE INDEX IF NOT EXISTS "idx_holidays_date" ON "holidays"("date");
CREATE INDEX IF NOT EXISTS "idx_holidays_company_date" ON "holidays"("company_id", "date");

-- تحديث العطلات الموجودة لتكون مدفوعة وتطبق على الجميع
UPDATE "holidays" SET 
    "is_paid" = true,
    "application_type" = 'ALL',
    "overtime_multiplier" = 2.0
WHERE "is_paid" IS NULL;

SELECT 'تم تطبيق migration العطلات بنجاح' as result;
