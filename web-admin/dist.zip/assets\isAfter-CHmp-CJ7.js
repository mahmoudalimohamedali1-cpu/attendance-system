import{aT as t}from"./index-BiBF1DeO.js";function m(e,o){const a=t(e),r=t(o);return a.getTime()>r.getTime()}export{m as i};
