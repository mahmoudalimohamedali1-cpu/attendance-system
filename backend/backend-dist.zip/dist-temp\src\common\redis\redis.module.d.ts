export declare class RedisModule {
}
