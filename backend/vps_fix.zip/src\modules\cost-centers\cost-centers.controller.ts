import {
    Controller,
    Get,
    Post,
    Patch,
    Delete,
    Body,
    Param,
    Query,
    UseGuards,
    Req,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { CostCentersService } from './cost-centers.service';
import {
    CreateCostCenterDto,
    UpdateCostCenterDto,
    CreateAllocationDto,
    CreateBudgetDto,
} from './dto/cost-center.dto';

interface AuthenticatedRequest {
    user: {
        id: string;
        companyId: string;
        role: string;
    };
}

@ApiTags('Cost Centers - مراكز التكلفة')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('cost-centers')
export class CostCentersController {
    constructor(private readonly costCentersService: CostCentersService) { }

    // ==================== CRUD مراكز التكلفة ====================

    @Post()
    @Roles('ADMIN')
    @ApiOperation({ summary: 'إنشاء مركز تكلفة جديد' })
    create(@Body() dto: CreateCostCenterDto, @Req() req: AuthenticatedRequest) {
        return this.costCentersService.create(dto, req.user.companyId);
    }

    @Get()
    @ApiOperation({ summary: 'قائمة مراكز التكلفة' })
    @ApiQuery({ name: 'status', required: false, description: 'فلتر الحالة' })
    @ApiQuery({ name: 'type', required: false, description: 'فلتر النوع' })
    @ApiQuery({ name: 'search', required: false, description: 'بحث' })
    findAll(
        @Req() req: AuthenticatedRequest,
        @Query('status') status?: string,
        @Query('type') type?: string,
        @Query('search') search?: string,
    ) {
        return this.costCentersService.findAll(req.user.companyId, { status, type, search });
    }

    @Get('tree')
    @ApiOperation({ summary: 'الهيكل الهرمي لمراكز التكلفة' })
    findTree(@Req() req: AuthenticatedRequest) {
        return this.costCentersService.findTree(req.user.companyId);
    }

    @Get(':id')
    @ApiOperation({ summary: 'تفاصيل مركز تكلفة' })
    findOne(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
        return this.costCentersService.findOne(id, req.user.companyId);
    }

    @Patch(':id')
    @Roles('ADMIN')
    @ApiOperation({ summary: 'تحديث مركز تكلفة' })
    update(@Param('id') id: string, @Body() dto: UpdateCostCenterDto, @Req() req: AuthenticatedRequest) {
        return this.costCentersService.update(id, dto, req.user.companyId);
    }

    @Delete(':id')
    @Roles('ADMIN')
    @ApiOperation({ summary: 'أرشفة مركز تكلفة' })
    archive(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
        return this.costCentersService.archive(id, req.user.companyId);
    }

    // ==================== التوزيعات ====================

    @Post(':id/allocations')
    @Roles('ADMIN')
    @ApiOperation({ summary: 'إضافة توزيع موظف على مركز تكلفة' })
    createAllocation(
        @Param('id') costCenterId: string,
        @Body() dto: CreateAllocationDto,
        @Req() req: AuthenticatedRequest,
    ) {
        return this.costCentersService.createAllocation(
            { ...dto, costCenterId },
            req.user.companyId,
        );
    }

    @Get(':id/allocations')
    @ApiOperation({ summary: 'توزيعات مركز التكلفة' })
    findAllocations(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
        return this.costCentersService.findAllocations(id, req.user.companyId);
    }

    @Get('user/:userId/allocations')
    @ApiOperation({ summary: 'توزيعات موظف معين' })
    findUserAllocations(@Param('userId') userId: string, @Req() req: AuthenticatedRequest) {
        return this.costCentersService.findUserAllocations(userId, req.user.companyId);
    }

    @Delete('allocations/:allocationId')
    @Roles('ADMIN')
    @ApiOperation({ summary: 'إلغاء توزيع' })
    deactivateAllocation(@Param('allocationId') allocationId: string, @Req() req: AuthenticatedRequest) {
        return this.costCentersService.deactivateAllocation(allocationId, req.user.companyId);
    }

    // ==================== الميزانيات ====================

    @Post(':id/budgets')
    @Roles('ADMIN')
    @ApiOperation({ summary: 'إضافة ميزانية لمركز تكلفة' })
    createBudget(@Param('id') costCenterId: string, @Body() dto: CreateBudgetDto, @Req() req: AuthenticatedRequest) {
        return this.costCentersService.createBudget({ ...dto, costCenterId }, req.user.companyId);
    }

    @Get(':id/budgets')
    @ApiOperation({ summary: 'ميزانيات مركز التكلفة' })
    @ApiQuery({ name: 'year', required: false, description: 'السنة' })
    findBudgets(@Param('id') id: string, @Query('year') year?: string) {
        return this.costCentersService.findBudgets(id, year ? parseInt(year) : undefined);
    }

    // ==================== التحليلات ====================

    @Get(':id/analytics')
    @ApiOperation({ summary: 'تحليلات مركز التكلفة' })
    getAnalytics(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
        return this.costCentersService.getAnalytics(id, req.user.companyId);
    }

    @Get(':id/employees')
    @ApiOperation({ summary: 'موظفي مركز التكلفة' })
    getEmployees(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
        return this.costCentersService.getEmployeesByCostCenter(id, req.user.companyId);
    }
}
