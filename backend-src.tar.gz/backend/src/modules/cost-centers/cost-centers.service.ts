import {
    Injectable,
    NotFoundException,
    BadRequestException,
    ConflictException,
} from '@nestjs/common';
import { PrismaService } from '../../common/prisma/prisma.service';
import {
    CreateCostCenterDto,
    UpdateCostCenterDto,
    CreateAllocationDto,
    CreateBudgetDto,
} from './dto/cost-center.dto';
import { Prisma, CostCenter, CostCenterAllocation, CostCenterBudget } from '@prisma/client';

@Injectable()
export class CostCentersService {
    constructor(private prisma: PrismaService) { }

    // ==================== مراكز التكلفة CRUD ====================

    async create(dto: CreateCostCenterDto, companyId: string) {
        // التحقق من عدم تكرار الكود
        const existing = await this.prisma.costCenter.findFirst({
            where: { companyId, code: dto.code },
        });
        if (existing) {
            throw new ConflictException(`مركز تكلفة بالكود "${dto.code}" موجود مسبقاً`);
        }

        // حساب المستوى والمسار إذا كان له parent
        let level = 1;
        let path = dto.code;

        if (dto.parentId) {
            const parent = await this.prisma.costCenter.findUnique({
                where: { id: dto.parentId },
            });
            if (!parent) {
                throw new NotFoundException('مركز التكلفة الأب غير موجود');
            }
            level = parent.level + 1;
            path = parent.path ? `${parent.path}/${dto.code}` : dto.code;
        }

        return this.prisma.costCenter.create({
            data: {
                companyId,
                code: dto.code,
                nameAr: dto.nameAr,
                nameEn: dto.nameEn,
                description: dto.description,
                type: dto.type || 'OPERATING',
                status: 'ACTIVE',
                parentId: dto.parentId,
                level,
                path,
                managerId: dto.managerId,
                effectiveFrom: dto.effectiveFrom ? new Date(dto.effectiveFrom) : new Date(),
                effectiveTo: dto.effectiveTo ? new Date(dto.effectiveTo) : null,
                isAllowOverbudget: dto.isAllowOverbudget || false,
            },
            include: {
                parent: { select: { id: true, code: true, nameAr: true } },
                children: { select: { id: true, code: true, nameAr: true } },
            },
        });
    }

    async findAll(companyId: string, filters?: { status?: string; type?: string; search?: string }) {
        const where: Prisma.CostCenterWhereInput = { companyId };

        if (filters?.status) {
            where.status = filters.status;
        }
        if (filters?.type) {
            where.type = filters.type;
        }
        if (filters?.search) {
            where.OR = [
                { code: { contains: filters.search, mode: 'insensitive' } },
                { nameAr: { contains: filters.search, mode: 'insensitive' } },
                { nameEn: { contains: filters.search, mode: 'insensitive' } },
            ];
        }

        return this.prisma.costCenter.findMany({
            where,
            include: {
                parent: { select: { id: true, code: true, nameAr: true } },
                children: { select: { id: true, code: true, nameAr: true } },
                _count: { select: { users: true, allocations: true, budgets: true } },
            },
            orderBy: [{ level: 'asc' }, { code: 'asc' }],
        });
    }

    async findTree(companyId: string) {
        // جلب كل مراكز التكلفة وبناء الشجرة
        const costCenters = await this.prisma.costCenter.findMany({
            where: { companyId, status: 'ACTIVE' },
            include: {
                _count: { select: { users: true, allocations: true } },
            },
            orderBy: [{ level: 'asc' }, { code: 'asc' }],
        });

        // بناء الشجرة الهرمية
        const map = new Map<string, CostCenter & { children: (CostCenter & { children: CostCenter[] })[] }>();
        const roots: (CostCenter & { children: CostCenter[] })[] = [];

        costCenters.forEach((cc) => {
            map.set(cc.id, { ...cc, children: [] });
        });

        costCenters.forEach((cc) => {
            const node = map.get(cc.id)!;
            if (cc.parentId && map.has(cc.parentId)) {
                map.get(cc.parentId)!.children.push(node);
            } else {
                roots.push(node);
            }
        });

        return roots;
    }

    async findOne(id: string, companyId: string) {
        const costCenter = await this.prisma.costCenter.findFirst({
            where: { id, companyId },
            include: {
                parent: { select: { id: true, code: true, nameAr: true } },
                children: { select: { id: true, code: true, nameAr: true, status: true } },
                users: { select: { id: true, firstName: true, lastName: true, employeeCode: true } },
                allocations: {
                    where: { isActive: true },
                    select: {
                        id: true,
                        userId: true,
                        percentage: true,
                        allocationType: true,
                        effectiveFrom: true,
                        effectiveTo: true,
                    },
                },
                budgets: {
                    orderBy: [{ year: 'desc' }, { month: 'desc' }],
                    take: 12,
                },
            },
        });

        if (!costCenter) {
            throw new NotFoundException('مركز التكلفة غير موجود');
        }

        return costCenter;
    }

    async update(id: string, dto: UpdateCostCenterDto, companyId: string) {
        const existing = await this.prisma.costCenter.findFirst({
            where: { id, companyId },
        });

        if (!existing) {
            throw new NotFoundException('مركز التكلفة غير موجود');
        }

        // تحديث المستوى والمسار إذا تغير الـ parent
        const updateData: Prisma.CostCenterUpdateInput = { ...dto };

        if (dto.parentId !== undefined && dto.parentId !== existing.parentId) {
            if (dto.parentId) {
                // التحقق من عدم وجود دورة (circular reference)
                if (dto.parentId === id) {
                    throw new BadRequestException('لا يمكن أن يكون مركز التكلفة أباً لنفسه');
                }

                const parent = await this.prisma.costCenter.findUnique({
                    where: { id: dto.parentId },
                });

                if (!parent) {
                    throw new NotFoundException('مركز التكلفة الأب غير موجود');
                }

                updateData.level = parent.level + 1;
                updateData.path = parent.path
                    ? `${parent.path}/${existing.code}`
                    : existing.code;
            } else {
                updateData.level = 1;
                updateData.path = existing.code;
            }
        }

        if (dto.effectiveTo) {
            updateData.effectiveTo = new Date(dto.effectiveTo);
        }

        return this.prisma.costCenter.update({
            where: { id },
            data: updateData,
            include: {
                parent: { select: { id: true, code: true, nameAr: true } },
                children: { select: { id: true, code: true, nameAr: true } },
            },
        });
    }

    async archive(id: string, companyId: string) {
        const existing = await this.prisma.costCenter.findFirst({
            where: { id, companyId },
            include: { _count: { select: { children: true } } },
        });

        if (!existing) {
            throw new NotFoundException('مركز التكلفة غير موجود');
        }

        if (existing._count.children > 0) {
            throw new BadRequestException('لا يمكن أرشفة مركز تكلفة له أبناء. قم بأرشفة الأبناء أولاً');
        }

        return this.prisma.costCenter.update({
            where: { id },
            data: { status: 'ARCHIVED', effectiveTo: new Date() },
        });
    }

    // ==================== التوزيعات ====================

    async createAllocation(dto: CreateAllocationDto, companyId: string) {
        // التحقق من وجود costCenterId
        if (!dto.costCenterId) {
            throw new BadRequestException('معرف مركز التكلفة مطلوب');
        }

        // التحقق من وجود الموظف ومركز التكلفة
        const [user, costCenter] = await Promise.all([
            this.prisma.user.findFirst({ where: { id: dto.userId, companyId } }),
            this.prisma.costCenter.findFirst({ where: { id: dto.costCenterId, companyId } }),
        ]);

        if (!user) {
            throw new NotFoundException('الموظف غير موجود');
        }
        if (!costCenter) {
            throw new NotFoundException('مركز التكلفة غير موجود');
        }

        // التحقق من أن مجموع النسب لا يتجاوز 100%
        const existingAllocations = await this.prisma.costCenterAllocation.findMany({
            where: { userId: dto.userId, isActive: true },
        });

        const currentTotal = existingAllocations.reduce(
            (sum: number, a: CostCenterAllocation) => sum + Number(a.percentage),
            0,
        );

        if (currentTotal + dto.percentage > 100) {
            throw new BadRequestException(
                `مجموع النسب سيتجاوز 100%، النسبة المتاحة: ${100 - currentTotal}%`,
            );
        }

        return this.prisma.costCenterAllocation.create({
            data: {
                companyId,
                userId: dto.userId,
                costCenterId: dto.costCenterId,
                percentage: dto.percentage,
                allocationType: dto.allocationType || 'POSITION',
                effectiveFrom: dto.effectiveFrom ? new Date(dto.effectiveFrom) : new Date(),
                effectiveTo: dto.effectiveTo ? new Date(dto.effectiveTo) : null,
                reason: dto.reason,
                isActive: true,
            },
            include: {
                costCenter: { select: { id: true, code: true, nameAr: true } },
            },
        });
    }

    async findAllocations(costCenterId: string, companyId: string) {
        return this.prisma.costCenterAllocation.findMany({
            where: { costCenterId, companyId, isActive: true },
            include: {
                costCenter: { select: { id: true, code: true, nameAr: true } },
            },
            orderBy: { percentage: 'desc' },
        });
    }

    async findUserAllocations(userId: string, companyId: string) {
        return this.prisma.costCenterAllocation.findMany({
            where: { userId, companyId, isActive: true },
            include: {
                costCenter: { select: { id: true, code: true, nameAr: true } },
            },
            orderBy: { percentage: 'desc' },
        });
    }

    async deactivateAllocation(allocationId: string, companyId: string) {
        const allocation = await this.prisma.costCenterAllocation.findFirst({
            where: { id: allocationId, companyId },
        });

        if (!allocation) {
            throw new NotFoundException('التوزيع غير موجود');
        }

        return this.prisma.costCenterAllocation.update({
            where: { id: allocationId },
            data: { isActive: false, effectiveTo: new Date() },
        });
    }

    // ==================== الميزانيات ====================

    async createBudget(dto: CreateBudgetDto, companyId: string) {
        // التحقق من وجود costCenterId
        if (!dto.costCenterId) {
            throw new BadRequestException('معرف مركز التكلفة مطلوب');
        }

        const costCenter = await this.prisma.costCenter.findFirst({
            where: { id: dto.costCenterId, companyId },
        });

        if (!costCenter) {
            throw new NotFoundException('مركز التكلفة غير موجود');
        }

        // التحقق من عدم تكرار الميزانية لنفس الفترة
        const existing = await this.prisma.costCenterBudget.findFirst({
            where: {
                costCenterId: dto.costCenterId,
                year: dto.year,
                month: dto.month || null,
            },
        });

        if (existing) {
            throw new ConflictException('ميزانية لهذه الفترة موجودة مسبقاً');
        }

        return this.prisma.costCenterBudget.create({
            data: {
                companyId,
                costCenterId: dto.costCenterId,
                year: dto.year,
                month: dto.month,
                quarter: dto.quarter,
                budgetAmount: dto.budgetAmount,
                actualAmount: 0,
                variance: dto.budgetAmount,
                notes: dto.notes,
            },
            include: {
                costCenter: { select: { id: true, code: true, nameAr: true } },
            },
        });
    }

    async findBudgets(costCenterId: string, year?: number) {
        const where: Prisma.CostCenterBudgetWhereInput = { costCenterId };
        if (year) {
            where.year = year;
        }

        return this.prisma.costCenterBudget.findMany({
            where,
            orderBy: [{ year: 'desc' }, { month: 'asc' }],
        });
    }

    async updateBudgetActual(budgetId: string, actualAmount: number) {
        const budget = await this.prisma.costCenterBudget.findUnique({
            where: { id: budgetId },
        });

        if (!budget) {
            throw new NotFoundException('الميزانية غير موجودة');
        }

        const variance = Number(budget.budgetAmount) - actualAmount;

        return this.prisma.costCenterBudget.update({
            where: { id: budgetId },
            data: { actualAmount, variance },
        });
    }

    // ==================== التحليلات ====================

    async getAnalytics(costCenterId: string, companyId: string) {
        const [costCenter, employees, budgets, allocations] = await Promise.all([
            this.prisma.costCenter.findFirst({
                where: { id: costCenterId, companyId },
                include: {
                    _count: { select: { users: true, children: true } },
                },
            }),
            this.prisma.user.count({ where: { costCenterId, companyId } }),
            this.prisma.costCenterBudget.findMany({
                where: { costCenterId },
                orderBy: [{ year: 'desc' }, { month: 'asc' }],
                take: 12,
            }),
            this.prisma.costCenterAllocation.aggregate({
                where: { costCenterId, isActive: true },
                _sum: { percentage: true },
                _count: true,
            }),
        ]);

        if (!costCenter) {
            throw new NotFoundException('مركز التكلفة غير موجود');
        }

        // حساب إجماليات الميزانية
        const totalBudget = budgets.reduce((sum: number, b: CostCenterBudget) => sum + Number(b.budgetAmount), 0);
        const totalActual = budgets.reduce((sum: number, b: CostCenterBudget) => sum + Number(b.actualAmount), 0);
        const totalVariance = totalBudget - totalActual;
        const utilizationRate = totalBudget > 0 ? (totalActual / totalBudget) * 100 : 0;

        return {
            costCenter,
            summary: {
                directEmployees: employees,
                childrenCount: costCenter._count.children,
                allocationsCount: allocations._count,
                totalAllocationPercentage: Number(allocations._sum.percentage) || 0,
            },
            budget: {
                totalBudget,
                totalActual,
                totalVariance,
                utilizationRate: Math.round(utilizationRate * 100) / 100,
                periods: budgets,
            },
        };
    }

    async getEmployeesByCostCenter(costCenterId: string, companyId: string) {
        // الموظفين المباشرين
        const directEmployees = await this.prisma.user.findMany({
            where: { costCenterId, companyId },
            select: {
                id: true,
                firstName: true,
                lastName: true,
                employeeCode: true,
                jobTitle: true,
                salary: true,
            },
        });

        // الموظفين عبر التوزيعات
        const allocatedEmployees = await this.prisma.costCenterAllocation.findMany({
            where: { costCenterId, companyId, isActive: true },
            select: {
                userId: true,
                percentage: true,
            },
        });

        const allocatedUserIds = allocatedEmployees.map((a: { userId: string }) => a.userId);
        const allocatedUsers = await this.prisma.user.findMany({
            where: { id: { in: allocatedUserIds } },
            select: {
                id: true,
                firstName: true,
                lastName: true,
                employeeCode: true,
                jobTitle: true,
                salary: true,
            },
        });

        return {
            direct: directEmployees,
            allocated: allocatedUsers.map((u: { id: string; firstName: string; lastName: string; employeeCode: string | null; jobTitle: string | null; salary: Prisma.Decimal | null }) => ({
                ...u,
                percentage: allocatedEmployees.find((a: { userId: string; percentage: Prisma.Decimal }) => a.userId === u.id)?.percentage,
            })),
        };
    }
}
