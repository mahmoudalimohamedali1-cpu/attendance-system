"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var PredictiveInsightsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PredictiveInsightsService = void 0;
const common_1 = require("@nestjs/common");
let PredictiveInsightsService = PredictiveInsightsService_1 = class PredictiveInsightsService {
    constructor() {
        this.logger = new common_1.Logger(PredictiveInsightsService_1.name);
    }
    predictAbsences(date) {
        const dayOfWeek = date.getDay();
        const month = date.getMonth();
        const factors = [];
        let baseAbsences = 3;
        if (dayOfWeek === 0 || dayOfWeek === 4) {
            baseAbsences += 2;
            factors.push('قرب نهاية الأسبوع');
        }
        if (month === 6 || month === 7) {
            baseAbsences += 3;
            factors.push('موسم الصيف والإجازات');
        }
        if (month >= 5 && month <= 8) {
            baseAbsences += 1;
            factors.push('ارتفاع درجات الحرارة');
        }
        const variation = Math.floor(Math.random() * 3) - 1;
        const predicted = Math.max(0, baseAbsences + variation);
        let recommendation;
        if (predicted > 5) {
            recommendation = 'احتياطي: تأكد من وجود بدلاء';
        }
        else if (predicted > 3) {
            recommendation = 'تنبيه: قد يكون هناك ضغط على الفريق';
        }
        else {
            recommendation = 'طبيعي: لا إجراءات مطلوبة';
        }
        return {
            date,
            predictedAbsences: predicted,
            confidence: 0.75 + Math.random() * 0.15,
            factors: factors.length > 0 ? factors : ['لا عوامل خاصة'],
            recommendation,
        };
    }
    forecastWorkload(department) {
        const currentLoad = 70 + Math.floor(Math.random() * 20);
        const predictedLoad = currentLoad + Math.floor(Math.random() * 20) - 10;
        let trend;
        if (predictedLoad > currentLoad + 5)
            trend = 'increasing';
        else if (predictedLoad < currentLoad - 5)
            trend = 'decreasing';
        else
            trend = 'stable';
        const peakDays = ['الأحد', 'الاثنين', 'الخميس'].filter(() => Math.random() > 0.5);
        let recommendation;
        if (predictedLoad > 85) {
            recommendation = 'قد تحتاج لموارد إضافية';
        }
        else if (predictedLoad < 50) {
            recommendation = 'فرصة لمشاريع جديدة';
        }
        else {
            recommendation = 'مستوى مناسب';
        }
        return {
            period: 'الأسبوع القادم',
            currentLoad,
            predictedLoad,
            trend,
            peakDays,
            recommendation,
        };
    }
    predictBudget() {
        const categories = [
            { name: 'salaries', nameAr: 'الرواتب', budget: 500000 },
            { name: 'training', nameAr: 'التدريب', budget: 50000 },
            { name: 'travel', nameAr: 'السفر', budget: 30000 },
            { name: 'equipment', nameAr: 'المعدات', budget: 40000 },
            { name: 'benefits', nameAr: 'المزايا', budget: 80000 },
        ];
        return categories.map(cat => {
            const spentPercent = 0.6 + Math.random() * 0.5;
            const currentSpend = Math.round(cat.budget * spentPercent * 0.9);
            const predictedSpend = Math.round(cat.budget * spentPercent);
            const variance = predictedSpend - cat.budget;
            const variancePercent = Math.round((variance / cat.budget) * 100);
            let status;
            if (variancePercent > 5)
                status = 'over';
            else if (variancePercent < -10)
                status = 'under';
            else
                status = 'on_track';
            return {
                category: cat.name,
                categoryAr: cat.nameAr,
                currentSpend,
                predictedSpend,
                variance,
                variancePercent,
                status,
            };
        });
    }
    forecastHiring() {
        const departments = [
            { name: 'Engineering', nameAr: 'الهندسة', current: 25, growth: true },
            { name: 'Sales', nameAr: 'المبيعات', current: 15, growth: true },
            { name: 'HR', nameAr: 'الموارد البشرية', current: 8, growth: false },
            { name: 'Finance', nameAr: 'المالية', current: 10, growth: false },
        ];
        return departments.map(dept => {
            const needsHiring = dept.growth || Math.random() > 0.7;
            const need = needsHiring ? Math.ceil(dept.current * (0.1 + Math.random() * 0.15)) : 0;
            const reasons = [
                'نمو الأعمال',
                'استبدال المستقيلين',
                'مشاريع جديدة',
                'تخفيف ضغط العمل',
            ];
            return {
                department: dept.name,
                departmentAr: dept.nameAr,
                currentHeadcount: dept.current,
                predictedNeed: need,
                timeline: need > 0 ? 'الربع القادم' : 'لا حاجة حالياً',
                reason: need > 0 ? reasons[Math.floor(Math.random() * reasons.length)] : 'لا حاجة',
                priority: need > 3 ? 'high' : need > 0 ? 'medium' : 'low',
            };
        });
    }
    analyzeTrends() {
        const metrics = [
            { name: 'attendance', nameAr: 'الحضور', unit: '%' },
            { name: 'turnover', nameAr: 'معدل الدوران', unit: '%' },
            { name: 'satisfaction', nameAr: 'الرضا الوظيفي', unit: '/5' },
            { name: 'productivity', nameAr: 'الإنتاجية', unit: '%' },
        ];
        return metrics.map(metric => {
            const previous = 70 + Math.floor(Math.random() * 20);
            const current = previous + Math.floor(Math.random() * 15) - 7;
            const change = current - previous;
            const changePercent = Math.round((change / previous) * 100);
            let trend;
            if (change > 2)
                trend = 'up';
            else if (change < -2)
                trend = 'down';
            else
                trend = 'stable';
            let insight;
            if (metric.name === 'turnover') {
                insight = trend === 'up' ? 'انتبه: زيادة في الاستقالات' : 'جيد: استقرار الموظفين';
            }
            else {
                insight = trend === 'up' ? 'تحسن ملحوظ' : trend === 'down' ? 'يحتاج متابعة' : 'مستقر';
            }
            return {
                metric: metric.name,
                metricAr: metric.nameAr,
                current,
                previous,
                change,
                changePercent,
                trend,
                insight,
            };
        });
    }
    formatAbsencePrediction(pred) {
        const dateStr = pred.date.toLocaleDateString('ar-SA', { weekday: 'long', month: 'long', day: 'numeric' });
        const confidencePercent = Math.round(pred.confidence * 100);
        let message = `🔮 **توقع الغياب - ${dateStr}**\n\n`;
        message += `👥 المتوقع: ${pred.predictedAbsences} موظفين\n`;
        message += `📊 الثقة: ${confidencePercent}%\n\n`;
        if (pred.factors.length > 0) {
            message += `📋 **العوامل:**\n`;
            for (const factor of pred.factors) {
                message += `• ${factor}\n`;
            }
        }
        message += `\n💡 ${pred.recommendation}`;
        return message;
    }
    formatWorkloadForecast(forecast) {
        const trendEmoji = { increasing: '📈', stable: '➡️', decreasing: '📉' }[forecast.trend];
        const trendAr = { increasing: 'متزايد', stable: 'مستقر', decreasing: 'متناقص' }[forecast.trend];
        let message = `📊 **توقع عبء العمل - ${forecast.period}**\n\n`;
        message += `📍 الحالي: ${forecast.currentLoad}%\n`;
        message += `🔮 المتوقع: ${forecast.predictedLoad}%\n`;
        message += `${trendEmoji} الاتجاه: ${trendAr}\n\n`;
        if (forecast.peakDays.length > 0) {
            message += `⚡ أيام الذروة: ${forecast.peakDays.join(', ')}\n`;
        }
        message += `\n💡 ${forecast.recommendation}`;
        return message;
    }
    formatBudgetPrediction(predictions) {
        let message = `💰 **توقع الميزانية:**\n\n`;
        for (const pred of predictions) {
            const statusEmoji = { under: '🟢', on_track: '🟡', over: '🔴' }[pred.status];
            const statusAr = { under: 'أقل من المخطط', on_track: 'ضمن المخطط', over: 'يتجاوز المخطط' }[pred.status];
            message += `${statusEmoji} **${pred.categoryAr}**\n`;
            message += `   المتوقع: ${pred.predictedSpend.toLocaleString()} ر.س\n`;
            message += `   الفرق: ${pred.variancePercent > 0 ? '+' : ''}${pred.variancePercent}%\n\n`;
        }
        return message;
    }
    formatHiringForecast(forecasts) {
        let message = `👥 **توقع احتياجات التوظيف:**\n\n`;
        for (const forecast of forecasts.filter(f => f.predictedNeed > 0)) {
            const priorityEmoji = { low: '🟢', medium: '🟡', high: '🔴' }[forecast.priority];
            message += `${priorityEmoji} **${forecast.departmentAr}**\n`;
            message += `   الحالي: ${forecast.currentHeadcount} | المطلوب: +${forecast.predictedNeed}\n`;
            message += `   السبب: ${forecast.reason}\n`;
            message += `   التوقيت: ${forecast.timeline}\n\n`;
        }
        if (forecasts.filter(f => f.predictedNeed > 0).length === 0) {
            message += 'لا توجد احتياجات توظيف متوقعة حالياً';
        }
        return message;
    }
};
exports.PredictiveInsightsService = PredictiveInsightsService;
exports.PredictiveInsightsService = PredictiveInsightsService = PredictiveInsightsService_1 = __decorate([
    (0, common_1.Injectable)()
], PredictiveInsightsService);
//# sourceMappingURL=predictive-insights.service.js.map