export declare class DataUpdateModule {
}
