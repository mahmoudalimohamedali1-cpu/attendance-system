export declare class ContractsModule {
}
