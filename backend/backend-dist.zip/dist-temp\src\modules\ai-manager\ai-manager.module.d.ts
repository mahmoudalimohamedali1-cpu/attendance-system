export declare class AiManagerModule {
}
