export declare class EosModule {
}
