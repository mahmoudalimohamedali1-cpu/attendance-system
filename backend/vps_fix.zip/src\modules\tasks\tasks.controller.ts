import {
    Controller,
    Get,
    Post,
    Patch,
    Delete,
    Body,
    Param,
    Query,
    UseGuards,
    Request,
    UseInterceptors,
    UploadedFile,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiParam, ApiQuery, ApiConsumes } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname } from 'path';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { TasksService } from './tasks.service';
import { CreateTaskDto } from './dto/create-task.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { TaskQueryDto } from './dto/task-query.dto';
import {
    CreateTaskCategoryDto,
    UpdateTaskCategoryDto,
} from './dto/task-category.dto';
import {
    CreateTaskTemplateDto,
    UpdateTaskTemplateDto,
} from './dto/task-template.dto';
import {
    CreateChecklistDto,
    CreateChecklistItemDto,
    ToggleChecklistItemDto,
    CreateCommentDto,
    CreateTimeLogDto,
    AddDependencyDto,
    ReorderTaskDto,
} from './dto/task-actions.dto';

// Multer storage configuration
const attachmentStorage = diskStorage({
    destination: './uploads/tasks',
    filename: (req, file, callback) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        callback(null, uniqueSuffix + extname(file.originalname));
    },
});

@ApiTags('المهام - Tasks')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('tasks')
export class TasksController {
    constructor(private readonly tasksService: TasksService) { }

    // ============ TASKS ============

    @Post()
    @ApiOperation({ summary: 'إنشاء مهمة جديدة' })
    create(@Request() req: any, @Body() dto: CreateTaskDto) {
        return this.tasksService.createTask(req.user.id, req.user.companyId, dto);
    }

    @Get('my-tasks')
    @ApiOperation({ summary: 'مهامي - المهام المسندة لي أو التي أنشأتها' })
    getMyTasks(@Request() req: any) {
        return this.tasksService.getMyTasks(req.user.id, req.user.companyId);
    }

    @Get()
    @ApiOperation({ summary: 'قائمة المهام مع الفلترة والبحث' })
    findAll(@Request() req: any, @Query() query: TaskQueryDto) {
        return this.tasksService.getTasks(req.user.companyId, query);
    }

    @Get('kanban')
    @ApiOperation({ summary: 'لوحة Kanban للمهام' })
    @ApiQuery({ name: 'categoryId', required: false })
    @ApiQuery({ name: 'myTasks', required: false, type: Boolean })
    getKanban(
        @Request() req: any,
        @Query('categoryId') categoryId?: string,
        @Query('myTasks') myTasks?: string,
    ) {
        const userId = myTasks === 'true' ? req.user.id : undefined;
        return this.tasksService.getKanbanBoard(req.user.companyId, categoryId, userId);
    }

    @Get('stats')
    @ApiOperation({ summary: 'إحصائيات المهام' })
    @ApiQuery({ name: 'myStats', required: false, type: Boolean })
    getStats(@Request() req: any, @Query('myStats') myStats?: string) {
        const userId = myStats === 'true' ? req.user.id : undefined;
        return this.tasksService.getTaskStats(req.user.companyId, userId);
    }

    @Get(':id')
    @ApiOperation({ summary: 'تفاصيل مهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    findOne(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.getTaskById(id, req.user.companyId);
    }

    @Patch(':id')
    @ApiOperation({ summary: 'تحديث مهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    update(@Request() req: any, @Param('id') id: string, @Body() dto: UpdateTaskDto) {
        return this.tasksService.updateTask(id, req.user.companyId, req.user.id, dto);
    }

    @Delete(':id')
    @ApiOperation({ summary: 'حذف مهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    remove(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.deleteTask(id, req.user.companyId, req.user.id);
    }

    @Patch(':id/reorder')
    @ApiOperation({ summary: 'إعادة ترتيب مهمة (Kanban)' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    reorder(@Request() req: any, @Param('id') id: string, @Body() dto: ReorderTaskDto) {
        return this.tasksService.reorderTask(id, req.user.companyId, req.user.id, dto);
    }

    // ============ CHECKLISTS ============

    @Post(':id/checklists')
    @ApiOperation({ summary: 'إضافة قائمة تحقق' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    addChecklist(@Request() req: any, @Param('id') id: string, @Body() dto: CreateChecklistDto) {
        return this.tasksService.addChecklist(id, req.user.companyId, req.user.id, dto);
    }

    @Post('checklists/:checklistId/items')
    @ApiOperation({ summary: 'إضافة عنصر لقائمة التحقق' })
    @ApiParam({ name: 'checklistId', description: 'معرف قائمة التحقق' })
    addChecklistItem(
        @Request() req: any,
        @Param('checklistId') checklistId: string,
        @Body() dto: CreateChecklistItemDto,
    ) {
        return this.tasksService.addChecklistItem(checklistId, req.user.companyId, req.user.id, dto);
    }

    @Patch('checklist-items/:itemId/toggle')
    @ApiOperation({ summary: 'تبديل حالة عنصر قائمة التحقق' })
    @ApiParam({ name: 'itemId', description: 'معرف العنصر' })
    toggleChecklistItem(
        @Request() req: any,
        @Param('itemId') itemId: string,
        @Body() dto: ToggleChecklistItemDto,
    ) {
        return this.tasksService.toggleChecklistItem(
            itemId,
            req.user.companyId,
            req.user.id,
            dto.isCompleted,
        );
    }

    @Delete('checklist-items/:itemId')
    @ApiOperation({ summary: 'حذف عنصر من قائمة التحقق' })
    @ApiParam({ name: 'itemId', description: 'معرف العنصر' })
    deleteChecklistItem(@Request() req: any, @Param('itemId') itemId: string) {
        return this.tasksService.deleteChecklistItem(itemId, req.user.companyId, req.user.id);
    }

    // ============ COMMENTS ============

    @Post(':id/comments')
    @ApiOperation({ summary: 'إضافة تعليق' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    addComment(@Request() req: any, @Param('id') id: string, @Body() dto: CreateCommentDto) {
        return this.tasksService.addComment(id, req.user.companyId, req.user.id, dto);
    }

    @Delete('comments/:commentId')
    @ApiOperation({ summary: 'حذف تعليق' })
    @ApiParam({ name: 'commentId', description: 'معرف التعليق' })
    deleteComment(@Request() req: any, @Param('commentId') commentId: string) {
        return this.tasksService.deleteComment(commentId, req.user.companyId, req.user.id);
    }

    // ============ TIME LOGS ============

    @Post(':id/time-logs')
    @ApiOperation({ summary: 'تسجيل وقت عمل' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    addTimeLog(@Request() req: any, @Param('id') id: string, @Body() dto: CreateTimeLogDto) {
        return this.tasksService.addTimeLog(id, req.user.companyId, req.user.id, dto);
    }

    // ============ WATCHERS ============

    @Post(':id/watch')
    @ApiOperation({ summary: 'متابعة مهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    watch(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.addWatcher(id, req.user.companyId, req.user.id);
    }

    @Delete(':id/watch')
    @ApiOperation({ summary: 'إلغاء متابعة مهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    unwatch(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.removeWatcher(id, req.user.companyId, req.user.id);
    }

    // ============ DEPENDENCIES ============

    @Post(':id/dependencies')
    @ApiOperation({ summary: 'إضافة اعتماد (المهمة محظورة بسبب مهمة أخرى)' })
    @ApiParam({ name: 'id', description: 'معرف المهمة المحظورة' })
    addDependency(@Request() req: any, @Param('id') id: string, @Body() dto: AddDependencyDto) {
        return this.tasksService.addDependency(
            id,
            dto.blockingTaskId,
            req.user.companyId,
            req.user.id,
        );
    }

    @Delete(':id/dependencies/:blockingTaskId')
    @ApiOperation({ summary: 'إزالة اعتماد' })
    @ApiParam({ name: 'id', description: 'معرف المهمة المحظورة' })
    @ApiParam({ name: 'blockingTaskId', description: 'معرف المهمة المانعة' })
    removeDependency(
        @Request() req: any,
        @Param('id') id: string,
        @Param('blockingTaskId') blockingTaskId: string,
    ) {
        return this.tasksService.removeDependency(id, blockingTaskId, req.user.companyId);
    }

    // ============ ATTACHMENTS ============

    @Post(':id/attachments')
    @ApiOperation({ summary: 'رفع مرفق للمهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    @ApiConsumes('multipart/form-data')
    @UseInterceptors(FileInterceptor('file', { storage: attachmentStorage }))
    uploadAttachment(
        @Request() req: any,
        @Param('id') id: string,
        @UploadedFile() file: Express.Multer.File,
    ) {
        return this.tasksService.addAttachment(id, req.user.companyId, req.user.id, file);
    }


    @Delete('attachments/:attachmentId')
    @ApiOperation({ summary: 'حذف مرفق' })
    @ApiParam({ name: 'attachmentId', description: 'معرف المرفق' })
    deleteAttachment(@Request() req: any, @Param('attachmentId') attachmentId: string) {
        return this.tasksService.deleteAttachment(attachmentId, req.user.companyId, req.user.id);
    }

    // ==================== WORKFLOW ENDPOINTS ====================

    @Post(':id/workflow/request-review')
    @ApiOperation({ summary: 'طلب مراجعة المهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    requestReview(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.requestReview(id, req.user.companyId, req.user.id);
    }

    @Post(':id/workflow/start-review')
    @ApiOperation({ summary: 'بدء مراجعة المهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    startReview(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.startReview(id, req.user.companyId, req.user.id);
    }

    @Post(':id/workflow/approve')
    @ApiOperation({ summary: 'الموافقة على المهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    approveTask(
        @Request() req: any,
        @Param('id') id: string,
        @Body() body: { comment?: string },
    ) {
        return this.tasksService.approveTask(id, req.user.companyId, req.user.id, body?.comment);
    }

    @Post(':id/workflow/reject')
    @ApiOperation({ summary: 'رفض المهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    rejectTask(
        @Request() req: any,
        @Param('id') id: string,
        @Body() body: { reason: string },
    ) {
        return this.tasksService.rejectTask(id, req.user.companyId, req.user.id, body.reason);
    }

    @Post(':id/workflow/request-changes')
    @ApiOperation({ summary: 'طلب تعديلات على المهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    requestChanges(
        @Request() req: any,
        @Param('id') id: string,
        @Body() body: { feedback: string },
    ) {
        return this.tasksService.requestChanges(id, req.user.companyId, req.user.id, body.feedback);
    }

    @Get(':id/workflow/history')
    @ApiOperation({ summary: 'سجل الموافقات والمراجعات' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    getApprovalHistory(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.getApprovalHistory(id, req.user.companyId);
    }

    // ==================== EVIDENCE ENDPOINTS ====================

    @Post(':id/evidence')
    @ApiOperation({ summary: 'تقديم إثبات إنجاز' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    submitEvidence(
        @Request() req: any,
        @Param('id') id: string,
        @Body() body: {
            description?: string;
            fileUrl?: string;
            fileName?: string;
            fileType?: string;
            fileSize?: number;
            latitude?: number;
            longitude?: number;
            locationName?: string;
        },
    ) {
        return this.tasksService.submitEvidence(id, req.user.companyId, req.user.id, body);
    }

    @Get(':id/evidence')
    @ApiOperation({ summary: 'عرض إثباتات الإنجاز' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    getEvidences(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.getEvidences(id, req.user.companyId);
    }

    @Post('evidence/:evidenceId/verify')
    @ApiOperation({ summary: 'اعتماد أو رفض إثبات الإنجاز' })
    @ApiParam({ name: 'evidenceId', description: 'معرف الإثبات' })
    verifyEvidence(
        @Request() req: any,
        @Param('evidenceId') evidenceId: string,
        @Body() body: { status: 'APPROVED' | 'REJECTED'; comment?: string },
    ) {
        return this.tasksService.verifyEvidence(evidenceId, req.user.companyId, req.user.id, body.status, body.comment);
    }

    @Delete('evidence/:evidenceId')
    @ApiOperation({ summary: 'حذف إثبات الإنجاز' })
    @ApiParam({ name: 'evidenceId', description: 'معرف الإثبات' })
    deleteEvidence(@Request() req: any, @Param('evidenceId') evidenceId: string) {
        return this.tasksService.deleteEvidence(evidenceId, req.user.companyId, req.user.id);
    }

    // ==================== DEPENDENCY & GANTT ENDPOINTS ====================

    @Get(':id/dependencies')
    @ApiOperation({ summary: 'عرض تبعيات المهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    getDependencies(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.getDependencies(id, req.user.companyId);
    }

    @Patch('dependencies/:dependencyId/type')
    @ApiOperation({ summary: 'تحديث نوع التبعية' })
    @ApiParam({ name: 'dependencyId', description: 'معرف التبعية' })
    updateDependencyType(
        @Request() req: any,
        @Param('dependencyId') dependencyId: string,
        @Body() body: { type: 'BLOCKS' | 'BLOCKED_BY' | 'RELATED' | 'DUPLICATES' },
    ) {
        return this.tasksService.updateDependencyType(dependencyId, req.user.companyId, body.type);
    }

    @Get('gantt')
    @ApiOperation({ summary: 'بيانات Gantt Chart' })
    @ApiQuery({ name: 'categoryId', required: false, description: 'فلترة حسب الفئة' })
    getGanttData(@Request() req: any, @Query('categoryId') categoryId?: string) {
        return this.tasksService.getGanttData(req.user.companyId, categoryId);
    }

    // ==================== COMMUNICATION HUB ENDPOINTS ====================

    @Get(':id/comments/threaded')
    @ApiOperation({ summary: 'عرض التعليقات مع الردود' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    getComments(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.getComments(id, req.user.companyId);
    }

    @Post('comments/:commentId/reply')
    @ApiOperation({ summary: 'الرد على تعليق' })
    @ApiParam({ name: 'commentId', description: 'معرف التعليق' })
    replyToComment(
        @Request() req: any,
        @Param('commentId') commentId: string,
        @Body() body: { content: string; mentions?: string[] },
    ) {
        return this.tasksService.replyToComment(
            commentId,
            req.user.companyId,
            req.user.id,
            body.content,
            body.mentions || [],
        );
    }

    @Post('comments/:commentId/reactions')
    @ApiOperation({ summary: 'إضافة تفاعل على تعليق' })
    @ApiParam({ name: 'commentId', description: 'معرف التعليق' })
    addReaction(
        @Request() req: any,
        @Param('commentId') commentId: string,
        @Body() body: { emoji: string },
    ) {
        return this.tasksService.addReaction(commentId, req.user.companyId, req.user.id, body.emoji);
    }

    @Delete('comments/:commentId/reactions/:emoji')
    @ApiOperation({ summary: 'إزالة تفاعل من تعليق' })
    @ApiParam({ name: 'commentId', description: 'معرف التعليق' })
    @ApiParam({ name: 'emoji', description: 'الإيموجي' })
    removeReaction(
        @Request() req: any,
        @Param('commentId') commentId: string,
        @Param('emoji') emoji: string,
    ) {
        return this.tasksService.removeReaction(commentId, req.user.companyId, req.user.id, emoji);
    }

    @Get(':id/activity')
    @ApiOperation({ summary: 'سجل نشاط المهمة' })
    @ApiParam({ name: 'id', description: 'معرف المهمة' })
    @ApiQuery({ name: 'limit', required: false, description: 'عدد النتائج' })
    getActivityFeed(
        @Request() req: any,
        @Param('id') id: string,
        @Query('limit') limit?: string,
    ) {
        return this.tasksService.getActivityFeed(id, req.user.companyId, limit ? parseInt(limit) : 50);
    }

    // ==================== ANALYTICS ENDPOINTS ====================

    @Get('analytics/metrics')
    @ApiOperation({ summary: 'إحصائيات الإنتاجية' })
    @ApiQuery({ name: 'startDate', required: false })
    @ApiQuery({ name: 'endDate', required: false })
    getProductivityMetrics(
        @Request() req: any,
        @Query('startDate') startDate?: string,
        @Query('endDate') endDate?: string,
    ) {
        return this.tasksService.getProductivityMetrics(
            req.user.companyId,
            startDate ? new Date(startDate) : undefined,
            endDate ? new Date(endDate) : undefined,
        );
    }

    @Get('analytics/team')
    @ApiOperation({ summary: 'أداء الفريق' })
    @ApiQuery({ name: 'startDate', required: false })
    @ApiQuery({ name: 'endDate', required: false })
    getTeamPerformance(
        @Request() req: any,
        @Query('startDate') startDate?: string,
        @Query('endDate') endDate?: string,
    ) {
        return this.tasksService.getTeamPerformance(
            req.user.companyId,
            startDate ? new Date(startDate) : undefined,
            endDate ? new Date(endDate) : undefined,
        );
    }

    @Get('analytics/time')
    @ApiOperation({ summary: 'تحليل الوقت المسجل' })
    @ApiQuery({ name: 'startDate', required: false })
    @ApiQuery({ name: 'endDate', required: false })
    getTimeAnalytics(
        @Request() req: any,
        @Query('startDate') startDate?: string,
        @Query('endDate') endDate?: string,
    ) {
        return this.tasksService.getTimeAnalytics(
            req.user.companyId,
            startDate ? new Date(startDate) : undefined,
            endDate ? new Date(endDate) : undefined,
        );
    }

    @Get('analytics/trends')
    @ApiOperation({ summary: 'اتجاهات المهام' })
    @ApiQuery({ name: 'days', required: false, description: 'عدد الأيام (افتراضي 30)' })
    getTaskTrends(
        @Request() req: any,
        @Query('days') days?: string,
    ) {
        return this.tasksService.getTaskTrends(req.user.companyId, days ? parseInt(days) : 30);
    }

    @Post('analytics/report')
    @ApiOperation({ summary: 'توليد تقرير شامل' })
    generateReport(
        @Request() req: any,
        @Body() body: {
            startDate?: string;
            endDate?: string;
            categoryId?: string;
            assigneeId?: string;
            includeMetrics?: boolean;
            includeTeam?: boolean;
            includeTime?: boolean;
            includeTrends?: boolean;
        },
    ) {
        return this.tasksService.generateReport(req.user.companyId, {
            startDate: body.startDate ? new Date(body.startDate) : undefined,
            endDate: body.endDate ? new Date(body.endDate) : undefined,
            categoryId: body.categoryId,
            assigneeId: body.assigneeId,
            includeMetrics: body.includeMetrics,
            includeTeam: body.includeTeam,
            includeTime: body.includeTime,
            includeTrends: body.includeTrends,
        });
    }

    // ==================== AUTOMATION ENDPOINTS ====================

    @Post('automations')
    @ApiOperation({ summary: 'إنشاء قاعدة أتمتة' })
    createAutomation(
        @Request() req: any,
        @Body() body: {
            name: string;
            description?: string;
            trigger: string;
            triggerConfig?: any;
            action: string;
            actionConfig?: any;
            categoryId?: string;
            priority?: string;
        },
    ) {
        return this.tasksService.createAutomation(req.user.companyId, req.user.id, body);
    }

    @Get('automations')
    @ApiOperation({ summary: 'قواعد الأتمتة' })
    getAutomations(@Request() req: any) {
        return this.tasksService.getAutomations(req.user.companyId);
    }

    @Patch('automations/:id')
    @ApiOperation({ summary: 'تحديث قاعدة أتمتة' })
    @ApiParam({ name: 'id', description: 'معرف القاعدة' })
    updateAutomation(
        @Request() req: any,
        @Param('id') id: string,
        @Body() body: Partial<{
            name: string;
            description: string;
            trigger: string;
            triggerConfig: any;
            action: string;
            actionConfig: any;
            categoryId: string;
            priority: string;
            isActive: boolean;
        }>,
    ) {
        return this.tasksService.updateAutomation(id, req.user.companyId, body);
    }

    @Delete('automations/:id')
    @ApiOperation({ summary: 'حذف قاعدة أتمتة' })
    @ApiParam({ name: 'id', description: 'معرف القاعدة' })
    deleteAutomation(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.deleteAutomation(id, req.user.companyId);
    }

    @Patch('automations/:id/toggle')
    @ApiOperation({ summary: 'تفعيل/تعطيل قاعدة أتمتة' })
    @ApiParam({ name: 'id', description: 'معرف القاعدة' })
    toggleAutomation(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.toggleAutomation(id, req.user.companyId);
    }

    @Get('automations/:id/logs')
    @ApiOperation({ summary: 'سجل تنفيذ الأتمتة' })
    @ApiParam({ name: 'id', description: 'معرف القاعدة' })
    @ApiQuery({ name: 'limit', required: false })
    getAutomationLogs(
        @Request() req: any,
        @Param('id') id: string,
        @Query('limit') limit?: string,
    ) {
        return this.tasksService.getAutomationLogs(id, req.user.companyId, limit ? parseInt(limit) : 50);
    }
}


// ============ CATEGORIES CONTROLLER ============

@ApiTags('فئات المهام - Task Categories')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('task-categories')
export class TaskCategoriesController {
    constructor(private readonly tasksService: TasksService) { }

    @Get()
    @ApiOperation({ summary: 'قائمة فئات المهام' })
    findAll(@Request() req: any) {
        return this.tasksService.getCategories(req.user.companyId);
    }

    @Post()
    @ApiOperation({ summary: 'إنشاء فئة جديدة' })
    create(@Request() req: any, @Body() dto: CreateTaskCategoryDto) {
        return this.tasksService.createCategory(req.user.companyId, dto);
    }

    @Patch(':id')
    @ApiOperation({ summary: 'تحديث فئة' })
    @ApiParam({ name: 'id', description: 'معرف الفئة' })
    update(@Request() req: any, @Param('id') id: string, @Body() dto: UpdateTaskCategoryDto) {
        return this.tasksService.updateCategory(id, req.user.companyId, dto);
    }

    @Delete(':id')
    @ApiOperation({ summary: 'حذف فئة' })
    @ApiParam({ name: 'id', description: 'معرف الفئة' })
    remove(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.deleteCategory(id, req.user.companyId);
    }
}

// ============ TEMPLATES CONTROLLER ============

@ApiTags('قوالب المهام - Task Templates')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('task-templates')
export class TaskTemplatesController {
    constructor(private readonly tasksService: TasksService) { }

    @Get()
    @ApiOperation({ summary: 'قائمة قوالب المهام' })
    findAll(@Request() req: any) {
        return this.tasksService.getTemplates(req.user.companyId);
    }

    @Post()
    @ApiOperation({ summary: 'إنشاء قالب جديد' })
    create(@Request() req: any, @Body() dto: CreateTaskTemplateDto) {
        return this.tasksService.createTemplate(req.user.companyId, dto);
    }

    @Patch(':id')
    @ApiOperation({ summary: 'تحديث قالب' })
    @ApiParam({ name: 'id', description: 'معرف القالب' })
    update(@Request() req: any, @Param('id') id: string, @Body() dto: UpdateTaskTemplateDto) {
        return this.tasksService.updateTemplate(id, req.user.companyId, dto);
    }

    @Delete(':id')
    @ApiOperation({ summary: 'حذف قالب' })
    @ApiParam({ name: 'id', description: 'معرف القالب' })
    remove(@Request() req: any, @Param('id') id: string) {
        return this.tasksService.deleteTemplate(id, req.user.companyId);
    }
}

