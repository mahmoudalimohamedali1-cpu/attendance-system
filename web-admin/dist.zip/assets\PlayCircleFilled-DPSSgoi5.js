import{c as l,j as e}from"./index-BiBF1DeO.js";const a=l(e.jsx("path",{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m-2 14.5v-9l6 4.5z"}),"PlayCircleFilled");export{a as P};
