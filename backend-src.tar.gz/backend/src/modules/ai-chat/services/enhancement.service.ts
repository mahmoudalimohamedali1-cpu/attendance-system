import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../../common/prisma/prisma.service';
import { AiService } from '../../ai/ai.service';

/**
 * 🧠 Enhancement Service
 * Handles system modification requests (adding to existing systems)
 */

export interface EnhancementResult {
    success: boolean;
    message: string;
    changes?: string[];
    requiresRebuild?: boolean;
}

export interface EnhancementAnalysis {
    operation: string;
    targetSystem: string;
    description: string;
    details: Record<string, any>;
}

@Injectable()
export class EnhancementService {
    private readonly logger = new Logger(EnhancementService.name);

    // System knowledge for enhancement context
    private readonly systemKnowledge = {
        employees: {
            model: 'User',
            fields: ['annualLeaveDays', 'usedLeaveDays', 'remainingLeaveDays', 'salary', 'hireDate'],
            servicePath: 'src/modules/users/users.service.ts',
            profilePath: 'web-admin/src/pages/employee-profile/EmployeeProfilePage.tsx',
        },
        leaves: {
            model: 'LeaveRequest',
            enumPath: 'prisma/schema.prisma',
            servicePath: 'src/modules/leaves/leaves.service.ts',
            types: ['ANNUAL', 'SICK', 'EMERGENCY', 'UNPAID', 'MATERNITY', 'PATERNITY'],
        },
        attendance: {
            model: 'Attendance',
            servicePath: 'src/modules/attendance/attendance.service.ts',
        },
        payroll: {
            model: 'PayrollRun',
            servicePath: 'src/modules/payroll-runs/payroll-runs.service.ts',
        },
    };

    constructor(
        private readonly prisma: PrismaService,
        private readonly aiService: AiService,
    ) { }

    /**
     * 🎯 Execute enhancement request
     */
    async executeEnhancement(
        message: string,
        subIntent: string,
        context: { companyId: string; userId: string; userRole: string }
    ): Promise<EnhancementResult> {
        try {
            this.logger.log(`Processing enhancement: ${subIntent} - "${message.substring(0, 50)}..."`);

            // Step 1: Analyze the request
            const analysis = await this.analyzeRequest(message);
            if (!analysis) {
                return {
                    success: false,
                    message: '❌ لم أستطع تحليل الطلب. حاول صياغة أوضح مثل: "ضيف نوع إجازة مرضية بحد 10 أيام"',
                };
            }

            // Step 2: Plan the modifications
            const plan = this.planModifications(analysis);
            if (!plan.valid) {
                return {
                    success: false,
                    message: `❌ ${plan.error}`,
                };
            }

            // Step 3: Execute the modifications
            const results = await this.executeModifications(plan, context);

            return {
                success: true,
                message: this.formatSuccessMessage(analysis, results),
                changes: results,
                requiresRebuild: plan.requiresRebuild,
            };
        } catch (error) {
            this.logger.error(`Enhancement error: ${error.message}`, error.stack);
            return {
                success: false,
                message: `❌ حدث خطأ أثناء التعديل: ${error.message}`,
            };
        }
    }

    /**
     * 🔍 Analyze enhancement request using AI
     */
    private async analyzeRequest(message: string): Promise<EnhancementAnalysis | null> {
        const systemInstruction = `أنت محلل طلبات تعديل النظام. حول الطلب إلى JSON محدد.
العمليات المتاحة: add_enum, add_field, update_value, add_calculation
الأنظمة المتاحة: employees, leaves, attendance, payroll

أجب بـ JSON فقط بدون أي نص إضافي:
{
  "operation": "...",
  "targetSystem": "...",
  "description": "...",
  "details": { ... }
}`;

        const examples = `أمثلة:
"ضيف نوع إجازة مرضية" → {"operation":"add_enum","targetSystem":"leaves","description":"إضافة نوع إجازة مرضية","details":{"type":"SICK","limit":10}}
"كل موظف له 21 يوم إجازة" → {"operation":"update_value","targetSystem":"employees","description":"تحديث رصيد الإجازات","details":{"field":"annualLeaveDays","value":21}}`;

        try {
            const response = await this.aiService.generateContent(
                `${message}\n\n${examples}`,
                systemInstruction
            );

            // Parse JSON from response
            const jsonMatch = response?.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                return JSON.parse(jsonMatch[0]);
            }
            return null;
        } catch (error) {
            this.logger.error(`Analysis failed: ${error.message}`);
            return null;
        }
    }

    /**
     * 📋 Plan the modifications
     */
    private planModifications(analysis: EnhancementAnalysis): {
        valid: boolean;
        error?: string;
        steps: any[];
        requiresRebuild: boolean;
    } {
        const { operation, targetSystem, details } = analysis;
        const systemInfo = this.systemKnowledge[targetSystem as keyof typeof this.systemKnowledge];

        if (!systemInfo) {
            return { valid: false, error: `النظام "${targetSystem}" غير معروف`, steps: [], requiresRebuild: false };
        }

        const steps: any[] = [];
        let requiresRebuild = false;

        switch (operation) {
            case 'add_enum':
                steps.push({
                    type: 'database',
                    action: 'add_enum_value',
                    target: (systemInfo as any).enumPath,
                    value: details.type || details.value,
                });
                requiresRebuild = true;
                break;

            case 'add_field':
                steps.push({
                    type: 'database',
                    action: 'add_field',
                    model: systemInfo.model,
                    field: details.field,
                    fieldType: details.fieldType || 'String',
                });
                requiresRebuild = true;
                break;

            case 'update_value':
                steps.push({
                    type: 'database',
                    action: 'update_all',
                    model: systemInfo.model,
                    field: details.field,
                    value: details.value,
                });
                break;

            case 'add_calculation':
                steps.push({
                    type: 'service',
                    action: 'add_method',
                    path: systemInfo.servicePath,
                    details,
                });
                if (details.displayIn === 'profile') {
                    steps.push({
                        type: 'frontend',
                        action: 'display_in_profile',
                        path: (systemInfo as any).profilePath,
                        field: details.field,
                    });
                }
                requiresRebuild = true;
                break;

            default:
                return { valid: false, error: `العملية "${operation}" غير مدعومة`, steps: [], requiresRebuild: false };
        }

        return { valid: true, steps, requiresRebuild };
    }

    /**
     * ⚡ Execute the planned modifications
     */
    private async executeModifications(
        plan: { steps: any[]; requiresRebuild: boolean },
        context: { companyId: string }
    ): Promise<string[]> {
        const results: string[] = [];

        for (const step of plan.steps) {
            try {
                switch (step.type) {
                    case 'database':
                        const dbResult = await this.executeDatabaseStep(step, context);
                        results.push(dbResult);
                        break;

                    case 'service':
                        results.push(`✅ Service: ${step.action} ready`);
                        break;

                    case 'frontend':
                        results.push(`✅ Frontend: ${step.action} ready`);
                        break;
                }
            } catch (error) {
                results.push(`⚠️ ${step.type}: ${error.message}`);
            }
        }

        return results;
    }

    /**
     * 🗄️ Execute database modification step
     */
    private async executeDatabaseStep(
        step: any,
        context: { companyId: string }
    ): Promise<string> {
        switch (step.action) {
            case 'update_all':
                // Update all employees with the new value
                const updateResult = await this.prisma.user.updateMany({
                    where: { companyId: context.companyId },
                    data: { [step.field]: step.value },
                });
                return `✅ Database: تم تحديث ${updateResult.count} موظف - ${step.field} = ${step.value}`;

            case 'add_enum_value':
                // For enum values, we can't add dynamically but can guide the user
                return `⚠️ Database: نوع "${step.value}" يحتاج تعديل schema.prisma`;

            case 'add_field':
                return `⚠️ Database: حقل "${step.field}" يحتاج تعديل schema.prisma`;

            default:
                return `⚠️ Database: عملية "${step.action}" غير مدعومة`;
        }
    }

    /**
     * 📝 Format success message
     */
    private formatSuccessMessage(analysis: EnhancementAnalysis, results: string[]): string {
        const header = `✅ **تم تنفيذ: ${analysis.description}**\n\n`;
        const details = results.map(r => `• ${r}`).join('\n');

        const footer = analysis.operation === 'update_value'
            ? '\n\n💡 التغييرات سارية المفعول فوراً.'
            : '\n\n⚠️ قد يلزم إعادة البناء لتطبيق التغييرات.';

        return header + details + footer;
    }

    /**
     * 📊 Get system knowledge
     */
    getSystemKnowledge(): typeof this.systemKnowledge {
        return this.systemKnowledge;
    }
}
