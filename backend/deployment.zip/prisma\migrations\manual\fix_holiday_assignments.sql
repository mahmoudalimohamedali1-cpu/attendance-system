-- Fix holiday_assignments table with correct id type
CREATE TABLE IF NOT EXISTS "holiday_assignments" (
    "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "holiday_id" TEXT NOT NULL REFERENCES "holidays"("id") ON DELETE CASCADE,
    "assignment_type" VARCHAR(50) NOT NULL,
    "branch_id" TEXT,
    "department_id" TEXT,
    "employee_id" TEXT,
    "created_at" TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS "idx_ha_holiday" ON "holiday_assignments"("holiday_id");
CREATE INDEX IF NOT EXISTS "idx_ha_branch" ON "holiday_assignments"("branch_id");
CREATE INDEX IF NOT EXISTS "idx_ha_dept" ON "holiday_assignments"("department_id");
CREATE INDEX IF NOT EXISTS "idx_ha_emp" ON "holiday_assignments"("employee_id");

SELECT 'holiday_assignments table created successfully' as result;
