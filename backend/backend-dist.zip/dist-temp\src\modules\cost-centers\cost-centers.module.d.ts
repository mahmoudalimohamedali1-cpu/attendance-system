export declare class CostCentersModule {
}
