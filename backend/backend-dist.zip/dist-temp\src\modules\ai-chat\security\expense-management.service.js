"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ExpenseManagementService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpenseManagementService = void 0;
const common_1 = require("@nestjs/common");
let ExpenseManagementService = ExpenseManagementService_1 = class ExpenseManagementService {
    constructor() {
        this.logger = new common_1.Logger(ExpenseManagementService_1.name);
        this.expenses = new Map();
        this.categoryMapping = {
            travel: 'السفر',
            meals: 'الوجبات',
            supplies: 'المستلزمات',
            transport: 'المواصلات',
            accommodation: 'الإقامة',
            other: 'أخرى',
        };
        this.vendorCategories = {
            'uber': 'transport',
            'careem': 'transport',
            'كريم': 'transport',
            'starbucks': 'meals',
            'ستاربكس': 'meals',
            'mcdonalds': 'meals',
            'jarir': 'supplies',
            'جرير': 'supplies',
            'hotel': 'accommodation',
            'فندق': 'accommodation',
            'saudia': 'travel',
            'flynas': 'travel',
            'طيران': 'travel',
        };
    }
    parseReceipt(receiptText) {
        const text = receiptText.toLowerCase();
        const amountMatch = text.match(/(\d+(?:\.\d{2})?)\s*(ر\.?س|ريال|sar|sr)?/);
        const amount = amountMatch ? parseFloat(amountMatch[1]) : undefined;
        const dateMatch = text.match(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/);
        let date;
        if (dateMatch) {
            const year = dateMatch[3].length === 2 ? 2000 + parseInt(dateMatch[3]) : parseInt(dateMatch[3]);
            date = new Date(year, parseInt(dateMatch[2]) - 1, parseInt(dateMatch[1]));
        }
        let vendor;
        let category = 'other';
        for (const [vendorKey, cat] of Object.entries(this.vendorCategories)) {
            if (text.includes(vendorKey)) {
                vendor = vendorKey;
                category = cat;
                break;
            }
        }
        const confidence = (amount ? 0.3 : 0) + (date ? 0.2 : 0) + (vendor ? 0.3 : 0) + 0.2;
        return {
            success: confidence > 0.5,
            vendor,
            amount,
            date: date || new Date(),
            category,
            confidence,
        };
    }
    createExpense(userId, userName, message) {
        const parsed = this.parseReceipt(message);
        if (!parsed.success || !parsed.amount) {
            return {
                success: false,
                message: '❌ لم أتمكن من استخراج المبلغ من الرسالة.\n\nمثال: "صرفت 150 ريال غداء مع العميل"',
            };
        }
        const expenseId = `exp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
        const expense = {
            id: expenseId,
            userId,
            userName,
            category: parsed.category,
            categoryAr: this.categoryMapping[parsed.category],
            amount: parsed.amount,
            currency: 'SAR',
            description: message,
            date: parsed.date || new Date(),
            status: 'draft',
            createdAt: new Date(),
        };
        this.expenses.set(expenseId, expense);
        return {
            success: true,
            expense,
            message: `✅ تم إضافة المصروف!\n\n💰 المبلغ: ${expense.amount} ر.س\n📁 التصنيف: ${expense.categoryAr}\n📅 التاريخ: ${expense.date.toLocaleDateString('ar-SA')}\n\nهل تريد تقديم الطلب للموافقة؟`,
        };
    }
    submitExpense(expenseId) {
        const expense = this.expenses.get(expenseId);
        if (!expense) {
            return { success: false, message: '❌ لم يتم العثور على المصروف' };
        }
        expense.status = 'pending';
        return {
            success: true,
            message: `✅ تم تقديم طلب المصروف للموافقة!\n\n💰 ${expense.amount} ر.س - ${expense.categoryAr}\n\n⏳ بانتظار موافقة المدير`,
        };
    }
    approveExpense(expenseId) {
        const expense = this.expenses.get(expenseId);
        if (!expense) {
            return { success: false, message: '❌ لم يتم العثور على المصروف' };
        }
        expense.status = 'approved';
        return {
            success: true,
            message: `✅ تمت الموافقة على المصروف!\n\n💰 ${expense.amount} ر.س - ${expense.userName}`,
        };
    }
    getUserExpenses(userId) {
        const userExpenses = [];
        for (const [, expense] of this.expenses) {
            if (expense.userId === userId) {
                userExpenses.push(expense);
            }
        }
        return userExpenses.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    }
    getExpenseSummary(userId) {
        const expenses = this.getUserExpenses(userId);
        if (expenses.length === 0) {
            return '📋 لا توجد مصروفات مسجلة.\n\nلإضافة مصروف:\n"صرفت 100 ريال [الوصف]"';
        }
        const thisMonth = expenses.filter(e => {
            const now = new Date();
            return e.date.getMonth() === now.getMonth() && e.date.getFullYear() === now.getFullYear();
        });
        const total = thisMonth.reduce((sum, e) => sum + e.amount, 0);
        const pending = expenses.filter(e => e.status === 'pending').length;
        const approved = expenses.filter(e => e.status === 'approved').length;
        let message = `💰 **ملخص المصروفات**\n\n`;
        message += `📅 مصروفات الشهر: ${total.toLocaleString()} ر.س\n`;
        message += `⏳ بانتظار الموافقة: ${pending}\n`;
        message += `✅ تمت الموافقة: ${approved}\n\n`;
        if (thisMonth.length > 0) {
            message += `**آخر المصروفات:**\n`;
            for (const exp of thisMonth.slice(0, 5)) {
                const statusEmoji = { draft: '📝', pending: '⏳', approved: '✅', rejected: '❌', reimbursed: '💵' }[exp.status];
                message += `${statusEmoji} ${exp.amount} ر.س - ${exp.categoryAr}\n`;
            }
        }
        return message;
    }
};
exports.ExpenseManagementService = ExpenseManagementService;
exports.ExpenseManagementService = ExpenseManagementService = ExpenseManagementService_1 = __decorate([
    (0, common_1.Injectable)()
], ExpenseManagementService);
//# sourceMappingURL=expense-management.service.js.map