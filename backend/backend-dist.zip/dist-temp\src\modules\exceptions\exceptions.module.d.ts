export declare class ExceptionsModule {
}
