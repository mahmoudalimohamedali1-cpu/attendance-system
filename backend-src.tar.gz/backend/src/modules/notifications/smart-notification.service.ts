import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PrismaService } from '../../common/prisma/prisma.service';
import { NotificationsService } from './notifications.service';
import { PermissionsService } from '../permissions/permissions.service';
import { ApprovalStep, NotificationType } from '@prisma/client';

@Injectable()
export class SmartNotificationService {
    private readonly logger = new Logger(SmartNotificationService.name);

    // الإعدادات الافتراضية
    private readonly REMINDER_DAYS = 3; // تذكير بعد 3 أيام من عدم الرد
    private readonly DAILY_SUMMARY_ENABLED = true;

    constructor(
        private prisma: PrismaService,
        private notificationsService: NotificationsService,
        private permissionsService: PermissionsService,
    ) { }

    // ==================== Cron Jobs ====================

    /**
     * تذكير يومي بالطلبات المعلقة (كل يوم الساعة 9 صباحاً)
     */
    @Cron('0 9 * * *', { timeZone: 'Asia/Riyadh' })
    async sendDailyReminders() {
        this.logger.log('🔔 Running daily reminder job...');

        try {
            // الإجازات المعلقة
            await this.sendPendingRequestReminders('leaves');

            // الخطابات المعلقة
            await this.sendPendingRequestReminders('letters');

            // الزيادات المعلقة
            await this.sendPendingRequestReminders('raises');

            this.logger.log('✅ Daily reminders sent successfully');
        } catch (error) {
            this.logger.error('❌ Error sending daily reminders:', error);
        }
    }

    /**
     * فحص الطلبات المتأخرة وإرسال تذكيرات (مرتين يومياً)
     */
    @Cron('0 9,14 * * *', { timeZone: 'Asia/Riyadh' })
    async checkOverdueRequests() {
        this.logger.log('⏰ Checking for overdue requests...');

        try {
            const overdueDate = new Date();
            overdueDate.setDate(overdueDate.getDate() - this.REMINDER_DAYS);

            await this.sendOverdueReminders('leaves', overdueDate);
            await this.sendOverdueReminders('letters', overdueDate);
            await this.sendOverdueReminders('raises', overdueDate);

            this.logger.log('✅ Overdue check completed');
        } catch (error) {
            this.logger.error('❌ Error checking overdue requests:', error);
        }
    }

    // ==================== Reminder Logic ====================

    /**
     * إرسال تذكيرات للطلبات المعلقة لكل مدير/HR
     */
    private async sendPendingRequestReminders(type: 'leaves' | 'letters' | 'raises') {
        // جلب المديرين/HR اللي عندهم صلاحية موافقة
        const approvers = await this.getApprovers(type);

        for (const approver of approvers) {
            const pendingCount = await this.getPendingCountForApprover(type, approver.id, approver.companyId);

            if (pendingCount > 0) {
                await this.notificationsService.sendNotification(
                    approver.id,
                    NotificationType.GENERAL,
                    this.getRequestTypeLabel(type) + ' معلقة',
                    `لديك ${pendingCount} طلب بانتظار موافقتك`,
                    { type, count: pendingCount },
                    `Pending ${type}`,
                    `You have ${pendingCount} pending ${type} requests`,
                );
            }
        }
    }

    /**
     * إرسال تذكيرات للطلبات المتأخرة (أكثر من X أيام)
     */
    private async sendOverdueReminders(type: 'leaves' | 'letters' | 'raises', overdueDate: Date) {
        // جلب الطلبات المتأخرة مع المسؤول عن الموافقة
        const overdueRequests = await this.getOverdueRequests(type, overdueDate);

        for (const request of overdueRequests) {
            const { approverId, companyId } = await this.getApproverForRequest(type, request);

            if (approverId) {
                const daysOverdue = this.getDaysOverdue(request.createdAt);

                await this.notificationsService.sendNotification(
                    approverId,
                    NotificationType.GENERAL,
                    '⚠️ طلب متأخر',
                    `طلب ${this.getRequestTypeLabel(type)} من ${request.userName} معلق منذ ${daysOverdue} أيام`,
                    {
                        type,
                        requestId: request.id,
                        urgent: true,
                    },
                    '⚠️ Overdue Request',
                    `${type} request from ${request.userName} pending for ${daysOverdue} days`,
                );
            }
        }
    }

    // ==================== Helper Methods ====================

    private async getApprovers(type: 'leaves' | 'letters' | 'raises', companyId?: string): Promise<{ id: string, companyId: string }[]> {
        const permissionCode = `${type.toUpperCase()}_APPROVE_MANAGER`;
        const hrPermissionCode = `${type.toUpperCase()}_APPROVE_HR`;

        // جلب كل المستخدمين اللي عندهم صلاحية موافقة مع فلترة للشركة إذا وجدت
        const users = await this.prisma.userPermission.findMany({
            where: {
                permission: {
                    code: { in: [permissionCode, hrPermissionCode] }
                },
                companyId: companyId || undefined, // فلترة اختيارية بالشركة
                user: { status: 'ACTIVE' }
            },
            select: {
                userId: true,
                companyId: true // نستخدم القيمة من السجل مباشرة
            },
            distinct: ['userId'],
        });

        return users.map(u => ({ id: u.userId, companyId: u.companyId || '' }));
    }

    private async getPendingCountForApprover(type: 'leaves' | 'letters' | 'raises', approverId: string, companyId: string): Promise<number> {
        // جلب الموظفين المتاحين للمستخدم
        const accessibleManagerIds = await this.permissionsService.getAccessibleEmployeeIds(
            approverId,
            companyId,
            `${type.toUpperCase()}_APPROVE_MANAGER`,
        );
        const accessibleHrIds = await this.permissionsService.getAccessibleEmployeeIds(
            approverId,
            companyId,
            `${type.toUpperCase()}_APPROVE_HR`,
        );

        const accessibleIds = [...new Set([...accessibleManagerIds, ...accessibleHrIds])];

        if (accessibleIds.length === 0) return 0;

        if (type === 'leaves') {
            // Manager step
            const managerCount = await this.prisma.leaveRequest.count({
                where: {
                    companyId,
                    userId: { in: accessibleManagerIds },
                    currentStep: ApprovalStep.MANAGER,
                    status: 'PENDING',
                },
            });
            // HR step
            const hrCount = await this.prisma.leaveRequest.count({
                where: {
                    companyId,
                    userId: { in: accessibleHrIds },
                    currentStep: ApprovalStep.HR,
                    status: 'MGR_APPROVED',
                },
            });
            return managerCount + hrCount;
        } else if (type === 'letters') {
            const managerCount = await this.prisma.letterRequest.count({
                where: {
                    companyId,
                    userId: { in: accessibleManagerIds },
                    currentStep: 'MANAGER',
                    status: 'PENDING',
                },
            });
            const hrCount = await this.prisma.letterRequest.count({
                where: {
                    companyId,
                    userId: { in: accessibleHrIds },
                    currentStep: 'HR',
                    status: 'MGR_APPROVED',
                },
            });
            return managerCount + hrCount;
        } else {
            const managerCount = await this.prisma.raiseRequest.count({
                where: {
                    companyId,
                    userId: { in: accessibleManagerIds },
                    currentStep: 'MANAGER',
                    status: 'PENDING',
                },
            });
            const hrCount = await this.prisma.raiseRequest.count({
                where: {
                    companyId,
                    userId: { in: accessibleHrIds },
                    currentStep: 'HR',
                    status: 'MGR_APPROVED',
                },
            });
            return managerCount + hrCount;
        }
    }

    private async getOverdueRequests(type: 'leaves' | 'letters' | 'raises', overdueDate: Date): Promise<{ id: string; createdAt: Date; userName: string; currentStep: string; companyId: string }[]> {
        if (type === 'leaves') {
            const requests = await this.prisma.leaveRequest.findMany({
                where: {
                    status: { in: ['PENDING', 'MGR_APPROVED'] },
                    createdAt: { lt: overdueDate },
                },
                include: {
                    user: { select: { firstName: true, lastName: true } }
                },
            });
            return requests.map(r => ({
                id: r.id,
                createdAt: r.createdAt,
                userName: `${r.user.firstName} ${r.user.lastName}`,
                currentStep: r.currentStep,
                companyId: r.companyId || '',
            }));
        } else if (type === 'letters') {
            const requests = await this.prisma.letterRequest.findMany({
                where: {
                    status: { in: ['PENDING', 'MGR_APPROVED'] },
                    createdAt: { lt: overdueDate },
                },
                include: {
                    user: { select: { firstName: true, lastName: true } }
                },
            });
            return requests.map(r => ({
                id: r.id,
                createdAt: r.createdAt,
                userName: `${r.user.firstName} ${r.user.lastName}`,
                currentStep: r.currentStep,
                companyId: r.companyId || '',
            }));
        } else {
            const requests = await this.prisma.raiseRequest.findMany({
                where: {
                    status: { in: ['PENDING', 'MGR_APPROVED'] },
                    createdAt: { lt: overdueDate },
                },
                include: {
                    user: { select: { firstName: true, lastName: true } }
                },
            });
            return requests.map(r => ({
                id: r.id,
                createdAt: r.createdAt,
                userName: `${r.user.firstName} ${r.user.lastName}`,
                currentStep: r.currentStep,
                companyId: r.companyId || '',
            }));
        }
    }

    private async getApproverForRequest(type: 'leaves' | 'letters' | 'raises', request: { id: string; currentStep: string; companyId: string }): Promise<{ approverId: string | null, companyId: string | null }> {
        // بناءً على الخطوة الحالية، نحدد نوع الموافق المطلوب
        const permissionCode = request.currentStep === 'MANAGER'
            ? `${type.toUpperCase()}_APPROVE_MANAGER`
            : `${type.toUpperCase()}_APPROVE_HR`;

        // جلب أول موافق متاح ضمن نفس الشركة
        const approver = await this.prisma.userPermission.findFirst({
            where: {
                permission: { code: permissionCode },
                companyId: request.companyId, // التحقق من نفس الشركة
            },
            select: {
                userId: true,
                companyId: true
            },
        });

        return {
            approverId: approver?.userId || null,
            companyId: approver?.companyId || null
        };
    }

    private getRequestTypeLabel(type: 'leaves' | 'letters' | 'raises'): string {
        const labels = {
            leaves: 'إجازة',
            letters: 'خطاب',
            raises: 'زيادة',
        };
        return labels[type];
    }

    private getDaysOverdue(createdAt: Date): number {
        const now = new Date();
        const diffTime = Math.abs(now.getTime() - createdAt.getTime());
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    // ==================== Manual Trigger (for testing) ====================

    async triggerReminderManually() {
        this.logger.log('⚡ Manual trigger for reminders...');
        await this.sendDailyReminders();
        await this.checkOverdueRequests();
        return { message: 'Reminders triggered successfully' };
    }
}
