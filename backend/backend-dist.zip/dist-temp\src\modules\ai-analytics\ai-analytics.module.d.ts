export declare class AiAnalyticsModule {
}
