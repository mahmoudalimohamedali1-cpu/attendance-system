import {
    Injectable,
    NotFoundException,
    BadRequestException,
    ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../../common/prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { CreateTaskDto } from './dto/create-task.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { TaskQueryDto } from './dto/task-query.dto';
import {
    CreateTaskCategoryDto,
    UpdateTaskCategoryDto,
} from './dto/task-category.dto';
import {
    CreateTaskTemplateDto,
    UpdateTaskTemplateDto,
} from './dto/task-template.dto';
import {
    CreateChecklistDto,
    CreateChecklistItemDto,
    CreateCommentDto,
    CreateTimeLogDto,
    ReorderTaskDto,
} from './dto/task-actions.dto';
import { TaskStatus, NotificationType, Prisma } from '@prisma/client';

@Injectable()
export class TasksService {
    constructor(
        private prisma: PrismaService,
        private notificationsService: NotificationsService,
    ) { }

    // ============ TASKS CRUD ============

    async createTask(
        userId: string,
        companyId: string,
        dto: CreateTaskDto,
    ) {
        // If using template, apply template defaults
        let templateData = {};
        if (dto.templateId) {
            const template = await this.prisma.taskTemplate.findFirst({
                where: { id: dto.templateId, companyId },
            });
            if (template) {
                templateData = {
                    priority: dto.priority || template.defaultPriority,
                    dueDate: dto.dueDate
                        ? new Date(dto.dueDate)
                        : template.defaultDueDays
                            ? new Date(Date.now() + template.defaultDueDays * 24 * 60 * 60 * 1000)
                            : undefined,
                };
            }
        }

        const task = await this.prisma.task.create({
            data: {
                companyId,
                createdById: userId,
                title: dto.title,
                description: dto.description,
                priority: dto.priority || (templateData as any).priority || 'MEDIUM',
                status: dto.status || 'TODO',
                categoryId: dto.categoryId,
                templateId: dto.templateId,
                dueDate: dto.dueDate
                    ? new Date(dto.dueDate)
                    : (templateData as any).dueDate,
                startDate: dto.startDate ? new Date(dto.startDate) : undefined,
                assigneeId: dto.assigneeId,
                tags: dto.tags || [],
                customFields: dto.customFields as any,
            },
            include: {
                category: true,
                createdBy: { select: { id: true, firstName: true, lastName: true, avatar: true } },
                assignee: { select: { id: true, firstName: true, lastName: true, avatar: true } },
            },
        });

        // Log activity
        await this.logActivity(task.id, userId, 'CREATED', null, null, 'تم إنشاء المهمة');

        // If a template has checklist template, create checklists
        if (dto.templateId) {
            const template = await this.prisma.taskTemplate.findUnique({
                where: { id: dto.templateId },
            });
            if (template?.checklistTemplate) {
                const checklists = template.checklistTemplate as any[];
                for (let i = 0; i < checklists.length; i++) {
                    const cl = checklists[i];
                    const checklist = await this.prisma.taskChecklist.create({
                        data: {
                            taskId: task.id,
                            title: cl.title,
                            order: i,
                        },
                    });
                    if (cl.items && Array.isArray(cl.items)) {
                        for (let j = 0; j < cl.items.length; j++) {
                            await this.prisma.taskChecklistItem.create({
                                data: {
                                    checklistId: checklist.id,
                                    content: typeof cl.items[j] === 'string' ? cl.items[j] : cl.items[j].content,
                                    order: j,
                                },
                            });
                        }
                    }
                }
            }
        }

        // Notify assignee if assigned
        if (dto.assigneeId && dto.assigneeId !== userId) {
            await this.notificationsService.create({
                companyId,
                userId: dto.assigneeId,
                type: NotificationType.GENERAL,
                title: 'مهمة جديدة مسندة إليك',
                body: `تم تكليفك بمهمة: ${dto.title}`,
                data: { taskId: task.id },
            });
        }

        return task;
    }

    async getTasks(companyId: string, query: TaskQueryDto) {
        const {
            search,
            status,
            priority,
            categoryId,
            assigneeId,
            createdById,
            dueDateFrom,
            dueDateTo,
            tags,
            page = 1,
            limit = 20,
            sortBy = 'createdAt',
            sortOrder = 'desc',
        } = query;

        const where: Prisma.TaskWhereInput = {
            companyId,
            ...(search && {
                OR: [
                    { title: { contains: search, mode: 'insensitive' } },
                    { description: { contains: search, mode: 'insensitive' } },
                ],
            }),
            ...(status && { status }),
            ...(priority && { priority }),
            ...(categoryId && { categoryId }),
            ...(assigneeId && { assigneeId }),
            ...(createdById && { createdById }),
            ...(dueDateFrom || dueDateTo
                ? {
                    dueDate: {
                        ...(dueDateFrom && { gte: new Date(dueDateFrom) }),
                        ...(dueDateTo && { lte: new Date(dueDateTo) }),
                    },
                }
                : {}),
            ...(tags && { tags: { hasSome: tags.split(',') } }),
        };

        const [tasks, total] = await Promise.all([
            this.prisma.task.findMany({
                where,
                include: {
                    category: true,
                    createdBy: { select: { id: true, firstName: true, lastName: true, avatar: true } },
                    assignee: { select: { id: true, firstName: true, lastName: true, avatar: true } },
                    checklists: {
                        include: { items: true },
                    },
                    _count: {
                        select: { comments: true, attachments: true },
                    },
                },
                orderBy: { [sortBy]: sortOrder },
                skip: (page - 1) * limit,
                take: limit,
            }),
            this.prisma.task.count({ where }),
        ]);

        return {
            data: tasks,
            meta: {
                total,
                page,
                limit,
                totalPages: Math.ceil(total / limit),
            },
        };
    }

    /**
     * Get tasks assigned to or created by the current user (for mobile app)
     */
    async getMyTasks(userId: string, companyId: string) {
        const tasks = await this.prisma.task.findMany({
            where: {
                companyId,
                status: { not: 'CANCELLED' },
                OR: [
                    { assigneeId: userId },
                    { createdById: userId },
                ],
            },
            include: {
                category: true,
                createdBy: { select: { id: true, firstName: true, lastName: true, avatar: true } },
                assignee: { select: { id: true, firstName: true, lastName: true, avatar: true } },
                checklists: { include: { items: true } },
            },
            orderBy: [
                { status: 'asc' },
                { priority: 'asc' },
                { dueDate: 'asc' },
            ],
        });

        return tasks;
    }

    async getTaskById(id: string, companyId: string) {
        const task = await this.prisma.task.findFirst({
            where: { id, companyId },
            include: {
                category: true,
                template: true,
                createdBy: { select: { id: true, firstName: true, lastName: true, avatar: true, email: true } },
                assignee: { select: { id: true, firstName: true, lastName: true, avatar: true, email: true } },
                assignments: {
                    include: {
                        user: { select: { id: true, firstName: true, lastName: true, avatar: true } },
                    },
                },
                watchers: {
                    include: {
                        user: { select: { id: true, firstName: true, lastName: true, avatar: true } },
                    },
                },
                checklists: {
                    include: { items: { orderBy: { order: 'asc' } } },
                    orderBy: { order: 'asc' },
                },
                comments: {
                    include: {
                        author: { select: { id: true, firstName: true, lastName: true, avatar: true } },
                    },
                    orderBy: { createdAt: 'desc' },
                },
                attachments: {
                    include: {
                        uploadedBy: { select: { id: true, firstName: true, lastName: true } },
                    },
                },
                timeLogs: {
                    include: {
                        user: { select: { id: true, firstName: true, lastName: true } },
                    },
                    orderBy: { startTime: 'desc' },
                },
                blockedBy: {
                    include: {
                        blockingTask: { select: { id: true, title: true, status: true } },
                    },
                },
                blocks: {
                    include: {
                        blockedTask: { select: { id: true, title: true, status: true } },
                    },
                },
                activities: {
                    include: {
                        user: { select: { id: true, firstName: true, lastName: true } },
                    },
                    orderBy: { createdAt: 'desc' },
                    take: 20,
                },
            },
        });

        if (!task) {
            throw new NotFoundException('المهمة غير موجودة');
        }

        return task;
    }

    async updateTask(
        id: string,
        companyId: string,
        userId: string,
        dto: UpdateTaskDto,
    ) {
        const existing = await this.prisma.task.findFirst({
            where: { id, companyId },
        });

        if (!existing) {
            throw new NotFoundException('المهمة غير موجودة');
        }

        // Track changes for activity log
        const changes: { field: string; oldVal: any; newVal: any }[] = [];

        if (dto.status && dto.status !== existing.status) {
            changes.push({ field: 'status', oldVal: existing.status, newVal: dto.status });
        }
        if (dto.priority && dto.priority !== existing.priority) {
            changes.push({ field: 'priority', oldVal: existing.priority, newVal: dto.priority });
        }
        if (dto.assigneeId !== undefined && dto.assigneeId !== existing.assigneeId) {
            changes.push({ field: 'assigneeId', oldVal: existing.assigneeId, newVal: dto.assigneeId });
        }

        const task = await this.prisma.task.update({
            where: { id },
            data: {
                ...(dto.title && { title: dto.title }),
                ...(dto.description !== undefined && { description: dto.description }),
                ...(dto.status && { status: dto.status }),
                ...(dto.priority && { priority: dto.priority }),
                ...(dto.categoryId !== undefined && { categoryId: dto.categoryId }),
                ...(dto.dueDate !== undefined && {
                    dueDate: dto.dueDate ? new Date(dto.dueDate) : null,
                }),
                ...(dto.startDate !== undefined && {
                    startDate: dto.startDate ? new Date(dto.startDate) : null,
                }),
                ...(dto.assigneeId !== undefined && { assigneeId: dto.assigneeId }),
                ...(dto.tags && { tags: dto.tags }),
                ...(dto.customFields && { customFields: dto.customFields as any }),
                ...(dto.progress !== undefined && { progress: dto.progress }),
                ...(dto.order !== undefined && { order: dto.order }),
                ...(dto.status === 'COMPLETED' && { completedAt: new Date() }),
            },
            include: {
                category: true,
                assignee: { select: { id: true, firstName: true, lastName: true, avatar: true } },
            },
        });

        // Log activities for changes
        for (const change of changes) {
            await this.logActivity(
                id,
                userId,
                'UPDATED',
                change.oldVal,
                change.newVal,
                `تم تغيير ${this.getFieldLabel(change.field)}`,
            );
        }

        // Notify new assignee
        if (dto.assigneeId && dto.assigneeId !== existing.assigneeId && dto.assigneeId !== userId) {
            await this.notificationsService.create({
                companyId,
                userId: dto.assigneeId,
                type: NotificationType.GENERAL,
                title: 'تم تعيينك في مهمة',
                body: `تم تكليفك بمهمة: ${task.title}`,
                data: { taskId: id },
            });
        }

        return task;
    }

    async deleteTask(id: string, companyId: string, userId: string) {
        const task = await this.prisma.task.findFirst({
            where: { id, companyId },
        });

        if (!task) {
            throw new NotFoundException('المهمة غير موجودة');
        }

        // Check permission (only creator or admin can delete)
        const user = await this.prisma.user.findUnique({ where: { id: userId } });
        if (task.createdById !== userId && user?.role !== 'ADMIN' && user?.role !== 'HR') {
            throw new ForbiddenException('ليس لديك صلاحية حذف هذه المهمة');
        }

        await this.prisma.task.delete({ where: { id } });

        return { message: 'تم حذف المهمة بنجاح' };
    }

    // ============ KANBAN ============

    async getKanbanBoard(companyId: string, categoryId?: string, userId?: string) {
        const where: Prisma.TaskWhereInput = {
            companyId,
            status: { not: 'CANCELLED' },
            ...(categoryId && { categoryId }),
            ...(userId && {
                OR: [
                    { assigneeId: userId },
                    { createdById: userId },
                    { assignments: { some: { userId } } },
                    { watchers: { some: { userId } } },
                ],
            }),
        };

        const tasks = await this.prisma.task.findMany({
            where,
            include: {
                category: true,
                assignee: { select: { id: true, firstName: true, lastName: true, avatar: true } },
                checklists: { include: { items: true } },
                _count: { select: { comments: true, attachments: true } },
            },
            orderBy: [{ order: 'asc' }, { createdAt: 'desc' }],
        });

        // Group by status
        const board: Record<string, typeof tasks> = {
            BACKLOG: [],
            TODO: [],
            IN_PROGRESS: [],
            IN_REVIEW: [],
            BLOCKED: [],
            COMPLETED: [],
        };

        for (const task of tasks) {
            if (board[task.status]) {
                board[task.status].push(task);
            }
        }

        return board;
    }

    async reorderTask(id: string, companyId: string, userId: string, dto: ReorderTaskDto) {
        const task = await this.prisma.task.findFirst({
            where: { id, companyId },
        });

        if (!task) {
            throw new NotFoundException('المهمة غير موجودة');
        }

        const oldStatus = task.status;
        const newStatus = dto.status as TaskStatus;

        // Update task
        await this.prisma.task.update({
            where: { id },
            data: {
                status: newStatus,
                order: dto.order,
                ...(newStatus === 'COMPLETED' && { completedAt: new Date() }),
            },
        });

        // Log if status changed
        if (oldStatus !== newStatus) {
            await this.logActivity(id, userId, 'STATUS_CHANGED', oldStatus, newStatus, 'تم تغيير حالة المهمة');
        }

        return { success: true };
    }

    // ============ CHECKLISTS ============

    async addChecklist(taskId: string, companyId: string, userId: string, dto: CreateChecklistDto) {
        const task = await this.prisma.task.findFirst({ where: { id: taskId, companyId } });
        if (!task) throw new NotFoundException('المهمة غير موجودة');

        const maxOrder = await this.prisma.taskChecklist.aggregate({
            where: { taskId },
            _max: { order: true },
        });

        const checklist = await this.prisma.taskChecklist.create({
            data: {
                taskId,
                title: dto.title,
                order: (maxOrder._max.order || 0) + 1,
            },
            include: { items: true },
        });

        await this.logActivity(taskId, userId, 'CHECKLIST_ADDED', null, dto.title, 'تم إضافة قائمة تحقق');

        return checklist;
    }

    async addChecklistItem(
        checklistId: string,
        companyId: string,
        userId: string,
        dto: CreateChecklistItemDto,
    ) {
        const checklist = await this.prisma.taskChecklist.findFirst({
            where: { id: checklistId },
            include: { task: true },
        });

        if (!checklist || checklist.task.companyId !== companyId) {
            throw new NotFoundException('قائمة التحقق غير موجودة');
        }

        const maxOrder = await this.prisma.taskChecklistItem.aggregate({
            where: { checklistId },
            _max: { order: true },
        });

        const item = await this.prisma.taskChecklistItem.create({
            data: {
                checklistId,
                content: dto.content,
                order: (maxOrder._max.order || 0) + 1,
            },
        });

        await this.updateTaskProgress(checklist.taskId);

        return item;
    }

    async toggleChecklistItem(
        itemId: string,
        companyId: string,
        userId: string,
        isCompleted: boolean,
    ) {
        const item = await this.prisma.taskChecklistItem.findFirst({
            where: { id: itemId },
            include: { checklist: { include: { task: true } } },
        });

        if (!item || item.checklist.task.companyId !== companyId) {
            throw new NotFoundException('العنصر غير موجود');
        }

        const updated = await this.prisma.taskChecklistItem.update({
            where: { id: itemId },
            data: {
                isCompleted,
                completedAt: isCompleted ? new Date() : null,
                completedById: isCompleted ? userId : null,
            },
        });

        await this.updateTaskProgress(item.checklist.taskId);

        return updated;
    }

    async deleteChecklistItem(itemId: string, companyId: string, userId: string) {
        const item = await this.prisma.taskChecklistItem.findFirst({
            where: { id: itemId },
            include: { checklist: { include: { task: true } } },
        });

        if (!item || item.checklist.task.companyId !== companyId) {
            throw new NotFoundException('العنصر غير موجود');
        }

        await this.prisma.taskChecklistItem.delete({
            where: { id: itemId },
        });

        await this.updateTaskProgress(item.checklist.taskId);
        await this.logActivity(
            item.checklist.taskId,
            userId,
            'CHECKLIST_ITEM_DELETED',
            item.content,
            null,
            'تم حذف عنصر من القائمة',
        );

        return { message: 'تم حذف العنصر' };
    }

    private async updateTaskProgress(taskId: string) {
        const checklists = await this.prisma.taskChecklist.findMany({
            where: { taskId },
            include: { items: true },
        });

        const allItems = checklists.flatMap((c) => c.items);
        if (allItems.length === 0) return;

        const completedCount = allItems.filter((i) => i.isCompleted).length;
        const progress = Math.round((completedCount / allItems.length) * 100);

        await this.prisma.task.update({
            where: { id: taskId },
            data: { progress },
        });
    }

    // ============ COMMENTS ============

    async addComment(taskId: string, companyId: string, userId: string, dto: CreateCommentDto) {
        const task = await this.prisma.task.findFirst({ where: { id: taskId, companyId } });
        if (!task) throw new NotFoundException('المهمة غير موجودة');

        const comment = await this.prisma.taskComment.create({
            data: {
                taskId,
                authorId: userId,
                content: dto.content,
                mentions: dto.mentions || [],
            },
            include: {
                author: { select: { id: true, firstName: true, lastName: true, avatar: true } },
            },
        });

        // Notify mentioned users
        if (dto.mentions && dto.mentions.length > 0) {
            for (const mentionedUserId of dto.mentions) {
                if (mentionedUserId !== userId) {
                    await this.notificationsService.create({
                        companyId,
                        userId: mentionedUserId,
                        type: NotificationType.GENERAL,
                        title: 'تم ذكرك في تعليق',
                        body: `تم ذكرك في تعليق على المهمة: ${task.title}`,
                        data: { taskId, commentId: comment.id },
                    });
                }
            }
        }

        // Notify task assignee
        if (task.assigneeId && task.assigneeId !== userId) {
            await this.notificationsService.create({
                companyId,
                userId: task.assigneeId,
                type: NotificationType.GENERAL,
                title: 'تعليق جديد على المهمة',
                body: `تم إضافة تعليق جديد على المهمة: ${task.title}`,
                data: { taskId, commentId: comment.id },
            });
        }

        await this.logActivity(taskId, userId, 'COMMENT_ADDED', null, null, 'تم إضافة تعليق');

        return comment;
    }

    async deleteComment(commentId: string, companyId: string, userId: string) {
        const comment = await this.prisma.taskComment.findFirst({
            where: { id: commentId },
            include: { task: true },
        });

        if (!comment || comment.task.companyId !== companyId) {
            throw new NotFoundException('التعليق غير موجود');
        }

        if (comment.authorId !== userId) {
            throw new ForbiddenException('لا يمكنك حذف تعليق شخص آخر');
        }

        await this.prisma.taskComment.delete({ where: { id: commentId } });

        return { message: 'تم حذف التعليق' };
    }

    // ============ TIME LOGS ============

    async addTimeLog(taskId: string, companyId: string, userId: string, dto: CreateTimeLogDto) {
        const task = await this.prisma.task.findFirst({ where: { id: taskId, companyId } });
        if (!task) throw new NotFoundException('المهمة غير موجودة');

        let duration = dto.duration;
        if (!duration && dto.startTime && dto.endTime) {
            const start = new Date(dto.startTime);
            const end = new Date(dto.endTime);
            duration = Math.round((end.getTime() - start.getTime()) / (1000 * 60));
        }

        const timeLog = await this.prisma.taskTimeLog.create({
            data: {
                taskId,
                userId,
                startTime: new Date(dto.startTime),
                endTime: dto.endTime ? new Date(dto.endTime) : null,
                duration,
                description: dto.description,
                isBillable: dto.isBillable || false,
            },
            include: {
                user: { select: { id: true, firstName: true, lastName: true } },
            },
        });

        await this.logActivity(
            taskId,
            userId,
            'TIME_LOGGED',
            null,
            `${duration} دقيقة`,
            'تم تسجيل وقت عمل',
        );

        return timeLog;
    }

    // ============ CATEGORIES ============

    async getCategories(companyId: string) {
        return this.prisma.taskCategory.findMany({
            where: { companyId, isActive: true },
            include: {
                _count: { select: { tasks: true } },
            },
            orderBy: { order: 'asc' },
        });
    }

    async createCategory(companyId: string, dto: CreateTaskCategoryDto) {
        const maxOrder = await this.prisma.taskCategory.aggregate({
            where: { companyId },
            _max: { order: true },
        });

        return this.prisma.taskCategory.create({
            data: {
                companyId,
                name: dto.name,
                nameEn: dto.nameEn,
                color: dto.color || '#3B82F6',
                icon: dto.icon,
                order: (maxOrder._max.order || 0) + 1,
            },
        });
    }

    async updateCategory(id: string, companyId: string, dto: UpdateTaskCategoryDto) {
        const category = await this.prisma.taskCategory.findFirst({
            where: { id, companyId },
        });

        if (!category) throw new NotFoundException('الفئة غير موجودة');

        return this.prisma.taskCategory.update({
            where: { id },
            data: dto,
        });
    }

    async deleteCategory(id: string, companyId: string) {
        const category = await this.prisma.taskCategory.findFirst({
            where: { id, companyId },
            include: { _count: { select: { tasks: true } } },
        });

        if (!category) throw new NotFoundException('الفئة غير موجودة');
        if (category._count.tasks > 0) {
            throw new BadRequestException('لا يمكن حذف فئة تحتوي على مهام');
        }

        await this.prisma.taskCategory.delete({ where: { id } });
        return { message: 'تم حذف الفئة' };
    }

    // ============ TEMPLATES ============

    async getTemplates(companyId: string) {
        return this.prisma.taskTemplate.findMany({
            where: { companyId, isActive: true },
            include: {
                category: true,
                _count: { select: { tasks: true } },
            },
            orderBy: { createdAt: 'desc' },
        });
    }

    async createTemplate(companyId: string, dto: CreateTaskTemplateDto) {
        return this.prisma.taskTemplate.create({
            data: {
                companyId,
                name: dto.name,
                nameEn: dto.nameEn,
                description: dto.description,
                categoryId: dto.categoryId,
                defaultPriority: dto.defaultPriority || 'MEDIUM',
                defaultDueDays: dto.defaultDueDays,
                workflowType: dto.workflowType,
                checklistTemplate: dto.checklistTemplate as any,
            },
            include: { category: true },
        });
    }

    async updateTemplate(id: string, companyId: string, dto: UpdateTaskTemplateDto) {
        const template = await this.prisma.taskTemplate.findFirst({
            where: { id, companyId },
        });

        if (!template) throw new NotFoundException('القالب غير موجود');

        return this.prisma.taskTemplate.update({
            where: { id },
            data: {
                ...(dto.name && { name: dto.name }),
                ...(dto.nameEn !== undefined && { nameEn: dto.nameEn }),
                ...(dto.description !== undefined && { description: dto.description }),
                ...(dto.categoryId !== undefined && { categoryId: dto.categoryId }),
                ...(dto.defaultPriority && { defaultPriority: dto.defaultPriority }),
                ...(dto.defaultDueDays !== undefined && { defaultDueDays: dto.defaultDueDays }),
                ...(dto.workflowType !== undefined && { workflowType: dto.workflowType }),
                ...(dto.checklistTemplate && { checklistTemplate: dto.checklistTemplate as any }),
            },
            include: { category: true },
        });
    }

    async deleteTemplate(id: string, companyId: string) {
        const template = await this.prisma.taskTemplate.findFirst({
            where: { id, companyId },
        });

        if (!template) throw new NotFoundException('القالب غير موجود');

        // Soft delete
        await this.prisma.taskTemplate.update({
            where: { id },
            data: { isActive: false },
        });

        return { message: 'تم حذف القالب' };
    }

    // ============ WATCHERS ============

    async addWatcher(taskId: string, companyId: string, userId: string) {
        const task = await this.prisma.task.findFirst({ where: { id: taskId, companyId } });
        if (!task) throw new NotFoundException('المهمة غير موجودة');

        const existing = await this.prisma.taskWatcher.findFirst({
            where: { taskId, userId },
        });

        if (existing) return { message: 'أنت تتابع هذه المهمة مسبقاً' };

        await this.prisma.taskWatcher.create({
            data: { taskId, userId },
        });

        return { message: 'تمت إضافتك لمتابعة المهمة' };
    }

    async removeWatcher(taskId: string, companyId: string, userId: string) {
        const task = await this.prisma.task.findFirst({ where: { id: taskId, companyId } });
        if (!task) throw new NotFoundException('المهمة غير موجودة');

        await this.prisma.taskWatcher.deleteMany({
            where: { taskId, userId },
        });

        return { message: 'تم إلغاء متابعتك للمهمة' };
    }

    // ============ DEPENDENCIES ============

    async addDependency(
        blockedTaskId: string,
        blockingTaskId: string,
        companyId: string,
        userId: string,
    ) {
        const task1 = await this.prisma.task.findFirst({ where: { id: blockedTaskId, companyId } });
        const task2 = await this.prisma.task.findFirst({ where: { id: blockingTaskId, companyId } });

        if (!task1 || !task2) throw new NotFoundException('المهمة غير موجودة');
        if (blockedTaskId === blockingTaskId) {
            throw new BadRequestException('لا يمكن أن تكون المهمة معتمدة على نفسها');
        }

        // Check for circular dependency
        const existingReverse = await this.prisma.taskDependency.findFirst({
            where: { blockedTaskId: blockingTaskId, blockingTaskId: blockedTaskId },
        });
        if (existingReverse) {
            throw new BadRequestException('سيؤدي هذا إلى اعتماد دائري');
        }

        await this.prisma.taskDependency.create({
            data: { blockedTaskId, blockingTaskId },
        });

        await this.logActivity(
            blockedTaskId,
            userId,
            'DEPENDENCY_ADDED',
            null,
            task2.title,
            'تم إضافة اعتماد',
        );

        return { message: 'تم إضافة الاعتماد' };
    }

    async removeDependency(blockedTaskId: string, blockingTaskId: string, companyId: string) {
        await this.prisma.taskDependency.deleteMany({
            where: { blockedTaskId, blockingTaskId },
        });

        return { message: 'تم إزالة الاعتماد' };
    }

    // ============ STATISTICS ============

    async getTaskStats(companyId: string, userId?: string) {
        const where: Prisma.TaskWhereInput = {
            companyId,
            ...(userId && { OR: [{ assigneeId: userId }, { createdById: userId }] }),
        };

        const [total, byStatus, byPriority, overdue] = await Promise.all([
            this.prisma.task.count({ where }),
            this.prisma.task.groupBy({
                by: ['status'],
                where,
                _count: true,
            }),
            this.prisma.task.groupBy({
                by: ['priority'],
                where,
                _count: true,
            }),
            this.prisma.task.count({
                where: {
                    ...where,
                    dueDate: { lt: new Date() },
                    status: { notIn: ['COMPLETED', 'CANCELLED'] },
                },
            }),
        ]);

        return {
            total,
            byStatus: Object.fromEntries(byStatus.map((s) => [s.status, s._count])),
            byPriority: Object.fromEntries(byPriority.map((p) => [p.priority, p._count])),
            overdue,
        };
    }

    // ============ ATTACHMENTS ============

    async addAttachment(
        taskId: string,
        companyId: string,
        userId: string,
        file: { filename: string; originalname: string; mimetype: string; size: number; path: string },
    ) {
        const task = await this.prisma.task.findFirst({ where: { id: taskId, companyId } });
        if (!task) throw new NotFoundException('المهمة غير موجودة');

        const attachment = await this.prisma.taskAttachment.create({
            data: {
                taskId,
                uploadedById: userId,
                fileName: file.originalname,
                storagePath: `/uploads/tasks/${file.filename}`,
                mimeType: file.mimetype,
                fileSize: file.size,
            },
            include: {
                uploadedBy: { select: { id: true, firstName: true, lastName: true } },
            },
        });

        await this.logActivity(taskId, userId, 'ATTACHMENT_ADDED', null, file.originalname, 'تم إضافة مرفق');

        return attachment;
    }

    async deleteAttachment(attachmentId: string, companyId: string, userId: string) {
        const attachment = await this.prisma.taskAttachment.findFirst({
            where: { id: attachmentId },
            include: { task: true },
        });

        if (!attachment || attachment.task.companyId !== companyId) {
            throw new NotFoundException('المرفق غير موجود');
        }

        await this.prisma.taskAttachment.delete({ where: { id: attachmentId } });

        await this.logActivity(attachment.taskId, userId, 'ATTACHMENT_DELETED', attachment.fileName, null, 'تم حذف مرفق');

        return { message: 'تم حذف المرفق' };
    }

    // ============ HELPERS ============

    private async logActivity(
        taskId: string,
        userId: string,
        action: string,
        oldValue: any,
        newValue: any,
        description: string,
    ) {
        await this.prisma.taskActivityLog.create({
            data: {
                taskId,
                userId,
                action,
                oldValue: oldValue ? String(oldValue) : null,
                newValue: newValue ? String(newValue) : null,
                description,
            },
        });
    }

    private getFieldLabel(field: string): string {
        const labels: Record<string, string> = {
            status: 'الحالة',
            priority: 'الأولوية',
            assigneeId: 'المكلف',
            dueDate: 'تاريخ الاستحقاق',
            title: 'العنوان',
        };
        return labels[field] || field;
    }

    // ==================== WORKFLOW METHODS ====================

    /**
     * Request review - changes status to PENDING_REVIEW
     */
    async requestReview(taskId: string, companyId: string, userId: string) {
        const task = await this.prisma.task.findFirst({
            where: { id: taskId, companyId },
            include: { reviewer: true },
        });

        if (!task) throw new NotFoundException('المهمة غير موجودة');
        if (task.assigneeId !== userId) {
            throw new ForbiddenException('فقط المنفذ يمكنه طلب المراجعة');
        }
        if (!task.reviewerId) {
            throw new BadRequestException('لم يتم تعيين مراجع لهذه المهمة');
        }

        const updated = await this.prisma.task.update({
            where: { id: taskId },
            data: {
                status: 'PENDING_REVIEW',
                reviewRequestedAt: new Date(),
            },
        });

        // Create approval record
        await this.prisma.taskApproval.create({
            data: {
                taskId,
                userId,
                action: 'SUBMITTED_FOR_REVIEW',
                comment: 'طلب مراجعة المهمة',
            },
        });

        // Notify reviewer
        if (task.reviewer) {
            await this.notificationsService.sendNotification(
                task.reviewerId!,
                'TASK_UPDATED' as any,
                'طلب مراجعة مهمة',
                `تم طلب مراجعة المهمة: ${task.title}`,
                { taskId },
            );
        }

        await this.logActivity(taskId, userId, 'STATUS_CHANGED', 'IN_PROGRESS', 'PENDING_REVIEW', 'طلب مراجعة');

        return updated;
    }

    /**
     * Start reviewing - changes status to IN_REVIEW
     */
    async startReview(taskId: string, companyId: string, userId: string) {
        const task = await this.prisma.task.findFirst({
            where: { id: taskId, companyId },
        });

        if (!task) throw new NotFoundException('المهمة غير موجودة');
        if (task.reviewerId !== userId) {
            throw new ForbiddenException('فقط المراجع المعين يمكنه بدء المراجعة');
        }

        const updated = await this.prisma.task.update({
            where: { id: taskId },
            data: { status: 'IN_REVIEW' },
        });

        await this.logActivity(taskId, userId, 'STATUS_CHANGED', 'PENDING_REVIEW', 'IN_REVIEW', 'بدأ المراجعة');

        return updated;
    }

    /**
     * Approve task - changes status to APPROVED or COMPLETED
     */
    async approveTask(taskId: string, companyId: string, userId: string, comment?: string) {
        const task = await this.prisma.task.findFirst({
            where: { id: taskId, companyId },
            include: { assignee: true, approver: true },
        });

        if (!task) throw new NotFoundException('المهمة غير موجودة');

        const isReviewer = task.reviewerId === userId;
        const isApprover = task.approverId === userId;

        if (!isReviewer && !isApprover) {
            throw new ForbiddenException('غير مصرح لك بالموافقة على هذه المهمة');
        }

        let newStatus = 'APPROVED';

        // If reviewer approves and there's an approver, wait for final approval
        if (isReviewer && task.approverId && task.approverId !== userId) {
            newStatus = 'APPROVED'; // Waiting for final approver
        } else {
            // Final approval - mark as completed
            newStatus = 'COMPLETED';
        }

        const updated = await this.prisma.task.update({
            where: { id: taskId },
            data: {
                status: newStatus as any,
                reviewedAt: isReviewer ? new Date() : task.reviewedAt,
                approvedAt: new Date(),
                completedAt: newStatus === 'COMPLETED' ? new Date() : undefined,
            },
        });

        // Create approval record
        await this.prisma.taskApproval.create({
            data: {
                taskId,
                userId,
                action: 'APPROVED',
                comment: comment || 'تمت الموافقة على المهمة',
            },
        });

        // Notify assignee
        if (task.assignee) {
            await this.notificationsService.sendNotification(
                task.assigneeId!,
                'TASK_UPDATED' as any,
                'تمت الموافقة على مهمتك',
                `تمت الموافقة على المهمة: ${task.title}`,
                { taskId },
            );
        }

        await this.logActivity(taskId, userId, 'STATUS_CHANGED', task.status, newStatus, 'تمت الموافقة');

        return updated;
    }

    /**
     * Reject task - changes status to REJECTED
     */
    async rejectTask(taskId: string, companyId: string, userId: string, reason: string) {
        const task = await this.prisma.task.findFirst({
            where: { id: taskId, companyId },
            include: { assignee: true },
        });

        if (!task) throw new NotFoundException('المهمة غير موجودة');

        const isReviewer = task.reviewerId === userId;
        const isApprover = task.approverId === userId;

        if (!isReviewer && !isApprover) {
            throw new ForbiddenException('غير مصرح لك برفض هذه المهمة');
        }

        const updated = await this.prisma.task.update({
            where: { id: taskId },
            data: {
                status: 'REJECTED',
                rejectedAt: new Date(),
                rejectionReason: reason,
            },
        });

        // Create approval record
        await this.prisma.taskApproval.create({
            data: {
                taskId,
                userId,
                action: 'REJECTED',
                comment: reason,
            },
        });

        // Notify assignee
        if (task.assignee) {
            await this.notificationsService.sendNotification(
                task.assigneeId!,
                'TASK_UPDATED' as any,
                'تم رفض مهمتك',
                `تم رفض المهمة: ${task.title}. السبب: ${reason}`,
                { taskId },
            );
        }

        await this.logActivity(taskId, userId, 'STATUS_CHANGED', task.status, 'REJECTED', `رفض: ${reason}`);

        return updated;
    }

    /**
     * Request changes - sends back to assignee for modifications
     */
    async requestChanges(taskId: string, companyId: string, userId: string, feedback: string) {
        const task = await this.prisma.task.findFirst({
            where: { id: taskId, companyId },
            include: { assignee: true },
        });

        if (!task) throw new NotFoundException('المهمة غير موجودة');

        const isReviewer = task.reviewerId === userId;
        const isApprover = task.approverId === userId;

        if (!isReviewer && !isApprover) {
            throw new ForbiddenException('غير مصرح لك بطلب تعديلات');
        }

        const updated = await this.prisma.task.update({
            where: { id: taskId },
            data: {
                status: 'IN_PROGRESS', // Back to work
            },
        });

        // Create approval record
        await this.prisma.taskApproval.create({
            data: {
                taskId,
                userId,
                action: 'CHANGES_REQUESTED',
                comment: feedback,
            },
        });

        // Notify assignee
        if (task.assignee) {
            await this.notificationsService.sendNotification(
                task.assigneeId!,
                'TASK_UPDATED' as any,
                'مطلوب تعديلات على مهمتك',
                `مطلوب تعديلات على المهمة: ${task.title}. الملاحظات: ${feedback}`,
                { taskId },
            );
        }

        await this.logActivity(taskId, userId, 'STATUS_CHANGED', task.status, 'IN_PROGRESS', `طلب تعديلات: ${feedback}`);

        return updated;
    }

    /**
     * Get approval history for a task
     */
    async getApprovalHistory(taskId: string, companyId: string) {
        const task = await this.prisma.task.findFirst({
            where: { id: taskId, companyId },
        });

        if (!task) throw new NotFoundException('المهمة غير موجودة');

        return this.prisma.taskApproval.findMany({
            where: { taskId },
            include: {
                user: {
                    select: { id: true, firstName: true, lastName: true, avatar: true },
                },
            },
            orderBy: { createdAt: 'desc' },
        });
    }

    // ==================== EVIDENCE METHODS ====================

    /**
     * Submit evidence for task completion
     */
    async submitEvidence(
        taskId: string,
        companyId: string,
        userId: string,
        data: {
            description?: string;
            fileUrl?: string;
            fileName?: string;
            fileType?: string;
            fileSize?: number;
            latitude?: number;
            longitude?: number;
            locationName?: string;
        },
    ) {
        const task = await this.prisma.task.findFirst({
            where: { id: taskId, companyId },
            include: { reviewer: true, approver: true },
        });

        if (!task) throw new NotFoundException('المهمة غير موجودة');

        const evidence = await this.prisma.taskEvidence.create({
            data: {
                taskId,
                submittedById: userId,
                ...data,
            },
            include: {
                submittedBy: {
                    select: { id: true, firstName: true, lastName: true, avatar: true },
                },
            },
        });

        // Notify reviewer/approver
        const notifyUserId = task.reviewerId || task.approverId;
        if (notifyUserId) {
            await this.notificationsService.sendNotification(
                notifyUserId,
                'TASK_UPDATED' as any,
                'تم تقديم إثبات إنجاز',
                `تم تقديم إثبات إنجاز للمهمة: ${task.title}`,
                { taskId, evidenceId: evidence.id },
            );
        }

        await this.logActivity(taskId, userId, 'EVIDENCE_SUBMITTED' as any, null, evidence.id, 'تقديم إثبات إنجاز');

        return evidence;
    }

    /**
     * Get all evidences for a task
     */
    async getEvidences(taskId: string, companyId: string) {
        const task = await this.prisma.task.findFirst({
            where: { id: taskId, companyId },
        });

        if (!task) throw new NotFoundException('المهمة غير موجودة');

        return this.prisma.taskEvidence.findMany({
            where: { taskId },
            include: {
                submittedBy: {
                    select: { id: true, firstName: true, lastName: true, avatar: true },
                },
                verifiedBy: {
                    select: { id: true, firstName: true, lastName: true, avatar: true },
                },
            },
            orderBy: { createdAt: 'desc' },
        });
    }

    /**
     * Verify evidence (approve/reject)
     */
    async verifyEvidence(
        evidenceId: string,
        companyId: string,
        userId: string,
        status: 'APPROVED' | 'REJECTED',
        comment?: string,
    ) {
        const evidence = await this.prisma.taskEvidence.findFirst({
            where: { id: evidenceId },
            include: {
                task: true,
                submittedBy: true,
            },
        });

        if (!evidence) throw new NotFoundException('الإثبات غير موجود');
        if (evidence.task.companyId !== companyId) {
            throw new ForbiddenException('غير مصرح بالوصول');
        }

        // Only reviewer or approver can verify
        const task = evidence.task;
        const isReviewer = task.reviewerId === userId;
        const isApprover = task.approverId === userId;

        if (!isReviewer && !isApprover) {
            throw new ForbiddenException('فقط المراجع أو المعتمد يمكنه التحقق من الإثبات');
        }

        const updated = await this.prisma.taskEvidence.update({
            where: { id: evidenceId },
            data: {
                status,
                verifiedById: userId,
                verifiedAt: new Date(),
                verificationComment: comment,
            },
            include: {
                submittedBy: {
                    select: { id: true, firstName: true, lastName: true, avatar: true },
                },
                verifiedBy: {
                    select: { id: true, firstName: true, lastName: true, avatar: true },
                },
            },
        });

        // Notify submitter
        const statusAr = status === 'APPROVED' ? 'تم اعتماد' : 'تم رفض';
        await this.notificationsService.sendNotification(
            evidence.submittedById,
            'TASK_UPDATED' as any,
            `${statusAr} إثبات الإنجاز`,
            `${statusAr} إثبات الإنجاز للمهمة: ${task.title}`,
            { taskId: task.id, evidenceId },
        );

        await this.logActivity(
            task.id,
            userId,
            'EVIDENCE_VERIFIED' as any,
            null,
            status,
            `${statusAr} إثبات الإنجاز`,
        );

        return updated;
    }

    /**
     * Delete evidence
     */
    async deleteEvidence(evidenceId: string, companyId: string, userId: string) {
        const evidence = await this.prisma.taskEvidence.findFirst({
            where: { id: evidenceId },
            include: { task: true },
        });

        if (!evidence) throw new NotFoundException('الإثبات غير موجود');
        if (evidence.task.companyId !== companyId) {
            throw new ForbiddenException('غير مصرح بالوصول');
        }

        // Only submitter can delete their own evidence
        if (evidence.submittedById !== userId) {
            throw new ForbiddenException('فقط مقدم الإثبات يمكنه حذفه');
        }

        await this.prisma.taskEvidence.delete({
            where: { id: evidenceId },
        });

        return { success: true };
    }

    // ==================== DEPENDENCY METHODS ====================

    /**
     * Get all dependencies for a task (blocking and blocked by)
     */
    async getDependencies(taskId: string, companyId: string) {
        const task = await this.prisma.task.findFirst({
            where: { id: taskId, companyId },
        });

        if (!task) throw new NotFoundException('المهمة غير موجودة');

        const [blockedBy, blocks] = await Promise.all([
            this.prisma.taskDependency.findMany({
                where: { blockedTaskId: taskId },
                include: {
                    blockingTask: {
                        select: {
                            id: true,
                            title: true,
                            status: true,
                            priority: true,
                            dueDate: true,
                        },
                    },
                },
            }),
            this.prisma.taskDependency.findMany({
                where: { blockingTaskId: taskId },
                include: {
                    blockedTask: {
                        select: {
                            id: true,
                            title: true,
                            status: true,
                            priority: true,
                            dueDate: true,
                        },
                    },
                },
            }),
        ]);

        return { blockedBy, blocks };
    }

    /**
     * Update dependency type
     */
    async updateDependencyType(
        dependencyId: string,
        companyId: string,
        type: 'BLOCKS' | 'BLOCKED_BY' | 'RELATED' | 'DUPLICATES',
    ) {
        const dependency = await this.prisma.taskDependency.findFirst({
            where: { id: dependencyId },
            include: { blockedTask: true },
        });

        if (!dependency) throw new NotFoundException('التبعية غير موجودة');
        if (dependency.blockedTask.companyId !== companyId) {
            throw new ForbiddenException('غير مصرح بالوصول');
        }

        return this.prisma.taskDependency.update({
            where: { id: dependencyId },
            data: { type },
        });
    }

    /**
     * Get Gantt chart data for all tasks
     */
    async getGanttData(companyId: string, categoryId?: string) {
        const where: any = { companyId };
        if (categoryId) where.categoryId = categoryId;

        const tasks = await this.prisma.task.findMany({
            where,
            select: {
                id: true,
                title: true,
                status: true,
                priority: true,
                startDate: true,
                dueDate: true,
                progress: true,
                assignee: {
                    select: { id: true, firstName: true, lastName: true, avatar: true },
                },
                category: {
                    select: { id: true, name: true, color: true },
                },
                blockedBy: {
                    select: { blockingTaskId: true, type: true },
                },
                blocks: {
                    select: { blockedTaskId: true, type: true },
                },
            },
            orderBy: [{ startDate: 'asc' }, { dueDate: 'asc' }],
        });

        // Transform for Gantt chart
        return tasks.map(task => ({
            id: task.id,
            name: task.title,
            start: task.startDate || task.dueDate,
            end: task.dueDate,
            progress: task.progress,
            status: task.status,
            priority: task.priority,
            assignee: task.assignee,
            category: task.category,
            dependencies: task.blockedBy.map(d => d.blockingTaskId),
            type: task.blockedBy.length > 0 ? 'task' : 'milestone',
        }));
    }

    // ==================== COMMUNICATION HUB METHODS ====================

    /**
     * Get threaded comments with reactions
     */
    async getComments(taskId: string, companyId: string) {
        const task = await this.prisma.task.findFirst({
            where: { id: taskId, companyId },
        });

        if (!task) throw new NotFoundException('المهمة غير موجودة');

        // Get top-level comments (no parent)
        const comments = await this.prisma.taskComment.findMany({
            where: { taskId, parentId: null },
            include: {
                author: {
                    select: { id: true, firstName: true, lastName: true, avatar: true },
                },
                reactions: {
                    include: {
                        user: {
                            select: { id: true, firstName: true, lastName: true },
                        },
                    },
                },
                replies: {
                    include: {
                        author: {
                            select: { id: true, firstName: true, lastName: true, avatar: true },
                        },
                        reactions: {
                            include: {
                                user: {
                                    select: { id: true, firstName: true, lastName: true },
                                },
                            },
                        },
                    },
                    orderBy: { createdAt: 'asc' },
                },
            },
            orderBy: { createdAt: 'desc' },
        });

        return comments;
    }

    /**
     * Reply to a comment (threaded)
     */
    async replyToComment(
        commentId: string,
        companyId: string,
        userId: string,
        content: string,
        mentions: string[] = [],
    ) {
        const parentComment = await this.prisma.taskComment.findFirst({
            where: { id: commentId },
            include: { task: true, author: true },
        });

        if (!parentComment) throw new NotFoundException('التعليق غير موجود');
        if (parentComment.task.companyId !== companyId) {
            throw new ForbiddenException('غير مصرح بالوصول');
        }

        const reply = await this.prisma.taskComment.create({
            data: {
                taskId: parentComment.taskId,
                authorId: userId,
                parentId: commentId,
                content,
                mentions,
            },
            include: {
                author: {
                    select: { id: true, firstName: true, lastName: true, avatar: true },
                },
            },
        });

        // Notify parent comment author
        if (parentComment.authorId !== userId) {
            await this.notificationsService.sendNotification(
                parentComment.authorId,
                'TASK_UPDATED' as any,
                'رد على تعليقك',
                `تم الرد على تعليقك في المهمة: ${parentComment.task.title}`,
                { taskId: parentComment.taskId, commentId: reply.id },
            );
        }

        // Notify mentioned users
        for (const mentionedUserId of mentions) {
            if (mentionedUserId !== userId && mentionedUserId !== parentComment.authorId) {
                await this.notificationsService.sendNotification(
                    mentionedUserId,
                    'TASK_UPDATED' as any,
                    'تمت الإشارة إليك',
                    `تمت الإشارة إليك في تعليق على المهمة: ${parentComment.task.title}`,
                    { taskId: parentComment.taskId, commentId: reply.id },
                );
            }
        }

        return reply;
    }

    /**
     * Add reaction to comment
     */
    async addReaction(commentId: string, companyId: string, userId: string, emoji: string) {
        const comment = await this.prisma.taskComment.findFirst({
            where: { id: commentId },
            include: { task: true, author: true },
        });

        if (!comment) throw new NotFoundException('التعليق غير موجود');
        if (comment.task.companyId !== companyId) {
            throw new ForbiddenException('غير مصرح بالوصول');
        }

        // Upsert reaction
        const reaction = await this.prisma.commentReaction.upsert({
            where: {
                commentId_userId_emoji: { commentId, userId, emoji },
            },
            create: { commentId, userId, emoji },
            update: {},
            include: {
                user: {
                    select: { id: true, firstName: true, lastName: true },
                },
            },
        });

        // Notify comment author (if not self)
        if (comment.authorId !== userId) {
            await this.notificationsService.sendNotification(
                comment.authorId,
                'TASK_UPDATED' as any,
                `${emoji} تفاعل على تعليقك`,
                `تفاعل شخص ما على تعليقك في المهمة`,
                { taskId: comment.taskId, commentId },
            );
        }

        return reaction;
    }

    /**
     * Remove reaction from comment
     */
    async removeReaction(commentId: string, companyId: string, userId: string, emoji: string) {
        const comment = await this.prisma.taskComment.findFirst({
            where: { id: commentId },
            include: { task: true },
        });

        if (!comment) throw new NotFoundException('التعليق غير موجود');
        if (comment.task.companyId !== companyId) {
            throw new ForbiddenException('غير مصرح بالوصول');
        }

        await this.prisma.commentReaction.deleteMany({
            where: { commentId, userId, emoji },
        });

        return { success: true };
    }

    /**
     * Get activity feed for a task
     */
    async getActivityFeed(taskId: string, companyId: string, limit: number = 50) {
        const task = await this.prisma.task.findFirst({
            where: { id: taskId, companyId },
        });

        if (!task) throw new NotFoundException('المهمة غير موجودة');

        return this.prisma.taskActivityLog.findMany({
            where: { taskId },
            include: {
                user: {
                    select: { id: true, firstName: true, lastName: true, avatar: true },
                },
            },
            orderBy: { createdAt: 'desc' },
            take: limit,
        });
    }

    // ==================== ANALYTICS METHODS ====================

    /**
     * Get productivity metrics for the company
     */
    async getProductivityMetrics(companyId: string, startDate?: Date, endDate?: Date) {
        const dateFilter: any = {};
        if (startDate) dateFilter.gte = startDate;
        if (endDate) dateFilter.lte = endDate;

        const whereClause: any = { companyId };
        if (startDate || endDate) {
            whereClause.createdAt = dateFilter;
        }

        // Get all tasks in period
        const tasks = await this.prisma.task.findMany({
            where: whereClause,
            select: {
                id: true,
                status: true,
                priority: true,
                dueDate: true,
                completedAt: true,
                createdAt: true,
            },
        });

        const totalTasks = tasks.length;
        const completedTasks = tasks.filter(t => t.status === 'COMPLETED').length;
        const approvedTasks = tasks.filter(t => t.status === 'APPROVED').length;
        const overdueTasks = tasks.filter(t =>
            t.dueDate && new Date(t.dueDate) < new Date() && !['COMPLETED', 'APPROVED', 'CANCELLED'].includes(t.status)
        ).length;

        // On-time completion rate
        const completedWithDue = tasks.filter(t => t.status === 'COMPLETED' && t.dueDate && t.completedAt);
        const onTimeCompleted = completedWithDue.filter(t =>
            new Date(t.completedAt!) <= new Date(t.dueDate!)
        ).length;

        // Average completion time (in hours)
        const completedWithTimes = tasks.filter(t => t.completedAt && t.createdAt);
        const avgCompletionHours = completedWithTimes.length > 0
            ? completedWithTimes.reduce((sum, t) => {
                const diff = new Date(t.completedAt!).getTime() - new Date(t.createdAt).getTime();
                return sum + (diff / (1000 * 60 * 60));
            }, 0) / completedWithTimes.length
            : 0;

        // By priority breakdown
        const byPriority = {
            URGENT: tasks.filter(t => t.priority === 'URGENT').length,
            HIGH: tasks.filter(t => t.priority === 'HIGH').length,
            MEDIUM: tasks.filter(t => t.priority === 'MEDIUM').length,
            LOW: tasks.filter(t => t.priority === 'LOW').length,
        };

        // By status breakdown
        const byStatus = {
            TODO: tasks.filter(t => t.status === 'TODO').length,
            IN_PROGRESS: tasks.filter(t => t.status === 'IN_PROGRESS').length,
            PENDING_REVIEW: tasks.filter(t => t.status === 'PENDING_REVIEW').length,
            IN_REVIEW: tasks.filter(t => t.status === 'IN_REVIEW').length,
            APPROVED: tasks.filter(t => t.status === 'APPROVED').length,
            COMPLETED: tasks.filter(t => t.status === 'COMPLETED').length,
            REJECTED: tasks.filter(t => t.status === 'REJECTED').length,
            BLOCKED: tasks.filter(t => t.status === 'BLOCKED').length,
        };

        return {
            totalTasks,
            completedTasks,
            approvedTasks,
            overdueTasks,
            completionRate: totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0,
            onTimeRate: completedWithDue.length > 0 ? (onTimeCompleted / completedWithDue.length) * 100 : 0,
            avgCompletionHours: Math.round(avgCompletionHours * 10) / 10,
            byPriority,
            byStatus,
        };
    }

    /**
     * Get team performance metrics
     */
    async getTeamPerformance(companyId: string, startDate?: Date, endDate?: Date) {
        const dateFilter: any = {};
        if (startDate) dateFilter.gte = startDate;
        if (endDate) dateFilter.lte = endDate;

        const whereClause: any = { companyId, assigneeId: { not: null } };
        if (startDate || endDate) {
            whereClause.createdAt = dateFilter;
        }

        const tasks = await this.prisma.task.findMany({
            where: whereClause,
            include: {
                assignee: {
                    select: { id: true, firstName: true, lastName: true, avatar: true },
                },
            },
        });

        // Group by assignee
        const byUser = new Map<string, any>();

        for (const task of tasks) {
            if (!task.assigneeId) continue;

            if (!byUser.has(task.assigneeId)) {
                byUser.set(task.assigneeId, {
                    user: task.assignee,
                    total: 0,
                    completed: 0,
                    inProgress: 0,
                    overdue: 0,
                });
            }

            const stats = byUser.get(task.assigneeId);
            stats.total++;

            if (task.status === 'COMPLETED' || task.status === 'APPROVED') {
                stats.completed++;
            } else if (task.status === 'IN_PROGRESS' || task.status === 'IN_REVIEW') {
                stats.inProgress++;
            }

            if (task.dueDate && new Date(task.dueDate) < new Date() &&
                !['COMPLETED', 'APPROVED', 'CANCELLED'].includes(task.status)) {
                stats.overdue++;
            }
        }

        // Convert to array and calculate rates
        const teamStats = Array.from(byUser.values()).map(stats => ({
            ...stats,
            completionRate: stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0,
        }));

        // Sort by completion rate
        teamStats.sort((a, b) => b.completionRate - a.completionRate);

        return teamStats;
    }

    /**
     * Get time tracking analytics
     */
    async getTimeAnalytics(companyId: string, startDate?: Date, endDate?: Date) {
        const dateFilter: any = {};
        if (startDate) dateFilter.gte = startDate;
        if (endDate) dateFilter.lte = endDate;

        const whereClause: any = {
            task: { companyId },
        };
        if (startDate || endDate) {
            whereClause.startTime = dateFilter;
        }

        const timeLogs = await this.prisma.taskTimeLog.findMany({
            where: whereClause,
            include: {
                task: {
                    select: { id: true, title: true, categoryId: true },
                },
                user: {
                    select: { id: true, firstName: true, lastName: true },
                },
            },
        });

        // Total hours logged
        const totalMinutes = timeLogs.reduce((sum, log) => sum + (log.duration || 0), 0);
        const totalHours = Math.round(totalMinutes / 60 * 10) / 10;

        // By user
        const byUser = new Map<string, number>();
        for (const log of timeLogs) {
            const current = byUser.get(log.userId) || 0;
            byUser.set(log.userId, current + (log.duration || 0));
        }

        const userHours = Array.from(byUser.entries()).map(([userId, minutes]) => ({
            userId,
            user: timeLogs.find(t => t.userId === userId)?.user,
            hours: Math.round(minutes / 60 * 10) / 10,
        })).sort((a, b) => b.hours - a.hours);

        return {
            totalHours,
            totalLogs: timeLogs.length,
            byUser: userHours,
        };
    }

    /**
     * Get task trends over time
     */
    async getTaskTrends(companyId: string, days: number = 30) {
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);

        const tasks = await this.prisma.task.findMany({
            where: {
                companyId,
                createdAt: { gte: startDate },
            },
            select: {
                createdAt: true,
                completedAt: true,
                status: true,
            },
        });

        // Group by day
        const dailyStats = new Map<string, { created: number; completed: number }>();

        for (let i = 0; i <= days; i++) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            const key = date.toISOString().split('T')[0];
            dailyStats.set(key, { created: 0, completed: 0 });
        }

        for (const task of tasks) {
            const createdKey = new Date(task.createdAt).toISOString().split('T')[0];
            if (dailyStats.has(createdKey)) {
                dailyStats.get(createdKey)!.created++;
            }

            if (task.completedAt) {
                const completedKey = new Date(task.completedAt).toISOString().split('T')[0];
                if (dailyStats.has(completedKey)) {
                    dailyStats.get(completedKey)!.completed++;
                }
            }
        }

        // Convert to array
        const trends = Array.from(dailyStats.entries())
            .map(([date, stats]) => ({ date, ...stats }))
            .sort((a, b) => a.date.localeCompare(b.date));

        return trends;
    }

    /**
     * Generate comprehensive report
     */
    async generateReport(
        companyId: string,
        options: {
            startDate?: Date;
            endDate?: Date;
            categoryId?: string;
            assigneeId?: string;
            includeMetrics?: boolean;
            includeTeam?: boolean;
            includeTime?: boolean;
            includeTrends?: boolean;
        } = {},
    ) {
        const report: any = {
            generatedAt: new Date(),
            period: {
                start: options.startDate || null,
                end: options.endDate || null,
            },
        };

        // Base metrics
        if (options.includeMetrics !== false) {
            report.metrics = await this.getProductivityMetrics(
                companyId,
                options.startDate,
                options.endDate,
            );
        }

        // Team performance
        if (options.includeTeam !== false) {
            report.team = await this.getTeamPerformance(
                companyId,
                options.startDate,
                options.endDate,
            );
        }

        // Time analytics
        if (options.includeTime) {
            report.timeTracking = await this.getTimeAnalytics(
                companyId,
                options.startDate,
                options.endDate,
            );
        }

        // Trends
        if (options.includeTrends) {
            report.trends = await this.getTaskTrends(companyId, 30);
        }

        // Category breakdown
        const categories = await this.prisma.taskCategory.findMany({
            where: { companyId },
            include: {
                _count: {
                    select: { tasks: true },
                },
            },
        });

        report.categories = categories.map(c => ({
            id: c.id,
            name: c.name,
            color: c.color,
            taskCount: c._count.tasks,
        }));

        return report;
    }

    // ==================== AUTOMATION METHODS ====================

    /**
     * Create an automation rule
     */
    async createAutomation(
        companyId: string,
        userId: string,
        data: {
            name: string;
            description?: string;
            trigger: string;
            triggerConfig?: any;
            action: string;
            actionConfig?: any;
            categoryId?: string;
            priority?: string;
        },
    ) {
        return this.prisma.taskAutomation.create({
            data: {
                companyId,
                createdById: userId,
                name: data.name,
                description: data.description,
                trigger: data.trigger as any,
                triggerConfig: data.triggerConfig,
                action: data.action as any,
                actionConfig: data.actionConfig,
                categoryId: data.categoryId,
                priority: data.priority as any,
            },
            include: {
                createdBy: {
                    select: { id: true, firstName: true, lastName: true },
                },
                category: {
                    select: { id: true, name: true, color: true },
                },
            },
        });
    }

    /**
     * Get all automation rules for a company
     */
    async getAutomations(companyId: string) {
        return this.prisma.taskAutomation.findMany({
            where: { companyId },
            include: {
                createdBy: {
                    select: { id: true, firstName: true, lastName: true },
                },
                category: {
                    select: { id: true, name: true, color: true },
                },
                _count: {
                    select: { logs: true },
                },
            },
            orderBy: { createdAt: 'desc' },
        });
    }

    /**
     * Update an automation rule
     */
    async updateAutomation(
        automationId: string,
        companyId: string,
        data: Partial<{
            name: string;
            description: string;
            trigger: string;
            triggerConfig: any;
            action: string;
            actionConfig: any;
            categoryId: string;
            priority: string;
            isActive: boolean;
        }>,
    ) {
        const automation = await this.prisma.taskAutomation.findFirst({
            where: { id: automationId, companyId },
        });

        if (!automation) throw new NotFoundException('القاعدة غير موجودة');

        return this.prisma.taskAutomation.update({
            where: { id: automationId },
            data: {
                ...data,
                trigger: data.trigger as any,
                action: data.action as any,
                priority: data.priority as any,
            },
            include: {
                createdBy: {
                    select: { id: true, firstName: true, lastName: true },
                },
                category: {
                    select: { id: true, name: true, color: true },
                },
            },
        });
    }

    /**
     * Delete an automation rule
     */
    async deleteAutomation(automationId: string, companyId: string) {
        const automation = await this.prisma.taskAutomation.findFirst({
            where: { id: automationId, companyId },
        });

        if (!automation) throw new NotFoundException('القاعدة غير موجودة');

        await this.prisma.taskAutomation.delete({
            where: { id: automationId },
        });

        return { success: true };
    }

    /**
     * Toggle automation active state
     */
    async toggleAutomation(automationId: string, companyId: string) {
        const automation = await this.prisma.taskAutomation.findFirst({
            where: { id: automationId, companyId },
        });

        if (!automation) throw new NotFoundException('القاعدة غير موجودة');

        return this.prisma.taskAutomation.update({
            where: { id: automationId },
            data: { isActive: !automation.isActive },
        });
    }

    /**
     * Process automations for a trigger event
     */
    async processAutomations(
        companyId: string,
        taskId: string,
        trigger: string,
        context: any = {},
    ) {
        // Find matching automations
        const automations = await this.prisma.taskAutomation.findMany({
            where: {
                companyId,
                trigger: trigger as any,
                isActive: true,
            },
        });

        const task = await this.prisma.task.findUnique({
            where: { id: taskId },
            include: { assignee: true, reviewer: true, approver: true },
        });

        if (!task) return [];

        const results = [];

        for (const automation of automations) {
            // Check category filter
            if (automation.categoryId && task.categoryId !== automation.categoryId) continue;

            // Check priority filter
            if (automation.priority && task.priority !== automation.priority) continue;

            // Check trigger config
            const triggerConfig = automation.triggerConfig as any;
            if (triggerConfig) {
                if (trigger === 'STATUS_CHANGED') {
                    if (triggerConfig.fromStatus && context.fromStatus !== triggerConfig.fromStatus) continue;
                    if (triggerConfig.toStatus && context.toStatus !== triggerConfig.toStatus) continue;
                }
            }

            // Execute action
            try {
                await this.executeAutomationAction(automation, task, context);

                // Log success
                await this.prisma.automationLog.create({
                    data: {
                        automationId: automation.id,
                        taskId,
                        trigger,
                        action: automation.action,
                        success: true,
                    },
                });

                // Update run count
                await this.prisma.taskAutomation.update({
                    where: { id: automation.id },
                    data: {
                        lastRunAt: new Date(),
                        runCount: { increment: 1 },
                    },
                });

                results.push({ automationId: automation.id, success: true });
            } catch (error: any) {
                // Log error
                await this.prisma.automationLog.create({
                    data: {
                        automationId: automation.id,
                        taskId,
                        trigger,
                        action: automation.action,
                        success: false,
                        error: error.message,
                    },
                });

                results.push({ automationId: automation.id, success: false, error: error.message });
            }
        }

        return results;
    }

    /**
     * Execute automation action
     */
    private async executeAutomationAction(automation: any, task: any, context: any) {
        const actionConfig = automation.actionConfig as any || {};

        switch (automation.action) {
            case 'SEND_NOTIFICATION':
                const targetUserId = actionConfig.userId || task.assigneeId;
                if (targetUserId) {
                    await this.notificationsService.sendNotification(
                        targetUserId,
                        'TASK_UPDATED' as any,
                        actionConfig.title || 'إشعار تلقائي',
                        actionConfig.message || `تم تنفيذ إجراء تلقائي على المهمة: ${task.title}`,
                        { taskId: task.id, automationId: automation.id },
                    );
                }
                break;

            case 'CHANGE_STATUS':
                if (actionConfig.status) {
                    await this.prisma.task.update({
                        where: { id: task.id },
                        data: { status: actionConfig.status },
                    });
                }
                break;

            case 'ASSIGN_USER':
                if (actionConfig.userId) {
                    await this.prisma.task.update({
                        where: { id: task.id },
                        data: { assigneeId: actionConfig.userId },
                    });
                }
                break;

            case 'SET_PRIORITY':
                if (actionConfig.priority) {
                    await this.prisma.task.update({
                        where: { id: task.id },
                        data: { priority: actionConfig.priority },
                    });
                }
                break;

            case 'ADD_WATCHER':
                if (actionConfig.userId) {
                    await this.prisma.taskWatcher.upsert({
                        where: {
                            taskId_userId: { taskId: task.id, userId: actionConfig.userId },
                        },
                        create: { taskId: task.id, userId: actionConfig.userId },
                        update: {},
                    });
                }
                break;

            default:
                break;
        }
    }

    /**
     * Get automation execution logs
     */
    async getAutomationLogs(automationId: string, companyId: string, limit: number = 50) {
        const automation = await this.prisma.taskAutomation.findFirst({
            where: { id: automationId, companyId },
        });

        if (!automation) throw new NotFoundException('القاعدة غير موجودة');

        return this.prisma.automationLog.findMany({
            where: { automationId },
            orderBy: { executedAt: 'desc' },
            take: limit,
        });
    }
}

