export declare class CreateDepartmentDto {
    name: string;
    nameEn?: string;
    branchId: string;
    workStartTime?: string;
    workEndTime?: string;
}
