export declare class EmailModule {
}
