import{ax as t}from"./index-Dt9l-mSr.js";const s=t();export{s};
