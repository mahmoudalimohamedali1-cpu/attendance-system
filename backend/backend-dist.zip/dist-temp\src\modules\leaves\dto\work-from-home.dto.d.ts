export declare class WorkFromHomeDto {
    userId: string;
    date: string;
    reason?: string;
}
