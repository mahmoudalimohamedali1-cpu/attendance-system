"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var OnboardingService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OnboardingService = void 0;
const common_1 = require("@nestjs/common");
let OnboardingService = OnboardingService_1 = class OnboardingService {
    constructor() {
        this.logger = new common_1.Logger(OnboardingService_1.name);
        this.checklists = new Map();
        this.checklistTemplate = [
            { id: '1', title: 'Complete HR paperwork', titleAr: 'إكمال أوراق الموارد البشرية', description: 'توقيع العقد والمستندات المطلوبة', category: 'hr', dueDay: 1 },
            { id: '2', title: 'Get IT credentials', titleAr: 'الحصول على بيانات الدخول', description: 'استلام البريد وكلمة المرور', category: 'it', dueDay: 1 },
            { id: '3', title: 'Set up workstation', titleAr: 'إعداد محطة العمل', description: 'تجهيز الكمبيوتر والمكتب', category: 'it', dueDay: 1 },
            { id: '4', title: 'Meet your buddy', titleAr: 'التعرف على الزميل المرشد', description: 'لقاء الزميل الذي سيساعدك', category: 'team', dueDay: 1 },
            { id: '5', title: 'Complete system tour', titleAr: 'جولة في النظام', description: 'التعرف على أنظمة الشركة', category: 'it', dueDay: 2 },
            { id: '6', title: 'Meet team members', titleAr: 'التعرف على الفريق', description: 'لقاء أعضاء الفريق', category: 'team', dueDay: 2 },
            { id: '7', title: 'Review company policies', titleAr: 'مراجعة سياسات الشركة', description: 'قراءة دليل الموظف', category: 'compliance', dueDay: 3 },
            { id: '8', title: 'Complete security training', titleAr: 'إكمال تدريب الأمان', description: 'تدريب الأمن السيبراني', category: 'training', dueDay: 5 },
            { id: '9', title: 'Set up benefits', titleAr: 'إعداد المزايا', description: 'التأمين الصحي والمزايا الأخرى', category: 'hr', dueDay: 5 },
            { id: '10', title: 'One-on-one with manager', titleAr: 'اجتماع مع المدير', description: 'لقاء فردي لمناقشة التوقعات', category: 'team', dueDay: 5 },
            { id: '11', title: 'Complete department training', titleAr: 'تدريب القسم', description: 'التدريب الخاص بالقسم', category: 'training', dueDay: 10 },
            { id: '12', title: 'Review 30-day goals', titleAr: 'مراجعة أهداف 30 يوم', description: 'وضع أهداف الشهر الأول', category: 'team', dueDay: 14 },
        ];
        this.tourSteps = [
            { id: 1, title: 'Dashboard', titleAr: 'لوحة التحكم', description: 'نظرة عامة على كل شيء', action: 'اذهب إلى الصفحة الرئيسية' },
            { id: 2, title: 'Attendance', titleAr: 'الحضور', description: 'تسجيل الحضور والانصراف', action: 'جرب تسجيل الحضور' },
            { id: 3, title: 'Leave Requests', titleAr: 'طلبات الإجازة', description: 'طلب الإجازات', action: 'استعرض رصيد إجازاتك' },
            { id: 4, title: 'Profile', titleAr: 'الملف الشخصي', description: 'بياناتك الشخصية', action: 'حدث معلوماتك' },
            { id: 5, title: 'AI Chat', titleAr: 'المساعد الذكي', description: 'اسأل أي سؤال', action: 'جرب سؤال المساعد' },
            { id: 6, title: 'Documents', titleAr: 'المستندات', description: 'الوصول للمستندات', action: 'استعرض المستندات المتاحة' },
        ];
    }
    startOnboarding(userId, userName, department) {
        const checklist = {
            userId,
            userName,
            startDate: new Date(),
            progress: 0,
            items: this.checklistTemplate.map(item => ({
                ...item,
                completed: false,
            })),
            department,
        };
        this.checklists.set(userId, checklist);
        return checklist;
    }
    getChecklist(userId) {
        return this.checklists.get(userId) || null;
    }
    completeItem(userId, itemId) {
        const checklist = this.checklists.get(userId);
        if (!checklist) {
            return { success: false, message: '❌ لم يتم العثور على قائمة المهام' };
        }
        const item = checklist.items.find(i => i.id === itemId);
        if (!item) {
            return { success: false, message: '❌ المهمة غير موجودة' };
        }
        if (item.completed) {
            return { success: false, message: '✅ المهمة مكتملة بالفعل' };
        }
        item.completed = true;
        item.completedAt = new Date();
        const completed = checklist.items.filter(i => i.completed).length;
        checklist.progress = Math.round((completed / checklist.items.length) * 100);
        return {
            success: true,
            message: `✅ تم إكمال "${item.titleAr}"!\n\n📊 التقدم: ${checklist.progress}%`,
        };
    }
    getNextItems(userId) {
        const checklist = this.checklists.get(userId);
        if (!checklist)
            return [];
        const daysSinceStart = Math.floor((new Date().getTime() - checklist.startDate.getTime()) / (1000 * 60 * 60 * 24));
        return checklist.items
            .filter(item => !item.completed && item.dueDay <= daysSinceStart + 2)
            .slice(0, 3);
    }
    getSystemTour(userId) {
        return this.tourSteps.map(step => ({ ...step, completed: false }));
    }
    formatChecklist(userId) {
        const checklist = this.checklists.get(userId);
        if (!checklist) {
            return '👋 مرحباً بك! يبدو أنك لست موظفاً جديداً.\n\nإذا كنت بحاجة لمساعدة، فقط اسأل!';
        }
        let message = `👋 **مرحباً ${checklist.userName}!**\n\n`;
        message += `📊 التقدم: ${checklist.progress}%\n`;
        message += `${this.getProgressBar(checklist.progress)}\n\n`;
        const nextItems = this.getNextItems(userId);
        if (nextItems.length > 0) {
            message += `📋 **المهام القادمة:**\n`;
            for (const item of nextItems) {
                message += `⬜ ${item.titleAr}\n   ${item.description}\n\n`;
            }
        }
        const completed = checklist.items.filter(i => i.completed);
        if (completed.length > 0) {
            message += `✅ **مكتمل:** ${completed.length}/${checklist.items.length}\n`;
        }
        if (checklist.buddy) {
            message += `\n👤 **زميلك المرشد:** ${checklist.buddy.name}\n📧 ${checklist.buddy.email}`;
        }
        return message;
    }
    getProgressBar(percent) {
        const filled = Math.floor(percent / 10);
        const empty = 10 - filled;
        return '▓'.repeat(filled) + '░'.repeat(empty);
    }
    formatSystemTour() {
        let message = '🎓 **جولة في النظام:**\n\n';
        for (const step of this.tourSteps) {
            message += `${step.id}️⃣ **${step.titleAr}**\n`;
            message += `   ${step.description}\n`;
            message += `   💡 ${step.action}\n\n`;
        }
        message += '❓ قل "التالي" للانتقال للخطوة التالية';
        return message;
    }
    assignBuddy(userId, buddyName, buddyEmail) {
        const checklist = this.checklists.get(userId);
        if (!checklist) {
            return { success: false, message: '❌ لم يتم العثور على الموظف' };
        }
        checklist.buddy = { name: buddyName, email: buddyEmail };
        return {
            success: true,
            message: `✅ تم تعيين ${buddyName} كزميل مرشد!`,
        };
    }
};
exports.OnboardingService = OnboardingService;
exports.OnboardingService = OnboardingService = OnboardingService_1 = __decorate([
    (0, common_1.Injectable)()
], OnboardingService);
//# sourceMappingURL=onboarding.service.js.map