import{c as o,j as s}from"./index-Dpjqn_H_.js";const c=o(s.jsx("path",{d:"M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"}),"Check");export{c as A};
