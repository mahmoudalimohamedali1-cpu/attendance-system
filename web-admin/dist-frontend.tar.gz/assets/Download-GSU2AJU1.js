import{c as o,j as a}from"./index-D5un0LxA.js";const t=o(a.jsx("path",{d:"M5 20h14v-2H5zM19 9h-4V3H9v6H5l7 7z"}),"Download");export{t as D};
