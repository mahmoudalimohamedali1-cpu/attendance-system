export declare class EmployeeProfileModule {
}
