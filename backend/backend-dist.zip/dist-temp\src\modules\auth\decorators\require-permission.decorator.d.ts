export declare const PERMISSION_KEY = "requiredPermission";
export declare const RequirePermission: (permissionCode: string) => import("@nestjs/common").CustomDecorator<string>;
