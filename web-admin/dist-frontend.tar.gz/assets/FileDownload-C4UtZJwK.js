import{c as o,j as a}from"./index-D5un0LxA.js";const t=o(a.jsx("path",{d:"M19 9h-4V3H9v6H5l7 7zM5 18v2h14v-2z"}),"FileDownload");export{t as F};
