export declare class FaceRecognitionModule {
}
